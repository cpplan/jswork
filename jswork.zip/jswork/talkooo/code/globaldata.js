/**
 * 定义整个程序所使用的全局变量
 */

var HashTable = require('../code/hashtable');

/**
 * key存放用户的uid
 * value存放用户的session, 对方用户key（所以，通过key能相互找到对方），以及其他数据
 * 如：value => {sess:session, selfsock: socket, ready:false, bei: 1000, pubdata: data, otherkey:otherkey}
 */
global.gamersTable = HashTable.HashTableObj();

//用户的socket，每次连接到服务器后，加入到此表
global.socketTable = HashTable.HashTableObj();

//当对方不在线时，其他用户发送的消息临时存放在此表。等用户上线了再来此获取
global.msgTable = HashTable.HashTableObj();

//每个用户的黑名单，自己无法给黑名单的人发消息，黑名单里面的人也无法给我发消息
global.blackTable = HashTable.HashTableObj();

var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport('SMTP', {
    host: 'smtp.huaton.net',
    secureConnection: true,
    port: 465,
    auth: {
        user: 'zhuce@huaton.net',
        pass: 'Minibaidu123'
    }
});

function sendEmail(fromTitle,toUserEmail,emailTitle,htmlCode){
    var mailOptions = {
            from: fromTitle,//发件人   '书本 <zhuce@huaton.net>', // 如果不加<xxx@xxx.com> 会报语法错误
            to: toUserEmail, // 收件人，可以群发，邮箱之间用 ，隔开
            subject: emailTitle, // 邮件标题
            html: htmlCode
    };

    transporter.sendMail(mailOptions,function(error,info){
        if(error != null){
            return console.log(error);
        }
        console.log('邮件发送成功');
    });
};

exports.sendRegistEmail = function(toUserEmail,htmlCode){
    sendEmail('花童游戏注册 <zhuce@huaton.net>',toUserEmail,'花童游戏注册验证',htmlCode);
};
var http = require('http');
var querystring = require('querystring');
var app = require('../app');

function connectAndSend(postData, options, callback) {

    // var contents = querystring.stringify({
    //     name:'byvoid',
    //     email:'byvoid@byvoid.com',
    //     address:'Zijing'
    // });

    var contents = querystring.stringify(postData);

    options.headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': contents.length
    };

    var req = http.request(options, function(res) {
        console.log('post callback');
        res.setEncoding('utf8');
        res.on('data', function(data) {
            if (callback) {
                if (data == '<h1>Not Found</h1>') {
                    console.log(data);
                    return;
                }
                callback(data); //接收到的post接口返回的数据，可能是html，也可能是其他数据类型
            }
        });
    });

    req.on('error', function(e) {
        console.log('error => ', e.message);
    });

    req.write(contents);
    req.end;

}

exports.sendPost = function(postData) {
    console.log('sendPost data => ', postData);
    var path = '/js';
    switch (postData.type) {
        case 'zsk':
            path = '/home/signin/TemporaryBobi';
            break;
        case 'zjk':
            path = '/home/signin/DSettlement';
            break;
        default:
            console.log('url faild');
            return;
    }

    var host = 'api.cubedat.com';
    var options = {
        host: host,
        path: path,
        method: 'POST'
    };

    // var host = '192.168.2.104';
    // path = '/js';
    // var options = {
    //     host: host,
    //     port: 5001,
    //     path: path,
    //     method: 'POST'
    // };

    switch (postData.type) {
        case 'zsk':
            var callback = postCallbackZsk;
            break;
        case 'zjk':
            var callback = postCallbackZjk;
            break;
        default:
            console.log('callback faild');
            return;
    }
    connectAndSend(postData, options, callback);
};

function postCallbackZsk(mydata) {
    console.log('postCallbackZsk mydata =>', mydata);

    try {
        var data = JSON.parse(mydata);
    } catch (error) {
        console.log(error);
        console.log(error.msg);
        return false;
    }

    if (data && !isNaN(data.roomid) && !isNaN(data.deskid)) {
        if (data.status && data.status == 1) {
            console.log(1);
            if (data.roomid == null || data.deskid == null) {
                return;
            }
            app.checkGamerCanGameOk(data.roomid, data.deskid, data.only_id);
        } else {
            console.log(2);
            if (data.roomid == null || data.deskid == null) {
                return;
            }
            app.checkGamerCanGameFaild(data.roomid, data.deskid, 'zskfaild', data.msg);
        }
    } else {
        console.log('zsk post back null');
    }
}

function postCallbackZjk(mydata) {
    console.log('postCallbackZjk mydata =>', mydata);

    try {
        var data = JSON.parse(mydata);
    } catch (error) {
        console.log(error);
        console.log(error.msg);
        return false;
    }

    if (data && !isNaN(data.roomid) && !isNaN(data.deskid)) {
        if (data.status && data.status == 1) {
            console.log(11);
            if (data.roomid == null || data.deskid == null) {
                return;
            }
            app.jiesuanPostBackOk(data.roomid, data.deskid);
        } else {
            console.log(22);
            if (data.roomid == null || data.deskid == null) {
                return;
            }
            app.jiesuanPostBackFaild(data.roomid, data.deskid, 'zjkfaild', data.msg);
        }
    } else {
        console.log('zjk post back null');
    }
}
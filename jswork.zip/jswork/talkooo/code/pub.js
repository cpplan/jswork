var HashTable = require('../code/hashtable');

//用户查找一个正在等待的用户，并加入
exports.findWaitingAndJoin = function (self_user_id) {
    //将各自value中的okey字段值，记录为对方的key
    try {
        var waitingGamerKey = findEmptyKey(); //在等待的用户的key
        if (!waitingGamerKey) {
            return null;
        }

        var waitingGamerValue = global.gamersTable.getValue(waitingGamerKey);
        waitingGamerValue.otherkey = self_user_id; //存放对方的key

        var joinGamerValue = global.gamersTable.getValue(self_user_id);
        joinGamerValue.otherkey = waitingGamerKey; //存放对方的key

        return waitingGamerValue.sess.userData.account;
    } catch (error) {
        console.log('findWaitingAndJoin error => ', error.msg);
        return null;
    }
};

function findEmptyKey() {
    //查找一个正在等待的用户
    var keys = global.gamersTable.getKeys;
    var count = keys.length;
    for (var i = 0; i < count; i++) {
        var key = keys[i];
        var value = global.gamersTable.getValue(key);
        if (value && !value.otherkey) {
            return key;
        }
    }
    return null;
}

exports.logout = function (waiting_user_id, self_user_id) {
    //用户退出，则需要将自己从对手用户的otherkey中删除，并从列表中删除
    var waitingGamerValue = global.gamersTable.getValue(waiting_user_id);
    waitingGamerValue.otherkey = null;

    global.gamersTable.remove(self_user_id);
};

exports.createName = function (nameLen) {
    var abcs = 'ABCDEFGHIJKLMNPQRSTUVWXY23456789';
    var max = abcs.length;
    var name = '';

    for (var i = 0; i < nameLen; i++) {
        var index = exports.randomNum(0, 31);
        if (index >= max) {
            index = 0;
        }
        var char = abcs.substr(index, 1);
        name += char;
    }

    return name;
};

//生成从minNum到maxNum的随机数
exports.randomNum = function (minNum, maxNum) {
    var random = 0;
    switch (arguments.length) {
        case 1:
            random = parseInt(Math.random() * minNum + 1, 10);
            break;
        case 2:
            random = parseInt(Math.random() * (maxNum - minNum + 1) + minNum, 10);
            break;
    }
    return random;
};

//产生0 - 9的随机数
exports.getRandomBetweenZeroToNine = function () {
    return parseInt(Math.random().toString().split('.')[1].substr(0, 1));
};


exports.getLeftRightObj = function () {
    //随机创建用户自己和对方的方位
    var num = parseInt(Math.random().toString().split('.')[1].substr(0, 1));
    if (num % 2 == 0) {
        return { myself: 'left', other: 'right' };
    } else {
        return { myself: 'right', other: 'left' };
    }
};




function getDateOfToday() {
    var time = new Date();
    var month = time.getMonth() + 1;
    month = month < 10 ? '0' + month : month;
    var day = time.getDate();
    day = day < 10 ? '0' + day : day;
    return time.getFullYear().toString() + '-' + month + '-' + day;
}

exports.getTimeNow = function () {
    var time = new Date();
    var hours = time.getHours();
    hours = hours < 10 ? '0' + hours : hours;
    var minutes = time.getMinutes();
    minutes = minutes < 10 ? '0' + minutes : minutes;
    var seconds = time.getSeconds();
    seconds = seconds < 10 ? '0' + seconds : seconds;

    return getDateOfToday() + ' ' + hours + ':' + minutes + ':' + seconds;
};

exports.getTimeNowForYz = function (outTime) {
    var time = new Date();
    time.setMinutes(time.getMinutes() - outTime);
    var hours = time.getHours();
    hours = hours < 10 ? '0' + hours : hours;
    var minutes = time.getMinutes();
    minutes = minutes < 10 ? '0' + minutes : minutes;
    var seconds = time.getSeconds();
    seconds = seconds < 10 ? '0' + seconds : seconds;

    return getDateOfToday() + ' ' + hours + ':' + minutes + ':' + seconds;
};



function replaceAnyWords(words, any, replace) {
    //替换words中所有的any为replace
    var reg = new RegExp(any, "g");
    var newwords = words.replace(reg, replace);
    // console.log('newwords => ', newwords);
    return newwords;
}

exports.replaceAny = function (words, any, replace) {
    //替换words中所有的any为replace
    return replaceAnyWords(words, any, replace);
};

exports.replaceSpace = function (words) {
    //替换所有空格
    var reg = new RegExp(" ", "g");
    var newwords = words.replace(reg, '');
    return newwords;
};

exports.isPlusNumber = function (words) {
    //判断正整数
    var reg = /^[1-9][0-9]*$/;
    return reg.test(words.toString());
};

exports.isMinusNumber = function (words) {
    //判断负整数
    var reg = /^-[1-9][0-9]*$/;
    return reg.test(words.toString());
}

exports.escape = function (words) {

    //比较特殊的字符先删除掉
    words = exports.replaceSpace(words);
    words = replaceAnyWords(words, '&mdash', '');//删除&mdash
    words = replaceAnyWords(words, '"', '');//删除"
    words = replaceAnyWords(words, "'", '');//删除'

    if (words.length == 0) {
        return words;
    }

    //带\的都表示需要转义才能使用
    // words = replaceAnyWords(words, '\\\?', '');//删除?
    words = replaceAnyWords(words, '\\\*', '');//删除*
    words = replaceAnyWords(words, '\\\$', '');//删除$
    words = replaceAnyWords(words, '\\\^', '');//删除^
    words = replaceAnyWords(words, '\\\(', '');//删除(
    words = replaceAnyWords(words, '\\\)', '');//删除)
    words = replaceAnyWords(words, '\\\[', '');//删除[
    words = replaceAnyWords(words, '\\\]', '');//删除]
    words = replaceAnyWords(words, '\\\|', '');//删除|
    // words = replaceAnyWords(words, '\\\.', '');//删除.

    words = replaceAnyWords(words, '\\\\', '');//删除"1\\2"中的\
    // words = replaceAnyWords(words, '\/', '');//删除/

    if (words.length == 0) {
        return words;
    }

    var pattern = "~`!@#%{};<>,";//不需要转义就可以直接使用
    var count = pattern.length;

    for (var i = 0; i < count; i++) {
        var any = pattern[i];
        words = replaceAnyWords(words, any, '');
        console.log('words => ', words);
    }

    return words;

};



var html_head = '<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body>';
var html_body = '</body></html>';

exports.toHtml = function (content) {
    return html_head + content + html_body;
};


exports.addBlack = function (myuid, blackuid) {
    //先查询我的黑名单是否已经建立
    var blackvalueHashTable = global.blackTable.getValue(myuid);
    if (!blackvalueHashTable) {
        console.log('我的黑名单还没有建立，先建立自己的黑名单');
        var blackHashTable = HashTable.HashTableObj();
        blackHashTable.add(blackuid, '');//只需要保存黑名单中的用户uid就行
        global.blackTable.add(myuid, blackHashTable);
    } else {
        console.log('我的黑名单已经建立，将最新的用户加入黑名单');
        blackvalueHashTable.add(blackuid, '');
    }
};

exports.removeBlack = function (myuid, blackuid) {
    //从我的黑名单中删掉对方
    var blackvalueHashTable = global.blackTable.getValue(myuid);
    if (!blackvalueHashTable) {
        console.log('我的黑名单不存在，不需要删除');
    } else {
        console.log('我的黑名单已经建立，将对方从黑名单中移除');
        blackvalueHashTable.remove(blackuid);
    }
};
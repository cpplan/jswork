var crypto = require('crypto');

exports.getTimeOfToday = function(){
    var time = new Date();
    return time.getFullYear().toString() + (time.getMonth() + 1).toString() + time.getDate().toString() + time.getHours().toString() + time.getMinutes().toString() + time.getSeconds().toString() + time.getMilliseconds().toString();
};

exports.getTimeOfTodayWithoutYear = function(){
    var time = new Date();
    return (time.getMonth() + 1).toString() + time.getDate().toString() + time.getHours().toString() + time.getMinutes().toString() + time.getSeconds().toString() + time.getMilliseconds().toString();
};

exports.getJiamiCode = function(psw){

    var sha1 = crypto.createHash('sha1');
    var jiamiCode = sha1.update(psw).digest('hex');
    // console.log(jiamiCode);
    return jiamiCode;

};
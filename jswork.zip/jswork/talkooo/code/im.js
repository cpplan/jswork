var pub = require('../code/pub');
var HashTable = require('../code/hashtable');
require('../code/globaldata');


exports.ready = function (uid, socket) {
    console.log('添加socket到hash表中');
    addSocket(uid, socket);

    console.log('自己刚上线，从临时信息表中查找是否有给自己的信息');
    var msgvaluehashtable = global.msgTable.getValue(uid);
    if (msgvaluehashtable) {
        var senderuidlist = msgvaluehashtable.getKeys();
        var count = senderuidlist.length;
        var senderuidaccmsgjson = [];//存放每个留言者的所有留言的数组(一个元素)，及其发送者信息

        console.log('打印出给自己留言的所有uid => ', senderuidlist);

        for (var i = 0; i < count; i++) {
            var uid = senderuidlist[i];
            var leavemsgs = msgvaluehashtable.getValue(uid);//获取一位用户发送的所有消息,是一个数组
            console.log('取到一个用户的发给此用户的所有留言信息 => ', leavemsgs);
            senderuidaccmsgjson.push(leavemsgs);
        }

        console.log('将别人发给自己的消息，发给自己');
        socket.emit('getmyleavemsg', senderuidaccmsgjson);

    } else {
        console.log('没有查找到别人发给自己的留言');
    }
};

function inBlack(myuid, blackuid){
    var blackvalueHashTable = global.blackTable.getValue(myuid);
    if(!blackvalueHashTable){
        console.log('不存在黑名单');
        return false;
    }

    console.log('存在黑名单，查询是否在此黑名单中');
    if(blackvalueHashTable.containsKey(blackuid) == true){
        console.log('对方在黑名单中');
        return true;
    }

    console.log('对方不在黑名单中');
    return false;
}

exports.imSendMsg = function (socket, senderuid, senderacc, msg, fuserid) {

    console.log('所有socket uid => ', global.socketTable.getKeys());

    //如果在线就将信息转发给目标用户
    var sendmsg = { senderuid: senderuid, senderacc: senderacc, msg: msg, thetime: pub.getTimeNow() };

    //先查询对方是否是在自己的黑名单中
    if(inBlack(senderuid, fuserid) == true){
        return socket.emit('sendmsgblack');
    }

    //如果不在线，则存放在临时信息表中，等待目标用户上线后来取
    var tosocket = global.socketTable.getValue(fuserid);

    if (tosocket && tosocket.disconnected == false) {
        console.log('对方在线，直接转发消息给: ', fuserid);
        tosocket.emit('recvmsg', sendmsg);

        console.log('通知消息发送者，对方在线，消息已发送给对方');
        socket.emit('sendmsgback', { online: true, sendmsg: sendmsg });
    } else {
        console.log('对方不在线, 消息存入临时表中，等待用户上线后来取');

        removeSocket(fuserid);

        //要存放的数据结构, 可以存放多个人发送的多条信息 : 
        //key = fuserid, value = <(key:senderuid) => (value:[ {msg:1}, {msg:2} ])>
        var recvvalue = global.msgTable.getValue(fuserid);
        if (recvvalue) {
            console.log('接收方已经存在留言，recvvalue同样是个hash表，可以存放多个人给他发送的多条消息');
            //试图找出发当前消息的人之前是否已经发送过。
            //如果发送过，将消息直接存入之前的消息数组; 如果没有发送过，创建新数组，并存入

            var oldsendermsgarr = recvvalue.getValue(senderuid);
            console.log('oldsendermsgarr => ', oldsendermsgarr);
            if (oldsendermsgarr) {
                console.log('朋友 ', senderuid, ' 此前已经发送过留言，则将新消息存入此前的数组');
                oldsendermsgarr.push(sendmsg);
            } else {
                console.log('朋友 ', senderuid, ' 此前没发有送过留言，为发消息者创建一条键值对记录');
                recvvalue.add(senderuid, [sendmsg]);
            }
        } else {
            console.log('接收方还不存在留言，则先创建一个hash表，用于存储发给此用户的所有用户的所有留言');
            //然后为此消息接收者创建一条key=>value==也为发送者创建一条键值对记录，存入上述hash表
            var newsenderhashtable = HashTable.HashTableObj();
            newsenderhashtable.add(senderuid, [sendmsg]);//代表一个发送者的hash表，也是消息接收者的value
            global.msgTable.add(fuserid, newsenderhashtable);//信息接收者hash表
        }

        console.log('通知消息发送者，对方不在线，消息已临时存储');
        socket.emit('sendmsgback', { online: false, sendmsg: sendmsg });

    }
};

exports.readedleavemsg = function (socket, myuid, fuserid) {
    //先找到给我留言的value
    var leavemsgvaluehashtable = global.msgTable.getValue(myuid);
    if (leavemsgvaluehashtable) {
        console.log('然后找到已经被打开的朋友的留言数组,全部删除');
        leavemsgvaluehashtable.remove(fuserid);
        console.log('剩余的其他人给我的留言uid => ', leavemsgvaluehashtable.getKeys());

        console.log('通知客户端，此朋友的留言已被删除');
        socket.emit('readedlmsgback', { fuserid: fuserid });
    }
}

function disconnect(uid) {
    console.log('断开前，所有socket uid => ', getSocketKeys());

    console.log('用户断开了连接，从socket列表中删除此人的scoket');
    removeSocket(uid);

    console.log('断开后，所有socket uid => ', getSocketKeys());
}

exports.disconnect = disconnect;

function addSocket(uid, socket) {
    console.log('添加前，所有socket uid => ', getSocketKeys());
    global.socketTable.add(uid, socket);
    console.log('添加后，所有socket uid => ', getSocketKeys());
}

function removeSocket(uid) {
    console.log('删除', uid, ' socket前，所有socket keys => ', getSocketKeys());
    global.socketTable.remove(uid);
    console.log('删除', uid, ' socket后，所有socket keys => ', getSocketKeys());
}

function getSocketKeys() {
    return global.socketTable.getKeys();
}

function emit(uid, socket, event, data) {
    if (!socket || socket.disconnected == true) {
        console.log('socket已断开，删除此socket');
        return removeSocket(uid);
    }
    socket.emit(event, data);
}
var cookies = require('cookies');
var async = require('async');
var mailer = null;//require('../code/email');
var jiami = require('../code/jiami');
var globaldata = require('../code/globaldata')

var mysql = require('mysql');
var db = mysql.createConnection({
			host     : '123.57.82.240',
			user     : 'chuxin',
			password : 'Chuxin!@#',
			database : 'zentao'
});

//db.connect();
console.log('connect to mysql sucess');

exports.regist = function(res,name,psw){
    db.query("select id from tuser where name = ?",[name],function(err,rows){
		if(err === null){
			if(rows.length > 0){
				res.end('registed','utf-8');//通知浏览器，此账号已经被使用
			} else {
				insertNewAccount(res,name,psw);//向数据库中插入新的记录
			}
		} else {
			console.log('出错：regist()查询数据',err.message);
			res.end('regist faild','utf-8');
		}
	});
};

exports.insertManyAccount = function(name) {
	db.query('insert into tuser (name,psw,dou,yb,online,logintime,area,room,desk,pos,locked,yzcode) values (?,?,?,?,?,?,?,?,?,?,?,?)'
	,[name,'123456',0,0,'of','',0,0,0,0,'开','yzCode'],function(err){
		if(err === null){
            if(this.lastID > 0){
                console.log(name,' ok');
			} else {
                console.log(name,' faild');
			}
		} else {
                console.log(name,' error');
		}
	});
};

function insertNewAccount(res,name,psw){
    var yzCode = jiami.getJiamiCode(name);

	db.query('insert into tuser (name,psw,dou,yb,online,logintime,area,room,desk,pos,locked,yzcode) values (?,?,?,?,?,?,?,?,?,?,?,?)'
	,[name,psw,0,0,'of','',0,0,0,0,'关',yzCode],function(err){
		if(err === null){
//			console.log('this.lastID = ' + this.lastID);//lastID == 最后插入行的ID
//			console.log('this.changes = ' + this.changes);// changes == 1
            if(this.lastID > 0){
                var htmlCode = '<p>您已经注册花童游戏帐号: ' + name + '，请点击下面链接进行验证：</p>'
                                + '<p>http://huaton.net/yzreg/?ht=' + yzCode + '</p>'
                                + '<p>这是系统自动发送的，请不要直接回复！</p>';
                mailer.sendRegistEmail(name,htmlCode);
                res.end('ok','utf-8');
			} else {
                res.end('faild','utf-8');
			}
		} else {
            console.log('出错：runInsert()插入数据',err.message);
            res.end('faild','utf-8');
		}
	});
}

exports.validateEmail = function(yzcode,res){
    var otime = getTimeNowForYz(global.yzOutTime);

    //更新未过期的制定验证码记录
    db.query("update tuser set locked = '开' where yzcode = ? and regtime > ?",[yzcode,otime],function(err){
        if(err === null){
            if(this.changes > 0){
                res.redirect('/yzok');//邮箱验证已经通过
            } else {
                res.redirect('/yzfailed');//邮箱验证已经过期
            }
        } else {
            console.log('出错：validateEmail()',err.message);
            console.log('非法邮箱验证!');
            res.redirect('/yzfailed');
        }
    });
};

exports.delOutTimeEmail = function(){
    var otime = getTimeNowForYz(global.yzOutTime);

    db.query("delete from tuser where locked = '关' and regtime < ?",[otime],function(err){
        if(err === null){
            if(this.changes > 0){
                console.log('删除过期未验证的邮箱帐号数: ',this.changes);
            }
        } else {
            console.log('出错：delOutTimeEmail()-delete',err.message);
        }
    });

    db.query("delete from tuserpsw where regtime < ?",[otime],function(err){
        if(err === null){
            if(this.changes > 0){
            console.log('删除过期未验证的邮箱帐号数: ',this.changes);
            }
        } else {
            console.log('出错：delOutTimeEmail()-tuserpsw',err.message);
        }
    });
};


exports.resetUserPsw = function(res,name,psw){
    db.query('select id from tuser where name = ? and locked = "开"',[name],function(err,rows){
        if(err === null){
            if(rows.length === 0){
                res.end('unregisted','utf-8');//此账号不存在，或还未验证
            } else {
                setNewPsw(res,name,psw);//向数据库中插入新的记录，备用
            }
        } else {
            console.log('出错：regist()查询数据',err.message);
            res.end('unregisted faild','utf-8');
        }
    });
}

function setNewPsw(res,name,psw){
    var nameCode = jiami.getJiamiCode(name);
    var pswCode = jiami.getJiamiCode(psw);

    db.query("insert into tuserpsw (name,psw,namecode,pswcode) values (?,?,?,?)",[name,psw,nameCode,pswCode],function(err){
        if(err === null){
            if(this.lastID > 0){
                var htmlCode = '<p>您已经使用花童游戏的密码找回功能设置了新的密码，如果不是您自己操作的，请不要点击下面的链接，并且请删除此邮件。如果的确是您自己操作的，请点击下面的链接激活您的新密码：</p>'
                                + '<p>http://huaton.net/yzpsw/?ht=' + nameCode + '|' + pswCode + '</p>'
                                + '<p>这是系统自动发送的，请不要直接回复！</p>';
                mailer.sendRegistEmail(name,htmlCode);
                res.end('ok','utf-8');
            } else {
                res.end('faild','utf-8');
            }
        } else {
            console.log('出错：resetUserPsw()插入数据',err.message);
            res.end('faild','utf-8');
        }
    });
}

exports.validateEmailForPsw = function(res,nameCode,pswCode){
    var otime = getTimeNowForYz(global.yzOutTime);

    db.query('select name,psw from tuserpsw where namecode = ? and pswcode = ? and regtime > ?',[nameCode,pswCode,otime],function(err,rows){
        if(err === null){
            if(rows.length === 0){
                res.redirect('/pswyzfailed');//在浏览器中显示timeout，修改密码时间过期
            } else {
                updateUserPsw(res,rows[0].name,rows[0].psw);//更新数据库中用户的密码
            }
        } else {
            console.log('出错：validateEmailForPsw()',err.message);
            res.end('faild','utf-8');
        }
    });
};

function updateUserPsw (res,name,newPsw){
    db.query("update tuser set psw = ? where name = ?",[newPsw,name],function(err){
        if(err === null){
            if(this.changes > 0){
                res.redirect('/pswyzok');//新密码邮箱验证已经通过
            } else {
                res.redirect('/pswyzfailed');//新密码邮箱验证已经过期
            }
        } else {
            console.log('出错：updateUserPsw() update',err.message);
            res.redirect('/yzfailed');
        }
    });

    db.query("delete from tuserpsw where name = ?",[name],function(err){
        if(err === null){
            if(this.changes > 0) {
                console.log('删除了42号记录');
            }
        } else {
            console.log('出错：updateUserPsw delete',err.message);
        }
    });
}

exports.login = function(req,res,name,psw,savePsw){
    db.query("select id,dou,yb from tuser where name = ? and psw = ? and locked = '开'",[name,psw],function(err,rows){
        if(err === null){
            if(rows.length === 1){
                req.session.name = name;//保存用户账号备用
                req.session.loginTime = getTimeNow();
                req.session.userId = rows[0].id;
                req.session.dou = rows[0].dou;
                req.session.yb = rows[0].yb;
                req.session.save();

                getGives(req);//取得并保存今天赠送的次数

                if(savePsw){
                    setCookie(req,res,name);//登录成功后，设置cookie
                }

                var gamer = JSON.stringify([rows[0].dou,rows[0].yb,req.session.name,rows[0].id]);
                res.end(gamer,'utf-8');

                global.LoginUserMap.add(name,req.session);
            } else {
                res.end('login faild','utf-8');
            }
        } else {
            res.end('login faild','utf-8');
        }
    });
};

exports.logout = function(userId){
    //重置用户占据的位置信息
    db.query("update tuser set area = 0,room = 0,desk = 0,pos = 0 where id = ?",[userId],function(err){
        if(err === null){
            if(this.changes > 0){
                // console.log('logout');
                // exports.showUser();//正式部署的时候，需要删除
            }
        } else {
            console.log('出错：logout()更新数据',err.message);
        }
    });
};

exports.getUpdate = function(req,res){
    db.query('select id,dou,yb from tuser where name = ?',[req.session.name],function(err,rows){
        if(err === null){
            if(rows.length > 0){
                req.session.userId = rows[0].id;
                req.session.dou = rows[0].dou;
                req.session.yb = rows[0].yb;
                req.session.save();

                res.end(req.session.dou + '|' + req.session.yb,'utf-8');
            }
        } else {
            console.log('出错：getUpdate()',err.message);
            res.end('getUpdate faild','utf-8');
        }
    });
};

exports.getOneSit = function(areaIndex, roomIndex, deskIndex, pos,userId){
    //更新tuser表中，用户所占位子的标记,以及新的登录时间
    db.query("update tuser set area = ?,room = ?,desk = ?,pos = ? where id = ?"
        ,[areaIndex,roomIndex,deskIndex,pos,userId],function(err){
        if(err === null){
            if(this.changes > 0){
                console.log('成功：更新数据库位置信息');
            } else {
                console.log('失败：更新数据库位置信息');
            }
        } else {
            console.log('出错：getOneSit()更新数据',err.message);
        }
    });
};


exports.updateSessionTimeOfUser = function(userName,desk,pos){
    //如果用户进行任何操作，则更新tuser表,对应桌面位子中的用户,如果此用户在线，则更新时间
    var now = getTimeNow();
    db.query("update tuser set logintime = ? where name = ?",[now,userName],function(err){
        if(err === null){
            if(this.changes > 0){
                recordNewTime(desk,pos,now);//更新与数据库中对应的桌面位置的用户的时间
            } else {
                console.log('未能更新用户数据库中的最新在线时间');
            }
        } else {
            console.log('未能更新用户数据库中的最新在线时间2',err.message);
        }
    });
};

function recordNewTime(desk,pos,now){
    switch(pos){
        case 1:
            if(desk.leftPai !== null){
                desk.leftPai.sitTime = now;
                console.log('更新用户占座时间');
            }
            break;
        case 2:
            if(desk.bottomPai !== null){
                desk.bottomPai.sitTime = now;
            }
            break;
        case 3:
            if(desk.rightPai !== null){
                desk.rightPai.sitTime = now;
            }
            break;
    }
}


function setCookie(req,res,name){

  var cookie = new cookies(req,res,'lovecat');
  var account = cookie.get('accMD5');//读取浏览器发送来的cookie

  if(account === undefined){
      cookie.set('accMD5',name,{maxAge: 60 * 1000});//设置cookie
  }

}

exports.showUser = function(){
    //打印所有用户账户信息
    db.query('select id,online,name,area,room,desk,pos,logintime from tuser',function(err,rows){
        if(err === null){
            if(rows.length > 0){
                for(var i = 0; i < rows.length; i++) {
                    var row = rows[i];
                   console.log(row.id,row.name,row.online,row.area,row.room,row.desk,row.pos,row.logintime);
                }

            } else {
                console.log('暂时无法获取用户信息');
            }
        } else {
            console.log(err.message);
        }
    });
};


exports.dizhuWin = function(dou1,session1,dou2,session2,dizhuSess){
    //地主赢：a.将农民应支付豆之和除去38%后数量加入地主豆中 b.扣除农民的豆
    var dzDou = parseInt((dou1 + dou2) * (1 - 0.38));
    dou1 = parseInt(dou1);

    var sqls = {
        'updateDzSql': 'update tuser set dou = dou + ' + dzDou + ' where name = "' + dizhuSess.name + '"',
        'updateNm1Sql': 'update tuser set dou = dou - ' + dou1 + ' where name = "' + session1.name + '"',
        'updateNm2Sql': 'update tuser set dou = dou - ' + dou1 + ' where name = "' + session2.name + '"'
    };

    var tasks = ['updateDzSql','updateNm1Sql','updateNm2Sql'];
    async.eachSeries(tasks, function (item,callback) {

        // console.log(item,' ==> ',sqls[item]);
        db.query(sqls[item],function(err){
            if(err === null) {
                // console.log('成功修改数据库中的豆');
            } else {
                console.log('出错：dizhuWin()更新数据',err.message);
            }
        });

        callback();

    }, function (err1) {
        //此函数在成功执行了上面所有的任务后，就会被调用
        if(err1 !== null){
            console.log('tasks err: ',err1);
        } else {
            // console.log('成功执行完所有任务');

            // console.log('成功增加地主 ' + dizhuSess.name + ' session中的豆');
            dizhuSess.dou += dzDou;//增加地主session中的豆的数量
            dizhuSess.save();
            // console.log('成功减少农民1 ' + session1.name + ' session中的豆');
            session1.dou -= dou1;//减少农民session1中的豆的数量
            session1.save();
            // console.log('成功减少农民2 ' + session2.name + ' session中的豆');
            session2.dou -= parseInt(dou2);//减少农民session2中的豆的数量
            session2.save();
        }
    });

};

exports.nmWin = function(session1,session2,dizhuSess,dzDou){
    //农民赢：a.扣除地主的豆  b.将扣除的地主的豆除去38%后，平分给农民
    var nmDou = parseInt(dzDou * 0.62 * 0.5);
    dzDou = parseInt(dzDou);

    var sqls = {
        'updateDzSql': 'update tuser set dou = dou - ' + dzDou + ' where name = "' + dizhuSess.name + '"',
        'updateNm1Sql': 'update tuser set dou = dou + ' + nmDou + ' where name = "' + session1.name + '"',
        'updateNm2Sql': 'update tuser set dou = dou + ' + nmDou + ' where name = "' + session2.name + '"'
    };

    var tasks = ['updateDzSql','updateNm1Sql','updateNm2Sql'];
    async.eachSeries(tasks, function (item,callback) {

        // console.log(item,' ==> ',sqls[item]);
        db.query(sqls[item],function(err){
            if(err === null) {
                // console.log('成功修改数据库中的豆');
            } else {
                console.log('出错：nmWin()更新数据',err.message);
            }
        });

        callback();

    }, function (err1) {
        //此函数在成功执行了上面所有的任务后，就会被调用
        if(err1 !== null){
            console.log('tasks err: ',err1);
        } else {
            // console.log('成功执行完所有任务');

            // console.log('成功减少地主 ' + dizhuSess.name + ' 数据库中的豆');
            // console.log('减少前地主 ' + dizhuSess.name + ' session中的豆 ',dizhuSess.dou);
            dizhuSess.dou -= dzDou;//减少地主session中的豆的数量
            dizhuSess.save();
            // console.log('减少后地主 ' + dizhuSess.name + ' session中的豆 ',dizhuSess.dou);
            //console.log('成功增加农民 ' + session1.name + ' 数据库中的豆');
            session1.dou += nmDou;//增加农民session1中的豆的数量
            session1.save();
            //console.log('成功增加农民 ' + session2.name + ' 数据库中的豆');
            session2.dou += nmDou;//增加农民session2中的豆的数量
            session2.save();
        }
    });

};


function getGives(req){
    db.query("select id from tgive where userId = ? and giveTime = ?",[req.session.userId,getDateOfToday()],function(err,rows){
        if(err === null){
            rows !== undefined ? req.session.gives = rows.length : req.session.gives = 0;
            req.session.save();
        } else {
            console.log('出错：getGives()更新数据',err.message);
        }
    });
}

exports.giveDou = function(req,ress){

    var date = getDateOfToday();

    var sqls = {
        'updateZsSql': 'update tuser set dou = dou + 1000 where id = ' + req.session.userId + ' and dou < 1000',
        'insertZsRsSql': "insert into tgive (userId,gives,giveTime) values (" + req.session.userId + ",1,'" + date + "')",
        'selectDouSql': "select dou from tuser where id = " + req.session.userId
    };

    var tasks = ['updateZsSql','insertZsRsSql','selectDouSql'];

    async.eachSeries(tasks, function (item,callback) {

        // console.log(item,' ==> ',sqls[item]);
        db.query(sqls[item],function(err,res){
            if(err === null) {
                if(res !== undefined && res.length === 1){
                    req.session.dou = res[0].dou;
                    req.session.gives += 1;
                    req.session.save();

                    ress.end(req.session.gives + ',' + res[0].dou,'utf-8');//发送新的豆数量
                }
            } else {
                console.log('出错：giveDou()更新数据',err.message);
            }
        });

        callback();

    }, function (err1) {
        //此函数在成功执行了上面所有的任务后，就会被调用
        if(err1 !== null){
            console.log('tasks err: ',err1);
            ress.end();
        } else {
            // console.log('成功执行完所有任务');
        }
    });
};

exports.deleteDouForLive = function(userId){
    db.query("update tuser set dou = dou - 10000 where id = ?",[userId],function(err){
        if(err === null){
            if(this.changes > 0) {
                // console.log('游戏中逃跑，扣除10000豆以示惩戒！');
            }
        } else {
            console.log('出错：deleteDouForLive()',err.message);
        }
    });
};

exports.getNotices = function(res){
    db.query('select id, notice from tnotice',function(err,rows){
        if(err === null){
            var count = rows.length;
            if(count > 0){

                var json = '';
                for(var i = 0; i < count; i++){
                    json += '{"id":' + rows[i].id + ',' + '"notice":"' + rows[i].notice + '"}';
                    if(i !== count - 1 && count !== 1){
                        json += ',';
                    }
                }
                json = '[' + json + ']';
                res.end(json,'utf-8');

            } else {
                res.end('暂时无法获取公告','utf-8');
            }

        } else {
            console.log('出错：getNotices()',err.message);
            res.end('公告获取失败','utf-8');
        }
    });
};


exports.mlogin = function(req,res,name,psw){
    db.query("select id, name from tmanager where name = ? and psw = ?",[name,psw],function(err,rows){
        if(err === null){

            if(rows.length > 0){
                req.session.managerId = rows[0].id;
                req.session.managerName = rows[0].name;//保存用户账号备用
                req.session.save();

                res.end('manage','utf-8');

            } else {
//                res.end('账号或密码错误','utf-8');
            }

        } else {
            console.log('出错：mlogin()查询数据',err.message);
            res.end('账号或密码错误','utf-8');
        }
    });
};

exports.manageNotice = function(operate,id,notice,res){
    var sql = '';

    switch (operate){
        case 'add':
            sql = 'insert into tnotice (notice) values ("' + notice + '")';
            break;
        case 'delete':
            sql = "delete from tnotice where id = " + parseInt(id);
            break;
        case 'update':
            sql = 'update tnotice set notice = "' + notice + '" where id = ' + parseInt(id);
            break;
    }

    if(sql === ''){
        return res.end('','utf-8');
    }

    db.query(sql,function(err){
        if(err === null){
            if(this.changes > 0) {
//                console.log('操作公告成功！');
                res.end('ok','utf-8');
            } else {
                res.end('faild','utf-8');
            }
        } else {
            console.log('出错：manageNotice()',err.message);
            res.end('faild','utf-8');
        }
    });
};


exports.getManager = function(res){
    db.query('select id, name, psw from tmanager where locked = "开"',function(err,rows){
        if(err == null){
            var count = rows.length;
            if(count > 0){

                var json = '';
                for(var i = 0; i < count; i++){
                    json += '{"id":' + rows[i].id + ',' + '"name":"' + rows[i].name  + '",' + '"psw":"' + rows[i].psw + '"}';
                    if(i != count - 1 && count != 1){
                        json += ',';
                    }
                }
                json = '[' + json + ']';
                res.end(json,'utf-8');

            } else {
                res.end('暂时无法获取管理员','utf-8');
            }

        } else {
            console.log('出错：getManager()查询数据',err.message);
            res.end('获取管理员失败','utf-8');
        }
    });
};

exports.handleManager = function(operate,id,name,psw,res){
    var sql = '';

    switch (operate){
        case 'add':
            sql = 'insert into tmanager (name,psw,thetime,locked) values ("' + name + '","' + psw + '","' + getDateOfToday() + '","开")';
            break;
        case 'delete':
            sql = "delete from tmanager where id = " + parseInt(id);
            break;
        case 'update':
            sql = 'update tmanager set psw = "' + psw + '" where id = ' + parseInt(id);
            break;
    }

    if(sql == ''){
        return res.end('','utf-8');
    }

    db.query(sql,function(err){
        if(err == null){
            if(this.changes > 0) {
//                console.log('操作管理员成功！');
                res.end('ok','utf-8');
            } else {
                res.end('faild','utf-8');
            }
        } else {
            console.log('出错：handleManager()',err.message);
            res.end('faild','utf-8');
        }
    });
};


exports.getUserPages = function(res){
    db.query('select count(*) from tuser',function(err,rows){
        if(err == null){
            if(rows.length > 0){
                var row = rows[0];
                var count = row['count(*)'];
                res.end(count.toString(),'utf-8');
            } else {
                res.end('0','utf-8');
            }
        } else {
            console.log('出错：getUserPages()查询数据',err.message);
            res.end('faild','utf-8');
        }
    });
};

exports.getUser = function(res,operate,page){
    var sql = '';
    switch (operate){
        case 'name':
            sql = 'select id, name, dou, yb, online from tuser where name = "' + page + '"';
            break;
        case 'page':
            if(isNaN(parseInt(page)) == false){
                var pageCount = 10;
                var startRs = (parseInt(page) - 1) * pageCount;
                sql = 'select id, name, dou, yb, online from tuser where locked = "开" limit ' + startRs + ',' + pageCount;
            }
            break;
    }

    if(sql == ''){
        return res.end('','utf-8');
    }

    db.query(sql,function(err,rows){
        if(err == null){
            var count = rows.length;
            if(count > 0){

                var json = '';
                for(var i = 0; i < count; i++){
                    json += '{"id":' + rows[i].id + ',' + '"name":"' + rows[i].name  + '",' + '"dou":"' + rows[i].dou + '",' + '"yb":"' + rows[i].yb + '",' + '"online":"' + rows[i].online + '"}';
                    if(i != count - 1 && count != 1){
                        json += ',';
                    }
                }
                json = '[' + json + ']';
                res.end(json,'utf-8');

            } else {
                res.end('faild','utf-8');
            }

        } else {
            console.log('出错：getUser()查询数据',err.message);
            res.end('faild','utf-8');
        }
    });
};

exports.handleUser = function(operate,id,value,field,res,admin){
    var sql = '';
    var userId = parseInt(id);
    var nums = parseInt(value);
    var types = '';

    switch (operate){
        case 'add':
            switch (field){
                case 'dou':
                    sql = 'update tuser set dou = dou + ' + nums + ' where id = ' + userId;
                    types = '花豆';
                    break;
                case 'yb':
                    sql = 'update tuser set yb = yb + ' + nums + ' where id = ' + userId;
                    types = '元宝';
                    break;
            }
            break;
        case 'delete':
            sql = "delete from tuser where id = " + userId;
            break;
    }

    if(sql == ''){
        return res.end('','utf-8');
    }

    db.query(sql,function(err){
        if(err == null){
            if(this.changes > 0) {
                res.end('ok','utf-8');

                db.query('insert into tdouyb (userId,nums,types,admin) values (?,?,?,?)',[userId,nums,types,admin],function(errs){

                });

            } else {
                res.end('faild','utf-8');
            }
        } else {
            console.log('出错：handleUser()',err.message);
            res.end('faild','utf-8');
        }
    });
};

exports.getCzrs = function(res,id,types){
    db.query('select nums, admin, thetime from tdouyb where userId = ? and types = ?',[id,types],function(err,rows){
        if(err == null){
            var count = rows.length;
            if(count > 0){

                var json = '';
                for(var i = 0; i < count; i++){
                    json += '{"nums":' + rows[i].nums + ',' + '"admin":"' + rows[i].admin + '",' + '"thetime":"' + rows[i].thetime + '"}';
                    if(i != count - 1 && count != 1){
                        json += ',';
                    }
                }
                json = '[' + json + ']';
                res.end(json,'utf-8');

            } else {
//                console.log('暂时无法获取充值记录');
                res.end('faild','utf-8');
            }

        } else {
            console.log('出错：getCzrs()查询数据',err.message);
            console.log('获取充值记录失败');
            res.end('faild','utf-8');
        }
    });
};






function getDateOfToday(){
    var time = new Date();
    var month = time.getMonth() + 1;
    month = month < 10 ? '0' + month : month;
    var day = time.getDate();
    day = day < 10 ? '0' + day : day;
    return time.getFullYear().toString() + '-' + month + '-' + day;
}

function getTimeNow() {
    var time = new Date();
    var hours = time.getHours();
    hours = hours < 10 ? '0' + hours : hours;
    var minutes = time.getMinutes();
    minutes = minutes < 10 ? '0' + minutes : minutes;
    var seconds = time.getSeconds();
    seconds = seconds < 10 ? '0' + seconds : seconds;

    return getDateOfToday() + ' ' + hours + ':' + minutes + ':' + seconds;
}

function getTimeNowForYz(outTime) {
    var time = new Date();
    time.setMinutes(time.getMinutes() - outTime);
    var hours = time.getHours();
    hours = hours < 10 ? '0' + hours : hours;
    var minutes = time.getMinutes();
    minutes = minutes < 10 ? '0' + minutes : minutes;
    var seconds = time.getSeconds();
    seconds = seconds < 10 ? '0' + seconds : seconds;

    return getDateOfToday() + ' ' + hours + ':' + minutes + ':' + seconds;
}

exports.select = function(){
    db.query('select * from tuser',function(err,rows){
        if(err == null){
            if(rows.length > 0){
                console.log('name: ',rows[0].name,'regtime: ',rows[0].regtime);
            }
        } else {
            console.log('出错：select()查询数据',err.message);
        }
    });

    //exports.update();
};

exports.update = function(){
    db.query("update tuser set locked = '关'",function(err){
        if(err == null){
            if(this.changes > 0) {
                console.log('更新好了');
            }
        } else {
            console.log('出错：update()查询数据',err.message);
        }
    });
};



exports.showAllUsers = function(){
    db.query("select * from tuser",function(err,rows){
        if(err === null){
            if(rows.length > 0){
                for(var key in rows) {
                    console.log(rows[key]);
                }
            }
        }
    });
};

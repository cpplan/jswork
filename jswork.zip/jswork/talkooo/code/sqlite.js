// var cookies = require('cookies');
var sqlite3 = require('sqlite3').verbose();
var db = new sqlite3.Database('./code/db/talk.db');
// var async = require('async');
var pub = require('../code/pub');
var jiami = require('../code/jiami');



exports.logincheck = function () {
    db.all("select * from tuser where islock = ?", ['开'], function (err, rows) {
        if (err == null) {
            if (rows.length > 0) {
                console.log('count => ', rows.length);
                return;
            }
        }
        console.log('login failed');
    });
};

exports.openHome = function (req, res, user_id, checked) {

    db.run('update tuser set openhome = ? where user_id = ?', [checked, user_id], function (err) {
        if (err === null) {
            if (this.changes > 0) {
                req.session.userData.openhome = checked;
                if(checked == 'checked') {
                    res.json({ ok: true, msg: '已对外开放首页，任何人都能访问' });
                } else {
                    res.json({ ok: true, msg: '已对外关闭首页，只有您能访问' });
                }
            } else {
                res.json({ ok: false, msg: '设置失败' });
            }
        } else {
            console.log('出错: openHome()更新数据', err.message);
            res.json({ ok: false, msg: '设置失败' });
        }
    });

};

exports.updateHeadUrl = function (res, user_id, headurl) {

    db.run('update tuser set headimg = ? where user_id = ?', [headurl, user_id], function (err) {
        if (err === null) {
            if (this.changes > 0) {
                // res.json({ ok: true, msg: '设置头像成功' });
            } else {
                // res.json({ ok: false, msg: '设置头像失败' });
            }
        } else {
            console.log('出错: updateHeadUrl()更新数据', err.message);
            return res.json({ ok: false, msg: '操作错误' });
        }
    });

    db.run('update ttalks set headimg = ? where user_id = ?', [headurl, user_id], function (err) {
        if (err === null) {
            if (this.changes > 0) {
                // res.json({ ok: true, msg: '设置头像成功' });
            } else {
                // res.json({ ok: false, msg: '设置头像失败' });
            }
        } else {
            console.log('出错: updateHeadUrl()更新数据', err.message);
            return res.json({ ok: false, msg: '操作错误' });
        }
    });

    db.run('update tfriends set fheadimg = ? where fuser_id = ?', [headurl, user_id], function (err) {
        if (err === null) {
            if (this.changes > 0) {
                res.json({ ok: true, msg: '设置头像成功' });
            } else {
                res.json({ ok: false, msg: '设置头像失败' });
            }
        } else {
            console.log('出错: updateHeadUrl()更新数据', err.message);
            res.json({ ok: false, msg: '操作错误' });
        }
    });

};

exports.getHeadImg = function (res, user_id) {

    db.all("select headimg from tuser where user_id = ?", [user_id], function (err, rows) {
        if (err === null) {
            if (rows.length === 1) {
                return res.json({ ok: true, headimg: rows[0].headimg });
            }
        }
        res.end(null);
    });

};

exports.addDir = function (res, user_id, newdir) {

    db.all("select dir_id from tdir where user_id = ? and dir = ?", [user_id, newdir], function (err, rows) {
        if (err == null) {
            if (rows.length > 0) {
                return res.json({ ok: false, msg: '目录「' + newdir + '」已存在' });
            } else {
                addNewDir(res, user_id, newdir);
            }
        } else {
            console.log('出错：addDir()插入数据', err.message);
            return res.json({ ok: false, msg: '操作错误' });
        }
    });

};

function addNewDir(res, user_id, newdir) {

    db.run('insert into tdir (user_id, dir, create_time, islock) values (?,?,?,?)', [user_id, newdir, pub.getTimeNow(), '开'], function (err) {
        if (err === null) {
            if (this.lastID > 0) {
                return res.json({ ok: true, msg: '新增目录「' + newdir + '」成功！', newdirid: this.lastID });
            } else {
                return res.json({ ok: false, msg: '操作失败' });
            }
        } else {
            console.log('出错: addNewDir()插入数据', err.message);
            return res.json({ ok: false, msg: '操作错误' });
        }
    });

};



exports.addFriendGroup = function (res, user_id, groupname) {

    db.all("select group_id from tgroup where user_id = ? and groupname = ?", [user_id, groupname], function (err, rows) {
        if (err == null) {
            if (rows.length > 0) {
                return res.json({ ok: false, msg: '好友分组「' + groupname + '」已存在' });
            } else {
                insertFriendGroup(res, user_id, groupname);
            }
        } else {
            console.log('出错: addFriendGroup()插入数据', err.message);
            return res.json({ ok: false, msg: '操作错误' });
        }
    });

};

function insertFriendGroup(res, user_id, groupname) {

    db.run('insert into tgroup (user_id, groupname, create_time, islock) values (?,?,?,?)', [user_id, groupname, pub.getTimeNow(), false], function (err) {
        if (err == null) {
            if (this.lastID && this.lastID > 0) {
                return res.json({ ok: true, msg: '新增好友分组「' + groupname + '」成功！', newgroupid: this.lastID });
            } else {
                return res.json({ ok: false, msg: '操作失败' });
            }
        } else {
            console.log('出错: insertFriendGroup()插入数据', err.message);
            return res.json({ ok: false, msg: '操作错误' });
        }
    });

};


exports.delDir = function (res, user_id, dir_id, dirgroup) {

    //删除2个表：好友表，好友分组表
    db.serialize(function () {

        var runok1 = false;
        var runok2 = false;

        db.run('BEGIN TRANSACTION');

        db.run('delete from ttalks where user_id = ? and dir_id = ?', [user_id, dir_id], function (err) {
            console.log('从即说表中删除即说文档，因为要删除的目录中可能没有文档，所以，只要删除没有出错，就是成功');
            if (err === null) {
                console.log('delDir, 成功, 操作 1');
                runok1 = true;
            } else {
                console.log('操作 1 错误: delDir => ', err.message);
            }
        });

        db.run('delete from tdir where user_id = ? and dir_id = ?', [user_id, dir_id], function (err) {
            console.log('删除目录');
            if (err === null) {
                if (this.changes > 0) {
                    console.log('delDir, 成功, 操作 2');
                    runok2 = true;
                } else {
                    console.log('delDir, 失败, 操作 2');
                }
            } else {
                console.log('操作 2 错误: delDir => ', err.message);
            }

            console.log('runok1: ', runok1, 'runok2: ', runok2);

            if (runok1 == true && runok2 == true) {
                console.log('提交事务');
                db.run('COMMIT TRANSACTION');

                res.json({ ok: true, msg: '删除目录「' + dirgroup + '」成功!' });
            } else {
                console.log('事务回滚');
                db.run('ROLLBACK TRANSACTION');

                res.json({ ok: false, msg: '删除目录「' + dirgroup + '」失败!' });
            }

        });

    });

};

exports.delFriendGroup = function (res, user_id, group_id, dirgroup) {

    //删除2个表：好友表，好友分组表
    db.serialize(function () {

        var runok1 = false;
        var runok2 = false;

        db.run('BEGIN TRANSACTION');

        db.run('delete from tfriends where user_id = ? and group_id = ?', [user_id, group_id], function (err) {
            console.log('从好友表中删除好友，因为要删除的分组中可能没有好友，所以，只要删除没有出错，就是成功');
            if (err === null) {
                console.log('delFriendGroup, 成功, 操作 1');
                runok1 = true;
            } else {
                console.log('操作 1 错误: delFriendGroup => ', err.message);
            }
        });

        db.run('delete from tgroup where user_id = ? and group_id = ?', [user_id, group_id], function (err) {
            console.log('删除好友分组');
            if (err === null) {
                if (this.changes > 0) {
                    console.log('delFriendGroup, 成功, 操作 2');
                    runok2 = true;
                } else {
                    console.log('delFriendGroup, 失败, 操作 2');
                }
            } else {
                console.log('操作 2 错误: delFriendGroup => ', err.message);
            }

            console.log('runok1: ', runok1, 'runok2: ', runok2);

            if (runok1 == true && runok2 == true) {
                console.log('提交事务');
                db.run('COMMIT TRANSACTION');

                res.json({ ok: true, msg: '删除好友分组「' + dirgroup + '」成功!' });
            } else {
                console.log('事务回滚');
                db.run('ROLLBACK TRANSACTION');

                res.json({ ok: false, msg: '删除好友分组「' + dirgroup + '」失败!' });
            }

        });

    });

};


exports.updateDir = function (res, user_id, dirid, updatedir) {

    db.run('update tdir set dir = ? where dir_id = ? and user_id = ? and dir != "未分类"', [updatedir, dirid, user_id], function (err) {
        if (err === null) {
            if (this.changes > 0) {
                res.json({ ok: true, msg: '修改目录「' + updatedir + '」成功' });
            } else {
                res.json({ ok: false, msg: '修改目录「' + updatedir + '」失败' });
            }
        } else {
            console.log('出错：updateDir()更新数据', err.message);
            res.json({ ok: false, msg: '操作错误3' });
        }
    });

};

exports.updateGroup = function (res, user_id, group_id, updategroup) {

    db.run('update tgroup set groupname = ? where group_id = ? and user_id = ? and groupname != "朋友"', [updategroup, group_id, user_id], function (err) {
        if (err === null) {
            if (this.changes > 0) {
                res.json({ ok: true, msg: '修改好友分组「' + updategroup + '」成功' });
            } else {
                res.json({ ok: false, msg: '修改好友分组「' + updategroup + '」失败' });
            }
        } else {
            console.log('出错：updateGroup()更新数据', err.message);
            res.json({ ok: false, msg: '操作错误4' });
        }
    });

};

exports.getDirs = function (res, user_id) {

    db.all("select dir_id, dir from tdir where user_id = ?", [user_id], function (err, rows) {
        if (err === null) {
            console.log('rows => ', rows);
            if (rows.length > 0) {
                return res.json(rows);
            } else {
                return res.end('no', 'utf-8');
            }
        } else {
            console.log('出错：getDirs()查询数据', err.message);
            return res.end('faild', 'utf-8');
        }
    });

};

exports.getTree = function (res, account, user_id, openhome) {

    db.all("select dir_id, dir from tdir where user_id = ?", [user_id], function (err, rows) {
        if (err === null) {
            if (rows.length > 0) {
                return res.render('tree', { layout: 'tree', account: account, uid: user_id, openhome: openhome, rows: rows });
            }
        }
        return res.render('tree', { layout: 'tree', account: account, uid: user_id, openhome: 'unchecked', rows: [] });
    });

};

exports.getGroup = function (res, account, user_id) {

    db.all("select group_id, groupname from tgroup where user_id = ?", [user_id], function (err, rows) {
        console.log('getGroup rows => ', rows);
        if (err === null) {
            if (rows.length > 0) {
                return res.render('friends', { layout: 'friends', account: account, uid: user_id, rows: rows });
            }
        }
        return res.render('friends', { layout: 'friends', account: account, uid: user_id, rows: [] });
    });

};

exports.getFriendGroups = function (res, user_id) {

    db.all("select group_id, groupname from tgroup where user_id = ?", [user_id], function (err, rows) {
        console.log('getMyGroup rows => ', rows);
        if (err === null) {
            if (rows.length > 0) {
                return res.json(rows);
            } else {
                return res.json([]);
            }
        } else {
            return res.json('getMyGgroup() => ', err.message);
        }
    });

};

exports.searchTalk = function (res, user_id, search) {

    db.all("select talk_id, user_id, title, dir_id, create_time from ttalks where user_id = " + user_id + " and talk like '%" + search + "%'", function (err, rows) {
        if (err === null) {
            console.log('searchTalk => ', rows);
            if (rows.length > 0) {
                return res.json(rows);
            } else {
                return res.end(null);
            }
        } else {
            console.log(err.message);
            return res.end(null);
        }
    });

};

exports.getDirItems = function (res, user_id, dir_id, mytype) {

    var sql = '';
    var params = [];
    switch (mytype) {
        case 'tree':
            sql = 'select talk_id, user_id, title, dir_id, create_time from ttalks where user_id = ? and dir_id = ? order by talk_id desc';
            params = [user_id, dir_id];
            break;
        case 'friends':
            sql = 'select friends_id, user_id, group_id, friend, headimg, fuser_id from tfriends where user_id = ? and group_id = ?';
            params = [user_id, dir_id];
            break;
    }

    db.all(sql, params, function (err, rows) {
        if (err === null) {
            console.log('getDirItems => ', rows);
            if (rows.length > 0) {
                return res.json(rows);
            } else {
                return res.end(null);
            }
        } else {
            console.log(err.message);
            return res.end(null);
        }
    });

};

exports.delTalk = function (res, user_id, talkids) {

    console.log('delTalk talkids => ', talkids);
    if(talkids > 0) {
        var sqlin = '(' + talkids + ')';
    } else {
        var sqlin = '(';
        var count = talkids.length;
        for(var i = 0; i < count; i++){
            sqlin += talkids[i] + ',';
            console.log(sqlin);
        }
        sqlin += '0)';
    }

    console.log('sqlin => ', sqlin);

    db.run('delete from ttalks where talk_id in ' + sqlin + ' and user_id = ?', [user_id], function (err) {
        if (err === null) {
            console.log('this.changes = ' + this.changes); // changes == 1
            if (this.changes > 0) {
                res.json({ ok: true, msg: '删除成功' });
            } else {
                res.json({ ok: false, msg: '删除失败' });
            }
        } else {
            console.log('出错: delTalk()删除数据', err.message);
            res.json({ ok: false, msg: '操作错误3' });
        }
    });

};

exports.addTalk = function (res, user_id, title, talk, diridSelect, account, headimg) {

    var time = Date.parse(new Date());
    var openurl = user_id + diridSelect + time;
    db.run('insert into ttalks (user_id, dir_id, title, talk,create_time,islock, isopen, openurl, author, readcount, headimg) values (?,?,?,?,?,?,?,?,?,?,?)'
        , [user_id, diridSelect, title, talk, pub.getTimeNow(), '开', 0 , openurl, account, 0, headimg], function (err, rows) {
        if (err === null) {
            console.log('this.lastID = ' + this.lastID); //lastID == 最后插入行的ID
            console.log('this.changes = ' + this.changes); // changes == 1
            if (this.lastID > 0) {
                res.end(this.lastID.toString(), 'utf-8');
            } else {
                res.end('faild', 'utf-8');
            }
        } else {
            console.log('出错：addTalk()插入数据', err.message);
            res.end('faild', 'utf-8');
        }
    });

};

exports.updateTalk = function (res, user_id, talkid, title, talk, olddirid, diridSelect) {

    db.run('update ttalks set title = ?, talk = ?, dir_id = ?, create_time = ? where talk_id = ? and user_id = ? and dir_id = ?', [title, talk, diridSelect, pub.getTimeNow(), talkid, user_id, olddirid], function (err) {
        if (err === null) {
            if (this.changes > 0) {
                res.end('ok', 'utf-8');
            } else {
                exports.addTalk(res, user_id, talk, diridSelect);
                res.end('no', 'utf-8');
            }
        } else {
            console.log('出错：updateTalk()更新数据', err.message);
            res.end('faild', 'utf-8');
        }
    });

};

// exports.createOpenurl = function (res) {
//     var time = Date.parse(new Date());
//     var openurl = '12' + time;
//     console.log('talkid => ', global.talkid);

//     db.run('update ttalks set openurl = ? where talk_id = ?', [openurl, global.talkid++], function (err) {
//         if (err === null) {
//             if (this.changes > 0) {
//                 res.end('ok', 'utf-8');
//             } else {
//                 res.end('no', 'utf-8');
//             }
//         } else {
//             console.log('出错: createOpenurl()更新数据', err.message);
//             res.end('faild', 'utf-8');
//         }
//     });

// };

exports.updateTalkOpen = function (res, user_id, talkid, openid) {

    db.run('update ttalks set isopen = ?, create_time = ? where talk_id = ? and user_id = ?', [openid, pub.getTimeNow(), talkid, user_id], function (err) {
        if (err === null) {
            if (this.changes > 0) {
                if(openid == 1) {
                    res.json({ ok: true, msg: '已发送到首页', isopen: openid });
                } else {
                    res.json({ ok: true, msg: '已从首页撤回', isopen: openid });
                }
            } else {
                res.json({ ok: false, msg: '设置失败' });
            }
        } else {
            console.log('出错: updateTalkOpen()更新数据', err.message);
            res.json({ ok: false, msg: '设置失败' });
        }
    });

};

function talknors (req, res) {
    var account = req.session && req.session.userData ? req.session.userData.account : '';
    var uid = req.session && req.session.userData ? req.session.userData.user_id : 0;
    res.render('index', { layout: 'index', account: account, uid: uid, talkid: 0, talk: '', dirid: 0, cpage: '', isopen: 0 });
}

exports.getTalk = function (req, res, account, user_id, dirid, talkid, cpage) {

    db.all("select * from ttalks where talk_id = ? and user_id = ? and dir_id = ?", [talkid, user_id, dirid], function (err, rows) {
        if (err === null) {
            console.log('rows => ', rows);
            if (rows.length > 0) {
                var isopen = rows[0].isopen;
                if(isopen != 1){
                    isopen = 0;
                }

                return res.render('index', { layout: 'index', account: account, uid: user_id, talkid: rows[0].talk_id, talk: rows[0].talk, dirid: dirid, cpage: cpage, isopen: isopen, title:rows[0].title });
            } else {
                return talknors (req, res);
            }
        } else {
            console.log('出错：getTalk()查询数据', err.message);
            return talknors(req, res);            
        }
    });

};

exports.indexPage = function (req, res, isnextpage, nextpage) {
    //访问平台首页。将平台所有作家的主页文章，填充到首页平台

    var nums = 10;
    var start = (nextpage - 1) * nums;
    console.log(start, ', ', nums);

    db.all("select * from ttalks where isopen = 1 order by talk_id desc limit ?, ?", [start, nums], function (err, rows) {
        
        var account = req.session && req.session.userData ? req.session.userData.account : '';
        var uid = req.session && req.session.userData ? req.session.userData.user_id : 0;
        
        if (err === null) {
            console.log('indexTalk => ', rows);

            if (rows.length > 0) {
                if(isnextpage == true) {
                    return res.json(rows);
                }

                return res.render('ptindex', {layout:'ptindex', account: account, uid: uid, rows: rows, nomsg: ''});
            }
        } else {
            console.log(err.message);
        }
        if(isnextpage == true) {
            return res.json(null);
        }
        return res.render('ptindex', {layout:'ptindex', account: account, uid: uid, rows: [], nomsg: '暂无记录'});
    });

};

exports.homePage = function (req, res, user_id, isnextpage, nextpage) {
    //将user_id的所有文章，填充到他的首页

    var nums = 10;
    var start = (nextpage - 1) * nums;
    console.log(start, ', ', nums);

    db.all("select * from ttalks where user_id = ? order by talk_id desc limit ?, ?", [user_id, start, nums], function (err, rows) {
        
        var account = req.session && req.session.userData ? req.session.userData.account : '';
        var uid = req.session && req.session.userData ? req.session.userData.user_id : 0;

        if (err === null) {
            console.log('homeTalk => ', rows);

            if (rows.length > 0) {
                if(isnextpage == true) {
                    return res.json(rows);//获取下一页记录
                }
                
                //首次加载页面
                return res.render('home', {layout:'home', account: account, uid: uid, rows: rows, nomsg: ''});
            }
        } else {
            console.log(err.message);
        }
        if(isnextpage == true) {
            return res.json(null);
        }
        return res.render('home', {layout:'home', account: account, uid: uid, rows: [], nomsg: '暂无记录'});
    });

};


exports.openUrl = function (req, res, user_id, openurl) {
    //所有被作者推送到平台首页的文章，任何人都可以访问

    db.all("select * from ttalks where user_id = ? and openurl = ? or isopen = 1 and openurl = ?", [user_id, openurl, openurl], function (err, rows) {
        
        var account = req.session && req.session.userData ? req.session.userData.account : '';
        var uid = req.session && req.session.userData ? req.session.userData.user_id : 0;

        if (err === null) {
            console.log('openUrl rows => ', rows);
            if (rows.length > 0) {
                console.log('更新文章: ', openurl, '的阅读量');
                updateReadCount(openurl);

                return res.render('openpage', { layout: 'openpage', account: account, uid: uid, talkid: rows[0].talk_id, talk: rows[0].talk, author:rows[0].author, create_time:rows[0].create_time, headimg:rows[0].headimg });
            }
        } else {
            console.log('出错: openUrl()查询数据', err.message);
        }
        return res.render('openpage', { layout: 'openpage', account: account, uid: uid, talkid: 0, talk: '', author:'', create_time:'', headimg:'' });
    });

};

function updateReadCount (openurl) {

    db.run('update ttalks set readcount = readcount + 1 where openurl = ?', [openurl], function (err) {
        console.log('updateReadCount changes => ', this.changes);
        if (err === null) {
            if (this.changes > 0) {
                console.log('更新阅读量成功');
            } else {
                console.log('更新阅读量失败');
            }
        } else {
            console.log('更新阅读量错误: ', err.message);
        }
    });

};

exports.regist = function (res, account, psw) {
    db.all("select user_id from tuser where account = ?", [account], function (err, rows) {
        if (err === null) {
            if (rows.length > 0) {
                return res.json({ msg: '账号「' + account + '」已经被使用' });
            } else {
                insertNewAccount(res, account, psw); //向数据库中插入新的记录
            }
        } else {
            console.log('出错：regist()查询数据', err.message);
            return res.json({ msg: '注册失败，请稍后再试' });
        }
    });
};

function insertNewAccount(res, account, psw) {

    var psw_sha1 = jiami.getJiamiCode(psw);

    db.run('insert into tuser (account,psw,dou,isvip,create_time,islock) values (?,?,?,?,?,?)', [account, psw_sha1, 0, 0, pub.getTimeNow(), '开'], function (err, rows) {
        if (err === null) {
            if (this.lastID > 0) {
                insertNewDir(res, this.lastID, '未分类');
            } else {
                return res.json({ msg: '创建账号失败，请稍后再试' });
            }
        } else {
            console.log('出错：insertNewAccount()插入数据', err.message);
            return res.json({ msg: '创建账号失败，请稍后再试' });
        }
    });

}

function insertNewDir(res, user_id, newdir) {

    db.run('insert into tdir (user_id,dir,create_time,islock) values (?,?,?,?)', [user_id, newdir, pub.getTimeNow(), '开'], function (err, rows) {
        if (err === null) {
            console.log('this.lastID = ' + this.lastID); //lastID == 最后插入行的ID
            if (this.lastID > 0) {
                insertNewGroup(res, user_id, '朋友');
            } else {
                return res.json({ msg: '注册失败，请稍后再试' });
            }
        } else {
            console.log('出错：insertNewDir()插入数据', err.message);
            return res.json({ msg: '注册失败，请稍后再试' });
        }
    });

}

function insertNewGroup(res, user_id, newgroup) {

    db.run('insert into tgroup (user_id,groupname,create_time,islock) values (?,?,?,?)', [user_id, newgroup, pub.getTimeNow(), '开'], function (err, rows) {
        if (err === null) {
            if (this.lastID > 0) {
                return res.json({ msg: '注册成功!' });
            } else {
                return res.json({ msg: '注册失败，请稍后再试' });
            }
        } else {
            console.log('出错：insertNewGroup()插入数据', err.message);
            return res.json({ msg: '注册失败，请稍后再试' });
        }
    });

}




exports.addFriendMsg = function (res, msgtype, askacc, askuid, toacc, tomsg, askgroupid) {

    db.all("select user_id from tuser where account = ?", [toacc], function (err, rows) {
        if (err === null) {
            if (rows.length != 1) {
                return res.json({ ok: false, msg: '对方账号名不存在' });
            } else {

                var touid = rows[0].user_id;
                hasFriend(res, msgtype, askacc, askuid, toacc, tomsg, touid, askgroupid);

            }
        } else {
            console.log('出错: addFriendMsg()查询数据', err.message);
            return res.json({ ok: false, msg: '请求消息未成功发送，请稍后再试' });
        }
    });

};

function hasFriend(res, msgtype, askacc, askuid, toacc, tomsg, touid, askgroupid) {
    db.all("select friends_id from tfriends where user_id = ? and friend = ? and fuser_id = ?", [askuid, toacc, touid], function (err, rows) {
        if (err === null) {
            if (rows.length > 0) {
                return res.json({ ok: false, msg: toacc + ' 已经在您的朋友列表' });
            } else {

                hasAddFriendMsg(res, msgtype, askacc, askuid, toacc, tomsg, touid, askgroupid);

            }
        } else {
            console.log('出错: hasFriend()查询数据', err.message);
            return res.json({ ok: false, msg: '请求消息未成功发送，请稍后再试' });
        }
    });
}

function hasAddFriendMsg(res, msgtype, askacc, askuid, toacc, tomsg, touid, askgroupid) {
    db.all("select msg_id from tmsg where askuid = ?", [askuid], function (err, rows) {
        if (err === null) {
            if (rows.length > 0) {
                return res.json({ ok: false, msg: '您已给 ' + toacc + ' 发送过请求' });
            } else {

                getGroupId(res, msgtype, askacc, askuid, toacc, tomsg, touid, askgroupid);

            }
        } else {
            console.log('出错: hasAddFriendMsg()查询数据', err.message);
            return res.json({ ok: false, msg: '请求消息未成功发送，请稍后再试' });
        }
    });
}

function getGroupId(res, msgtype, askacc, askuid, toacc, tomsg, touid, askgroupid) {
    db.all("select group_id from tgroup where user_id = ? and groupname ='朋友'", [askuid], function (err, rows) {
        if (err === null) {
            if (rows.length != 1) {
                return res.json({ ok: false, msg: '默认[朋友]列表不存在' });
            } else {
                if (tomsg == '') {
                    tomsg = '未留言';
                }
                insertFriendMsg(res, msgtype, askacc, askuid, askgroupid, toacc, tomsg, touid);
            }
        } else {
            console.log('出错: getGroupId()查询数据', err.message);
            return res.json({ ok: false, msg: '请求消息未成功发送，请稍后再试' });
        }
    });
}

function insertFriendMsg(res, msgtype, askacc, askuid, askgroupid, toacc, tomsg, touid) {

    db.run('insert into tmsg (msgtype, recvuser, msg, askacc, askuid, askgroupid, thetime) values (?,?,?,?,?,?,?)'
        , [msgtype, toacc, tomsg, askacc, askuid, askgroupid, pub.getTimeNow()], function (err) {
            if (err === null) {
                console.log('this.lastID = ' + this.lastID); //lastID == 最后插入行的ID
                if (this.lastID > 0) {
                    console.log('如果对方在线，将请求加好友的消息发送给他/她');
                    emit(touid, 'askfriend');

                    res.json({ ok: true, msg: '请求消息已发送' });//通知自己操作结果
                } else {
                    res.json({ ok: false, msg: '请求消息未成功发送，请稍后再试' });
                }
            } else {
                console.log('出错: insertFriendMsg()插入数据', err.message);
                res.json({ ok: false, msg: '请求消息发送出错，请稍后再试' });
            }
        });

}

function emit(touid, msgtype, msgdata) {
    var socket = global.socketTable.getValue(touid);
    if (socket && socket.disconnected == false) {
        console.log('被请求加好友的用户在线');
        return socket.emit(msgtype, msgdata);
    }
    console.log('被请求加好友的用户 不在线');
}

exports.getMsgList = function (res, account) {

    db.all("select * from tmsg where recvuser = ? order by msg_id desc", [account], function (err, rows) {
        if (err === null) {
            console.log('rows => ', rows);
            if (rows.length > 0) {
                return res.json(rows);
            } else {
                return res.end(null);
            }
        } else {
            console.log(err.message);
            return res.end(null);
        }
    });

};

exports.refuseAddFriend = function (res, account, msg_id) {
    //拒绝接受加好友，1.删除请求加好友消息；2.通知客户端拒绝结果，并将加好友消息标记为：已拒绝

    db.run('delete from tmsg where recvuser = ? and msg_id = ?', [account, msg_id], function (err) {
        if (err === null) {
            if (this.changes > 0) {
                console.log('通知客户端，已经拒绝了加好友请求');
                res.json({ ok: true, msg: '您已拒绝加好友请求' });
            } else {
                console.log('通知客户端，拒绝操作，失败');
                res.json({ ok: false, msg: '操作错误，请稍后再试' });
            }
        } else {
            console.log('出错: refuseAddFriend()', err.message);
            res.json({ ok: false, msg: '操作错误，请稍后再试' });
        }
    });

};



function hasTheFriend(res, user_id, account, msg_id, group_id, ask_group_id, askacc, askuid) {
    db.all("select friends_id from tfriends where user_id = ? and friend = ? and fuser_id = ?", [user_id, askacc, askuid], function (err, rows) {
        if (err === null) {
            if (rows.length > 0) {
                return res.json({ ok: false, msg: askacc + ' 已经在您的朋友列表' });
            } else {

                acceptAddFriendForTransaction(res, user_id, account, msg_id, group_id, askacc, askuid, ask_group_id);

            }
        } else {
            console.log('出错: hasTheFriend()查询数据', err.message);
            return res.json({ ok: false, msg: '请求消息未成功发送，请稍后再试' });
        }
    });
}

exports.acceptAddFriend = function (res, user_id, account, msg_id, group_id) {
    db.all("select askacc, askuid, askgroupid from tmsg where recvuser = ? and msg_id = ?", [account, msg_id], function (err, rows) {
        console.log('先找出请求信息id为: ', msg_id, ' 的请求加好友用户的用户名和id');
        if (err === null) {
            console.log('acceptAddFriend rows => ', rows);
            if (rows.length == 1) {
                console.log('查找被请求用户默认好友分组，成功')
                var askacc = rows[0].askacc;
                var askuid = rows[0].askuid;
                var ask_group_id = rows[0].askgroupid;

                hasTheFriend(res, user_id, account, msg_id, group_id, ask_group_id, askacc, askuid);

            } else {
                console.log('查找用户的默认好友分组');
                res.json({ ok: false, msg: '您加 ' + askacc + ' 好友不成功, 请稍后再试' });
            }
        } else {
            console.log('错误: acceptAddFriend => ', err.message);
            res.json({ ok: false, msg: '您加 ' + askacc + ' 好友不成功, 请稍后再试' });
        }
    });
}

function acceptAddFriendForTransaction(res, user_id, account, msg_id, group_id, askacc, askuid, ask_group_id) {
    //接受加好友请求：双方将加对方为朋友，并在客户端记录进行标记

    db.serialize(function () {

        var runok1 = false;
        var runok2 = false;
        var runok3 = false;

        db.run('BEGIN TRANSACTION');

        db.run('delete from tmsg where recvuser = ? and msg_id = ?', [account, msg_id], function (err) {
            console.log('删除请求加好友的信息');
            if (err === null) {
                if (this.changes > 0) {
                    console.log('acceptAddFriend, 删除请求消息，成功, 操作 1');
                    runok1 = true;
                } else {
                    console.log('acceptAddFriend, 删除请求消息，失败, 操作 1');
                }
            } else {
                console.log('操作 1 错误: acceptAddFriend => ', err.message);
            }
        });

        db.run('insert into tfriends (user_id, group_id, friend, fheadimg, fuser_id, thetime, islock, black) values (?,?,?,?,?,?,?,?)'
            , [user_id, group_id, askacc, '', askuid, pub.getTimeNow(), false, false], function (err) {
                console.log('先给被请求者加好友');
                if (err === null) {
                    if (this.lastID > 0) {
                        console.log('给被请求者加好友, 成功, 操作 2');
                        runok2 = true;
                    } else {
                        console.log('被请求者加好友, 失败, 操作 2');
                    }
                } else {
                    console.log('操作 2 错误: acceptAddFriend => ', err.message);
                }
            });

        db.run('insert into tfriends (user_id, group_id, friend, fheadimg, fuser_id, thetime, islock, black) values (?,?,?,?,?,?,?,?)'
            , [askuid, ask_group_id, account, '', user_id, pub.getTimeNow(), false, false], function (err) {
                console.log('给请求者加好友');
                if (err === null) {
                    if (this.lastID > 0) {
                        console.log('给请求者加好友, 成功, 操作 3');
                        runok3 = true;
                    } else {
                        console.log('给请求者加好友, 失败, 操作 3');
                    }
                } else {
                    console.log('操作 3 错误: acceptAddFriend => ', err.message);
                }

                console.log('runok1: ', runok1, 'runok2: ', runok2, 'runok3: ', runok3);

                if (runok1 == true && runok2 == true && runok3 == true) {
                    console.log('提交事务');
                    db.run('COMMIT TRANSACTION');

                    console.log('相互将对方从自己的黑名单中删除');
                    pub.removeBlack(user_id, askuid);
                    pub.removeBlack(askuid, user_id);

                    console.log('提示接受方，双方已经加了好友，可以聊天了');
                    res.json({ ok: true, msg: '您已加 ' + askacc + ' 为好友' });
                } else {
                    console.log('事务回滚');
                    db.run('ROLLBACK TRANSACTION');

                    console.log('提示接受方，加好友不成功');
                    res.json({ ok: false, msg: '您加 ' + askacc + ' 好友不成功, 请稍后再试' });
                }
            });

    });

}

exports.delFriend = function (res, user_id, friendsid, fuserid) {

    //删除自己的一个好友，并把自己从对方的好友列表中删除
    db.serialize(function () {

        var runok1 = false;
        var runok2 = false;

        db.run('BEGIN TRANSACTION');

        db.run('delete from tfriends where user_id = ? and friends_id = ?', [user_id, friendsid], function (err) {
            console.log('已从好友列表中删除一个指定id的好友');
            if (err === null) {
                if (this.changes > 0) {
                    console.log('delFriend, 成功, 操作 1');
                    runok1 = true;
                } else {
                    console.log('delFriend, 失败, 操作 1');
                }
            } else {
                console.log('操作 1 错误: delFriend => ', err.message);
            }
        });

        db.run('delete from tfriends where user_id = ? and fuser_id = ?', [fuserid, user_id], function (err) {
            console.log('已把自己从对方好友列表中删除');
            if (err === null) {
                if (this.changes > 0) {
                    console.log('delFriend, 成功, 操作 2');
                    runok2 = true;
                } else {
                    console.log('delFriend, 失败, 操作 2');
                }
            } else {
                console.log('操作 2 错误: delFriend => ', err.message);
            }

            console.log('runok1: ', runok1, 'runok2: ', runok2);

            if (runok1 == true && runok2 == true) {
                console.log('提交事务');
                db.run('COMMIT TRANSACTION');

                console.log('相互加入对方的黑名单，双方就无法相互发送消息');
                pub.addBlack(user_id, fuserid);
                pub.addBlack(fuserid, user_id);

                res.json({ ok: true, msg: '删除好友成功!' });
            } else {
                console.log('事务回滚');
                db.run('ROLLBACK TRANSACTION');

                res.json({ ok: false, msg: '删除好友失败!' });
            }

        });

    });

};

exports.getFriendsList = function (res, user_id, group_id) {

    db.all("select * from tfriends where user_id = ? and group_id = ?", [user_id, group_id], function (err, rows) {
        console.log('getFriendsList rows => ', rows);
        if (err === null) {
            if (rows.length > 0) {
                return res.json(rows);
            } else {
                return res.end(null);
            }
        } else {
            console.log(err.message);
            return res.end(null);
        }
    });

};

exports.moveToGroup = function (res, user_id, friend, group_id) {

    db.run('update tfriends set group_id = ? where user_id = ? and friend = ?', [group_id, user_id, friend], function (err) {
        console.log('moveToGroup changes => ', this.changes);
        if (err === null) {
            if (this.changes > 0) {
                return res.json({ ok: true, msg: '移动成功' });
            } else {
                return res.json({ ok: false, msg: '移动失败, 请稍后再试' });
            }
        } else {
            console.log(err.message);
            return res.end(null);
        }
    });

};

exports.searchAnyFriends = function (res, search) {

    db.all("select * from tuser where account like '%" + search + "%'", function (err, rows) {
        if (err === null) {
            if (rows.length > 0) {
                return res.json(rows);
            } else {
                return res.end(null);
            }
        } else {
            console.log(err.message);
            return res.end(null);
        }
    });

};

exports.searchMyFriends = function (res, user_id, search) {

    db.all("select * from tfriends where user_id = " + user_id + " and friend like '%" + search + "%'", function (err, rows) {
        if (err === null) {
            if (rows.length > 0) {
                return res.json(rows);
            } else {
                return res.end(null);
            }
        } else {
            console.log(err.message);
            return res.end(null);
        }
    });

};




exports.login = function (req, res, account, psw) {

    var psw_sha1 = jiami.getJiamiCode(psw);

    db.all("select * from tuser where account = ? and psw = ? and islock = '开'", [account, psw_sha1], function (err, rows) {
        if (err === null) {
            if (rows.length === 1) {
                console.log('login rows => ', rows);
                var userData = {
                    user_id: rows[0].user_id,
                    account: account,
                    psw: psw,
                    loginTime: pub.getTimeNow(),
                    headimg: rows[0].headimg,
                    openhome: rows[0].openhome
                };
                req.session.cpage = null;
                req.session.userData = userData;
                req.session.save();

                // setHttpCookie(res, userData.account, userData.psw); //登录成功后，设置cookie
                return res.json({ msg: '登录成功', headimg: userData.headimg });
            }
        }
        res.end(null);
    });

};

function setHttpCookie(res, account, psw) {
    var cookie_data = {
        gb: account,
        mb: psw
    };
    res.setHeader('Set-Cookie', ['cookieData=' + JSON.stringify(cookie_data)], { maxAge: 1000 * 60 * 60 * 24 * 365, path: '/', httpOnly: true });
}
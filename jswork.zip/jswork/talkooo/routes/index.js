var express = require('express');
var router = express.Router();
var url = require('url');
var sqlite = require('../code/sqlite');
var pub = require('../code/pub');



router.all('*', function (req, res, next) {
    console.log(' all url => ', req.url);

    // res.header("Access-Control-Allow-Origin", "*");
    // res.header("Access-Control-Allow-Headers", "Content-Type,Content-Length, Authorization, Accept,X-Requested-With");
    // res.header("Access-Control-Allow-Methods", "POST,GET,OPTIONS");
    // res.header("X-Powered-By",' 3.2.1');

    // if(req.method == 'OPTIONS'){
    //     var params = url.parse(req.url, true).query;
    //     console.log('params => ', params['st']);

    //     console.log('return OPTIONS');
    //     return res.sendStatus(200);//让option请求快速返回
    // }

    next();
});

function resIndex(req, res) {
    var hello = '<span class="redcolor">hi, 随手记录点什么吧!</span>';
    var cpage = req.session.cpage == null ? '' : req.session.cpage;

    if (req.session && req.session.userData) {
        var userData = req.session.userData;
        if (req.session.hello) {
            hello = req.session.hello;
            req.session.hello = null;
            req.session.save();
        }
        console.log('cpage2 => ', cpage);

        var dirid = !req.session.currentdirid ? 0 : req.session.currentdirid;
        var layoutdata = { layout: 'index', account: userData.account, uid: userData.user_id, talkid: null, talk: hello, dirid: dirid, cpage: cpage, isopen: 0, title: '编写' };
        console.log('layoutdata => ', layoutdata);
        return res.render('index', layoutdata);
    } else {
        console.log('cpage3 => ', cpage);
        return res.render('index', { layout: 'index', account: '', uid: '', talkid: null, talk: hello, dirid: req.session.currentdirid, cpage: cpage, isopen: 0, title: '编写' });
    }
}

router.get('/', function (req, res) {
    resIndex(req, res);
});

router.get('/logout', function (req, res) {
    if (req.session && req.session.userData) {
        req.session.userData = null;
    }
    return res.redirect('/');
});

// router.get('/uuuuu', function (req, res) {
//     sqlite.createOpenurl(res);
// });



router.get('/openhome', function (req, res) {
    if (!req.session || !req.session.userData) {
        return res.json({ ok: false, msg: '请先登录' });
    }
    var params = url.parse(req.url, true).query;
    var uid = req.session.userData.user_id;
    var checked = params['checked'];
    
    if (checked != pub.escape(checked)) {
        return res.json({ ok: false, msg: '不能包括空格等特殊字符' });
    }
    sqlite.openHome(req, res, uid, checked);
});

router.get('/updateheadurl', function (req, res) {
    if (!req.session || !req.session.userData) {
        return res.json({ ok: false, msg: '请先登录' });
    }
    var params = url.parse(req.url, true).query;
    var uid = req.session.userData.user_id;
    var headurl = params['headurl'];
    
    var newheadurl = decodeURIComponent(headurl);
    // console.log('newheadurl => ', newheadurl);
    if (newheadurl != pub.escape(newheadurl)) {
        return res.json({ ok: false, msg: '目录中不能包括空格等特殊字符' });
    }
    sqlite.updateHeadUrl(res, uid, headurl);
});

router.get('/getheadimg', function (req, res) {
    if (!req.session || !req.session.userData) {
        return res.redirect('/');
    }
    var userData = req.session.userData;
    sqlite.getHeadImg(res, userData.user_id);
});

router.get('/gettime', function (req, res) {
    if (!req.session || !req.session.userData) {
        return res.end();
    }
    var myDate = new Date();
    var mytime = myDate.toLocaleString();
    return res.json({ time: mytime });
});

router.post('/regist', function (req, res) {
    try {
        var account = req.body.account;
        var psw = req.body.psw;
        if (account != pub.escape(account) || psw != pub.escape(psw)) {
            return res.json({ msg: '请不要填写包括空格在内的特殊字符' });
        }
        if (account.length < 1 || account.length > 30) {
            return res.json({ msg: '账号长度应为1-30字符' });
        }
        sqlite.regist(res, account, psw);
    } catch (error) {
        return res.end(null);
    }
});

router.post('/loging', function (req, res) {
    try {
        var account = req.body.account;
        var psw = req.body.psw;
        if (account != pub.escape(account) || psw != pub.escape(psw)) {
            return res.json({ msg: '请不要填写包括空格在内的特殊字符' });
        }
        return sqlite.login(req, res, account, psw);
    } catch (error) {
        console.log(error.message);
        return res.end(null);
    }
});

router.get('/loginAfterSaveHello', function (req, res) {
    //编辑状态下，要登录，登录成功后，将编辑中的文本发送到此接口保存，以便浏览器刷新当前页面后，将此文本发回显示
    if (!req.session || !req.session.userData) {
        return res.end('请先登录!', 'utf-8');
    }
    var params = url.parse(req.url, true).query;
    req.session.hello = params['hello'];
    return res.end('ok');
});


router.get('/changedir', function (req, res) {
    if (!req.session || !req.session.userData) {
        return res.end('请先登录!', 'utf-8');
    }
    var params = url.parse(req.url, true).query;
    var dirid = params['dirid'];

    if (pub.isPlusNumber(dirid) == false) {
        return res.end(null);
    }

    req.session.currentdirid = dirid;
    req.session.save();
    res.end('ok');
});

router.post('/addtalk', function (req, res) {
    if (!req.session || !req.session.userData) {
        return res.end('请先登录!', 'utf-8');
    }
    var params = url.parse(req.url, true).query;
    var uid = req.session.userData.user_id;
    var account = req.session.userData.account;

    var diridSelect = req.body.diridSelect;
    var title = req.body.title;
    var talk = req.body.talk;

    if (pub.isPlusNumber(diridSelect) == false) {
        return res.end('faild', 'utf-8');
    }
    sqlite.addTalk(res, uid, title, talk, diridSelect, account, req.session.userData.headimg);
});

router.post('/updatetalk', function (req, res) {
    if (!req.session || !req.session.userData) {
        return res.end('请先登录!', 'utf-8');
    }
    var params = url.parse(req.url, true).query;
    var uid = req.session.userData.user_id;

    var talkid = req.body.talkid;
    var title = req.body.title;
    var talk = req.body.talk;
    var olddirid = req.body.olddirid;
    var diridSelect = req.body.diridSelect;

    if (pub.isPlusNumber(talkid) == false || pub.isPlusNumber(olddirid) == false || pub.isPlusNumber(diridSelect) == false) {
        return res.end('faild', 'utf-8');
    }
    sqlite.updateTalk(res, uid, talkid, title, talk, olddirid, diridSelect);
});

router.get('/updatetalkopen', function (req, res) {
    if (!req.session || !req.session.userData) {
        return res.json({ ok: false, msg: '请先登录' });
    }
    var params = url.parse(req.url, true).query;
    var uid = req.session.userData.user_id;
    var talkid = params['talkid'];
    var openid = params['openid'];
    
    if (talkid != pub.escape(talkid) || openid != pub.escape(openid)) {
        return res.json({ ok: false, msg: '不能包括空格等特殊字符' });
    }
    openid = openid == '0' ? 1 : 0;
    sqlite.updateTalkOpen(res, uid, talkid, openid);
});


router.get('/adddir', function (req, res) {
    if (!req.session || !req.session.userData) {
        saveCpage(req.session, 'tree');
        return res.json({ ok: false, msg: '请登录' });
    }
    var params = url.parse(req.url, true).query;
    var newdir = params['newdir'];
    var mytype = params['mytype'];

    console.log('mytype: ', mytype);

    if (newdir.length > 20) {
        return res.json({ ok: false, msg: '目录长度不超过20个字符' });
    }
    if (newdir != pub.escape(newdir)) {
        return res.json({ ok: false, msg: '目录中不能包括空格等特殊字符' });
    }

    switch (mytype) {
        case 'tree':
            sqlite.addDir(res, req.session.userData.user_id, newdir);
            break;
        case 'friends':
            sqlite.addFriendGroup(res, req.session.userData.user_id, newdir);
            break;
        default:
            return res.json({ ok: false, msg: '操作错误' });
    }
});

router.get('/deldir', function (req, res) {
    if (!req.session || !req.session.userData) {
        saveCpage(req.session, 'tree');
        return res.json({ ok: false, msg: '请登录' });
    }
    var params = url.parse(req.url, true).query;
    var uid = req.session.userData.user_id;
    var dirid = params['dirid'];
    var dirgroup = params['dirgroup'];
    var mytype = params['mytype'];

    if (pub.isPlusNumber(dirid) == false) {
        return res.json({ ok: false, msg: '操作错误' });
    }

    switch (mytype) {
        case 'tree':
            if (dirgroup == '未分类') {
                return res.json({ ok: false, msg: '禁止删除默认「' + dirgroup + '」分组' });
            }
            sqlite.delDir(res, uid, dirid, dirgroup);
            break;
        case 'friends':
            if (dirgroup == '朋友' || dirgroup == '消息') {
                return res.json({ ok: false, msg: '禁止删除默认「' + dirgroup + '」分组' });
            }
            sqlite.delFriendGroup(res, uid, dirid, dirgroup);
            break;
        default:
            res.json({ ok: false, msg: '操作错误' });
    }
});

router.get('/updatedir', function (req, res) {
    if (!req.session || !req.session.userData) {
        saveCpage(req.session, 'tree');
        return res.json({ ok: false, msg: '请登录' });
    }
    var params = url.parse(req.url, true).query;
    var uid = req.session.userData.user_id;
    var dirid = params['dirid'];
    var updatedir = params['updatedir'];
    var mytype = params['mytype'];

    if (pub.isPlusNumber(dirid) == false) {
        return res.json({ ok: false, msg: '操作错误1' });
    }
    if (updatedir.length > 20) {
        return res.json({ ok: false, msg: '目录长度不超过20个字符' });
    }
    if (updatedir != pub.escape(updatedir)) {
        return res.json({ ok: false, msg: '目录中不能包括空格等特殊字符' });
    }

    switch (mytype) {
        case 'tree':
            if (updatedir == '未分类') {
                return res.json({ ok: false, msg: '默认「' + updatedir + '」目录已存在' });
            }
            sqlite.updateDir(res, uid, dirid, updatedir);
            break;
        case 'friends':
            if (updatedir == '消息') {
                return res.json({ ok: false, msg: '默认「' + updatedir + '」分组已存在' });
            }
            if (updatedir == '朋友') {
                return res.json({ ok: false, msg: '默认「' + updatedir + '」分组已存在' });
            }
            sqlite.updateGroup(res, uid, dirid, updatedir);
            break;
        default:
            res.json({ ok: false, msg: '操作错误2' });
    }
});

router.get('/getdirs', function (req, res) {
    if (!req.session || !req.session.userData) {
        return res.end('faild', 'utf-8');
    }
    var uid = req.session.userData.user_id;
    sqlite.getDirs(res, uid);
});

router.get('/tree', function (req, res) {
    if (!req.session || !req.session.userData) {
        saveCpage(req.session, 'tree');
        return res.redirect('/');
    }
    var userData = req.session.userData;
    sqlite.getTree(res, userData.account, userData.user_id, userData.openhome);
});

function saveCpage(sess, cpage) {
    //session失效但却操作之前已经登录的当前页，重新登录后会跳转到此地址
    //当cpage = null时，表示不用显示登录窗口和跳转到指定地址
    sess.cpage = cpage;
    sess.save();
}

function talknors (req, res) {
    var account = req.session && req.session.userData ? req.session.userData.account : '';
    var uid = req.session && req.session.userData ? req.session.userData.user_id : 0;
    res.render('index', { layout: 'index', account: account, uid: uid, talkid: 0, talk: '', dirid: 0, cpage: '', isopen: 0 });
}

router.get('/tree/:id', function (req, res) {
    var params = req.url.split('/');
    console.log('params => ', params);

    if (params.length == 3 && params[0] == '' && params[1] == 'tree') {
        var ids = params[2].split('-');
        var dirid = ids[0];
        var talkid = ids[1];
        console.log('ids => ', ids);

        if (pub.isPlusNumber(dirid) == false || pub.isPlusNumber(talkid) == false) {
            return talknors (req, res);
        }

        if (!req.session || !req.session.userData) {
            saveCpage(req.session, 'tree/' + dirid + '-' + talkid);
            return res.redirect('/');
        }

        if (req.session.hello) {
            //从目录中打开的文档，编辑后，保存发现session失效，于是弹出登录框，登录成功后，将此编辑后的文本保存到session中, 
            //登录返回，刷新此页面，服务器在此检测到有保存过的编辑文本，于是发送包含此文本的整个页面到浏览器
            var hello = req.session.hello;
            req.session.hello = null;
            req.session.save();
            var userData = req.session.userData;
            return res.render('index', { layout: 'index', account: userData.account, uid: userData.user_id, talkid: talkid, talk: hello, dirid: dirid, cpage: '', isopen: 0 });
        }

        var userData = req.session.userData;
        sqlite.getTalk(req, res, userData.account, userData.user_id, dirid, talkid, '');
    } else {
        return talknors(req, res);
    }
});


function homenors (req, res) {
    var account = req.session && req.session.userData ? req.session.userData.account : '';
    var uid = req.session && req.session.userData ? req.session.userData.user_id : 0;
    res.render('home', {layout:'home', account: account, uid: uid, rows: [], nomsg: '暂无记录'});
}

router.get('/:id/home', function (req, res) {
    if (!req.session || !req.session.userData) {
        return homenors (req, res);
    }
    var params = req.url.split('/');
    console.log('params => ', params);

    if (params.length == 3 && params[0] == '' && params[2] == 'home') {
        var uid = params[1];
        if (pub.isPlusNumber(uid) == false || uid != req.session.userData.user_id) {
            return homenors (req, res);
        }
        sqlite.homePage(req, res, uid, false, 1);
    }
});

router.get('/gethomenextpage', function (req, res) {
    var params = req.url.split('/');
    var params = url.parse(req.url, true).query;
    console.log('params => ', params);

    var uid = params['homeid'];
    var nextpage = params['nextpage'];

    if (pub.isPlusNumber(uid) == false || pub.isPlusNumber(nextpage) == false) {
        console.log('params is unlegal');
        return res.json({ok: false, msg: 'homeid unlegal'});
    }

    var isnextpage = true;
    sqlite.homePage(req, res, uid, isnextpage, nextpage);
});

router.get('/getindexnextpage', function (req, res) {
    var params = req.url.split('/');
    var params = url.parse(req.url, true).query;
    console.log('params => ', params);

    var nextpage = params['nextpage'];

    if (pub.isPlusNumber(nextpage) == false) {
        console.log('params is unlegal');
        return res.json({ok: false, msg: 'homeid unlegal'});
    }

    var isnextpage = true;
    sqlite.indexPage(req, res, isnextpage, nextpage);
});

router.get('/searchtalk', function (req, res) {
    if (!req.session || !req.session.userData) {
        saveCpage(req.session, 'tree');
        return res.end('请先登录!', 'utf-8');
    }
    var params = url.parse(req.url, true).query;
    var stxt = params['stxt'];
    if (stxt != pub.escape(stxt)) {
        return res.end(null);
    }
    sqlite.searchTalk(res, req.session.userData.user_id, stxt);
});

router.get('/diritems', function (req, res) {
    if (!req.session || !req.session.userData) {
        saveCpage(req.session, 'tree');
        return res.end('请先登录!', 'utf-8');
    }
    var params = url.parse(req.url, true).query;
    var uid = req.session.userData.user_id;
    var dirid = params['dirid'];
    var mytype = params['mytype'];

    if (pub.isPlusNumber(dirid) == false) {
        return res.end(null);
    }
    req.session.currentdirid = dirid;
    req.session.save();

    sqlite.getDirItems(res, uid, dirid, mytype);
});

router.get('/deltalk', function (req, res) {
    if (!req.session || !req.session.userData) {
        saveCpage(req.session, 'tree');
        return res.end('请先登录!', 'utf-8');
    }
    var params = url.parse(req.url, true).query;
    var uid = req.session.userData.user_id;
    console.log('params => ', params);
    console.log('params["talkids[]"] => ', params["talkids[]"]);

    var talkids = params["talkids[]"];

    var friendsid = talkids[0];//只准删一个
    var mytype = params['mytype'];
    var fuserid = params['fuserid'];

    var count = talkids.count;
    for(var i = 0; i < count; i++) {
        if (pub.isPlusNumber(talkids[i]) == false) {
            return res.end({ ok: false, msg: '操作错误1' });
        }
    }

    switch (mytype) {
        case 'tree':
            sqlite.delTalk(res, uid, talkids);//可一次删除多个
            break;
        case 'friends':
            if (pub.isPlusNumber(friendsid) == false) {
                return res.end({ ok: false, msg: '操作错误2' });
            }
            sqlite.delFriend(res, uid, friendsid, fuserid);
            break;
        default:
            res.json({ ok: false, msg: '操作错误3' });
    }
});



router.get('/addfriendmsg', function (req, res) {
    if (!req.session || !req.session.userData) {
        return res.end('请先登录!', 'utf-8');
    }
    var params = url.parse(req.url, true).query;
    var askacc = req.session.userData.account;
    var askuid = req.session.userData.user_id;
    var toacc = params['toacc'];
    var tomsg = params['tomsg'];
    var askgroupid = params['askgroupid'];

    var newtoacc = pub.escape(toacc);
    var newtomsg = pub.escape(tomsg);
    var newaskgroupid = pub.escape(askgroupid);

    if (toacc != newtoacc) {
        return res.json({ ok: false, msg: '账号不存在' });
    }

    if (askacc == toacc) {
        return res.json({ ok: false, msg: '不可加自己为好友' });
    }

    if (askgroupid != newaskgroupid) {
        return res.json({ ok: false, msg: '操作错误' });
    }

    sqlite.addFriendMsg(res, 'addfriend', askacc, askuid, newtoacc, newtomsg, askgroupid);
});

router.get('/getmsglist', function (req, res) {
    if (!req.session || !req.session.userData) {
        return res.end('请先登录!', 'utf-8');
    }
    sqlite.getMsgList(res, req.session.userData.account);
});

router.get('/handleaddfrimsg', function (req, res) {
    if (!req.session || !req.session.userData) {
        return res.end('请先登录!', 'utf-8');
    }
    var params = url.parse(req.url, true).query;
    var account = req.session.userData.account;
    var user_id = req.session.userData.user_id;

    var refuseaccept = params['refuseaccept'];
    var msg_id = params['msgid'];
    var group_id = params['groupid'];

    var newrefuseaccept = pub.escape(refuseaccept);
    var newmsgid = pub.escape(msg_id);
    var newgroupid = pub.escape(group_id);

    if (refuseaccept != newrefuseaccept || msg_id != newmsgid || group_id != newgroupid) {
        return res.json({ ok: false, msg: '不可包含非法字符' });
    }

    switch (refuseaccept) {
        case '拒绝':
            sqlite.refuseAddFriend(res, account, msg_id);
            break;
        case '接受':
            sqlite.acceptAddFriend(res, user_id, account, msg_id, group_id);
            break;
        default:
            res.json({ ok: false, msg: '操作错误' });
    }
});

router.get('/getfriendslist', function (req, res) {
    if (!req.session || !req.session.userData) {
        return res.end('请先登录!', 'utf-8');
    }
    var params = url.parse(req.url, true).query;
    var group_id = params['groupid'];
    if (group_id != pub.escape(group_id)) {
        return res.json({ ok: false, msg: '不可包含非法字符' });
    }

    sqlite.getFriendsList(res, req.session.userData.user_id, group_id);
});

router.get('/movetogroup', function (req, res) {
    if (!req.session || !req.session.userData) {
        return res.end('请先登录!', 'utf-8');
    }
    var params = url.parse(req.url, true).query;
    var friend = params['friend'];
    var group_id = params['groupid'];
    if (group_id != pub.escape(group_id)) {
        return res.json({ ok: false, msg: '不可包含非法字符' });
    }

    sqlite.moveToGroup(res, req.session.userData.user_id, friend, group_id);
});




router.get('/searchanyfriends', function (req, res) {
    if (!req.session || !req.session.userData) {
        return res.end('请先登录!', 'utf-8');
    }
    var params = url.parse(req.url, true).query;
    var stxt = params['stxt'];
    if (stxt != pub.escape(stxt)) {
        return res.end(null);
    }
    sqlite.searchAnyFriends(res, stxt);
});

router.get('/searchmyfriends', function (req, res) {
    if (!req.session || !req.session.userData) {
        return res.end('请先登录!', 'utf-8');
    }
    var params = url.parse(req.url, true).query;
    var stxt = params['stxt'];
    if (stxt != pub.escape(stxt)) {
        return res.end(null);
    }
    sqlite.searchMyFriends(res, req.session.userData.user_id, stxt);
});


router.get('/friends', function (req, res) {
    if (!req.session || !req.session.userData) {
        saveCpage(req.session, 'friends');
        return res.redirect('/');
    }
    var userData = req.session.userData;
    sqlite.getGroup(res, userData.account, userData.user_id);
});

router.get('/friendgroups', function (req, res) {
    if (!req.session || !req.session.userData) {
        saveCpage(req.session, 'friends');
        return res.redirect('/');
    }
    var userData = req.session.userData;
    sqlite.getFriendGroups(res, userData.user_id);
});

router.get('/index', function (req, res) {
    var params = req.url.split('/');
    console.log('params => ', params);
    sqlite.indexPage(req, res, false, 1);
});


function openpagenors (req, res) {
    var account = req.session && req.session.userData ? req.session.userData.account : '';
    var uid = req.session && req.session.userData ? req.session.userData.user_id : 0;
    res.render('openpage', { layout: 'openpage', account: account, uid: uid, talkid: 0, talk: '', author:'', create_time:'', headimg:'' });
}

router.get('/:id', function (req, res) {
    //所有未被处理的请求，都由此来处理, 包括带参数请求
    console.log('/:id url => ', req.url);
    var params = req.url.split('/');
    console.log('params => ', params);

    if (params.length == 2 && params[0] == '') {
        var openurl = params[1];
        if (openurl != pub.escape(openurl)) {
            return openpagenors (req, res);
        }
        var uid = req.session && req.session.userData ? req.session.userData.user_id : 0;
        sqlite.openUrl(req, res, uid, openurl);
    }
});


module.exports = router;
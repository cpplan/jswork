var Params = {
    getParam: function (param) {
        var query = window.location.search.substring(1);
        var vars = query.split("&");
        for (var i = 0; i < vars.length; i++) {
            var pair = vars[i].split("=");
            if (pair[0] == param) {
                return decodeURIComponent(pair[1]);
            }
        }
        return;
    }
};

function isPc() {
    var useragent = navigator.userAgent;
    if (useragent.indexOf('Mobile') > -1) {
        return false;
    } else {
        return true;
    }
}

var TalkNs = {

    $loading: null,
    $saveTimer: 0,
    heart: 0,
    LeaveMsg: null,

    init: function () {

        TalkNs.$loading = $('#loading');
        // this.checkLogin();

        $('#loginSpan').click(function () {
            $('.loginWin').show();
            $('#loginForm').show();
            $('#registForm').hide();
            if (isPc() == true) {
                $('#loginacc').focus();
            }
        });

        $('.winClose').click(function () {
            $('.loginWin').hide();
            $('.loginWin input').val('');
        });

        $('#loginbtn').unbind('click').click(function () {
            TalkNs.login();
        });

        $('#toregist').click(function () {
            $('#loginForm').hide();
            $('#registForm').show();
            if (isPc() == true) {
                $('#registacc').val('').focus();
            }
        });

        $('#tologin').click(function () {
            $('#loginForm').show();
            $('#registForm').hide();
            if (isPc() == true) {
                $('#loginacc').val('').focus();
            }
        });

        $('#registbtn').unbind('click').click(function (e) {
            e.stopPropagation();
            TalkNs.regist();
        });

        $('#sendbtn').unbind('click').click(function () {
            TalkNs.sendbtn();
        });

        $('#savebtn').unbind('click').click(function () {
            TalkNs.savebtn();
        });

        $('#titlebtn').unbind('click').click(function () {
            var $this = $(this);
            if ($('#editta').val() == '') {
                return TalkNs.edittaFocusInPc();
            }
            $this.addClass('redcolor');
            TalkNs.sendbtn();
            $this.removeClass('redcolor');
        });

        $('#fxbtn').unbind('click').click(function () {
            TalkNs.unSelected();
            $('#zhxbtn').css({ color: 'black' });
            TalkNs.edittaFocusInPc();
        });

        $('#zhxbtn').unbind('click').click(function () {
            var $selectItem = TalkNs.findSelected();
            if ($selectItem && $selectItem.hasClass('ptxt')) {
                if ($selectItem.hasClass('line-through')) {
                    $selectItem.removeClass('line-through');
                    TalkNs.btnShowRed(null);
                } else {
                    $selectItem.addClass('line-through');
                    TalkNs.setSaveTimer();
                }
                TalkNs.unSelected();
            }
            TalkNs.edittaFocusInPc();
        });

        $('#bigbtn').unbind('click').click(function () {
            var $selectItem = TalkNs.findSelected();
            if ($selectItem && $selectItem.hasClass('ptxt')) {
                if ($selectItem.hasClass('fsize14')) {
                    $selectItem.removeClass('fsize14');
                    TalkNs.btnShowRed(null);
                } else {
                    $selectItem.addClass('fsize14');
                    TalkNs.setSaveTimer();
                }
                TalkNs.unSelected();
            }
            TalkNs.edittaFocusInPc();
        });

        $('#dtopbtn').unbind('click').click(function () {
            var $selectItem = TalkNs.findSelected();
            if ($selectItem && ($selectItem.hasClass('ptxt') || $selectItem.html() != '')) {
                TalkNs.sendbtnfordtop();
            } else {
                alert('请先选择一个段落，才能在其上插入新段落');
                TalkNs.edittaFocusInPc();
            }
        });

        $('#editbtn').unbind('click').click(function () {
            var $selectItem = TalkNs.findSelected();
            if ($selectItem && ($selectItem.hasClass('ptxt') || $selectItem.html() != '')) {
                var $editta = $('#editta');
                if ($editta.attr('title') != '处于修改状态') {
                    $editta.val($selectItem.html()).css({ 'border-color': '#C45220' }).attr({ 'title': '处于修改状态' });
                    $('#sendbtn').text('修改');
                    TalkNs.btnShowRed($(this));

                    var color = $selectItem.css('color');
                    $('#colorSelect').val(color);
                } else {
                    TalkNs.resetToSend($editta);
                    TalkNs.btnShowRed(null);
                }
            }
            TalkNs.edittaFocusInPc();
        });

        $('#downbtn').unbind('click').click(function () {
            var $selectItem = TalkNs.findSelected();
            if ($selectItem && ($selectItem.hasClass('ptxt') || $selectItem.html() != '')) {
                var $editta = $('#editta');
                if ($editta.attr('title') != '处于修改状态') {
                    var talkto = $editta.val();
                    if (talkto != '') {
                        TalkNs.insertTalkto(talkto, 'down');
                    } else {
                        alert('请先填写要插入的内容');
                    }
                } else {
                    alert('请先完成或放弃修改，再插入新行');
                }
            } else {
                alert('请先选定一行');
            }
            TalkNs.edittaFocusInPc();
        });

        $('#upbtn').unbind('click').click(function () {
            var $selectItem = TalkNs.findSelected();
            if ($selectItem && ($selectItem.hasClass('ptxt') || $selectItem.html() != '')) {
                var $editta = $('#editta');
                if ($editta.attr('title') != '处于修改状态') {
                    var talkto = $editta.val();
                    if (talkto != '') {
                        TalkNs.insertTalkto(talkto, 'up');
                    } else {
                        alert('请先填写要插入的内容');
                    }
                } else {
                    alert('请先完成或放弃修改，再插入新行');
                }
            } else {
                alert('请先选定一行');
            }
            TalkNs.edittaFocusInPc();
        });

        $('#dirSelect').change(function () {
            var dir = $('#dirSelect > option:selected').val();
            TalkNs.changeCurrentDirAjax(dir);
            TalkNs.edittaFocusInPc();
        });

        $('#colorSelect').change(function () {
            var $selectItem = TalkNs.findSelected();
            if ($selectItem && $selectItem.hasClass('ptxt')) {
                var color = $('#colorSelect > option:selected').val();
                $selectItem.css({ 'color': color });
                TalkNs.unSelected();
            }
            TalkNs.edittaFocusInPc();
        });


        $('#dirlist').unbind('click').click(function (e) {
            e.stopPropagation();
            var $target = $(e.target);
            if ($target.hasClass('dirspan') == false) {
                return;
            }
            TalkNs.getItemsOfDirlist($target);
        });

        $('#delbtn').unbind('click').click(function () {
            var $selectItem = TalkNs.findSelected();
            if ($selectItem && $selectItem.hasClass('ptxt')) {
                var tip = $selectItem.text();
                tip = tip.length <= 10 ? tip.slice(0, 10) : tip.slice(0, 10) + '...';

                if($selectItem.find('img').length > 0){
                    tip = '图片';
                }
                if (confirm('确定要删除吗? (' + tip + ')')) {
                    var $block = $selectItem.parent().parent();
                    var childs = $block.children().length;

                    if ($selectItem.hasClass('title') == true) {
                        $selectItem.parent().parent().remove();
                    } else {
                        $selectItem.parent().remove();
                    }
                    if (childs == 1) {
                        $block.remove();
                    }

                    $('#fxbtn').css({ 'color': 'black' });

                    TalkNs.resetToSend($('#editta'));
                    TalkNs.setSaveTimer();
                }
            } else {
                $('#ppanel div.block > div.redborder').remove();
            }
            TalkNs.edittaFocusInPc();
        });

        $('#treeOpe > span').unbind('click').click(function () {
            $('#treeOpe > span').css({ color: '' }).removeAttr('data-color');

            var $span = $(this);
            if ($span.attr('data-color')) {
                $span.css({ color: '' }).removeAttr('data-color');
            } else {
                $span.css({ color: '#C40522' }).attr({ 'data-color': 1 });
            }
        });

        $('#dirEdit').unbind('click').click(function () {
            $('#newdirpanel').hide();
            $('#updatedirpanel').show();

            var dirli = $('#dirlist > li > span.redcolor');
            if (dirli.length != 1) {
                return;
            }
            var $li = $(dirli[0]);
            var dir = $li.text();
            $('#updatedir').val(dir);
            if (isPc() == true) {
                $('#updatedir').focus();
            }
        });

        $('#dirMinus').unbind('click').click(function () {
            var dirspan = $('#dirlist > li > span.redcolor');
            if (dirspan.length != 1) {
                return;
            }
            var $dirspan = $(dirspan[0]);
            var dir = $dirspan.text();
            if (dir == '未分类') {
                return alert('禁止删除「未分类」目录');
            }
            if (confirm('确定要删除目录「' + dir + '」, 以及「' + dir + '」下的所有文档吗?')) {
                TalkNs.delDirAjax($dirspan.attr('data-id'), $dirspan.parent(), dir);
            }
        });

        $('#groupEdit').unbind('click').click(function () {
            $('#newdirpanel').hide();
            $('#updatedirpanel').show();

            var groupli = $('#grouplist > li > span.redcolor');
            if (groupli.length != 1) {
                return;
            }
            var $li = $(groupli[0]);
            var dir = $li.text();
            $('#updatedir').val(dir);
            if (isPc() == true) {
                $('#updatedir').focus();
            }
        });

        $('#groupMinus').unbind('click').click(function () {
            var group = $('#grouplist > li > span.redcolor');
            var $group = $(group);
            var $li = $group.parent();
            var id = $li.find('span:nth(0)').attr('data-id');
            if (!id) {
                return;
            }
            var groupname = $group.text();
            if (groupname == '朋友' || groupname == '消息') {
                return alert('禁止删除默认「' + groupname + '」分组');
            }
            if (confirm('确定要删除好友分组「' + groupname + '」, 以及「' + groupname + '」下的所有文档吗?')) {
                TalkNs.delDirAjax(id, $li, groupname);
            }
        });

        $('#dirPlus').unbind('click').click(function () {
            $('#newdirpanel').show();
            $('#updatedirpanel').hide();
            if (isPc() == true) {
                $('#newdir').focus();
            }
        });

        $('#quitDirBtn').unbind('click').click(function () {
            $('#newdir').val('');
            $('#newdirpanel').hide();
            $('#treeOpe > span').css({ color: '' }).removeAttr('data-color');
        });

        $('#quitDirBtn2').unbind('click').click(function () {
            $('#updatedirpanel').hide();
            $('#treeOpe > span').css({ color: '' }).removeAttr('data-color');
        });

        $('#addDirBtn').unbind('click').click(function () {
            var newdir = $('#newdir').val();
            if (newdir == '' || newdir.length > 20) {
                return alert('目录长度须在20字符以内');
            }
            TalkNs.addDirAjax(newdir);
        });

        $('#updateDirBtn').unbind('click').click(function () {
            var updatedir = $('#updatedir').val();
            if (updatedir == '' || updatedir.length > 20) {
                return alert('目录长度须在20字符以内');
            }
            var $dirspan = $('#dirlist > li > span.redcolor');
            if ($dirspan.text() == '未分类') {
                return alert("禁止修改「未分类」目录");
            }
            if (updatedir == $dirspan.text()) {
                return;
            }
            var dirid = $dirspan.attr('data-id');
            TalkNs.updateDirAjax(dirid, updatedir);
        });

        $('#updateGroupBtn').unbind('click').click(function () {
            var updatedir = $('#updatedir').val();
            if (updatedir == '' || updatedir.length > 20) {
                return alert('目录长度须在20字符以内');
            }
            var $dirspan = $('#grouplist > li > span.redcolor');
            var groupname = $dirspan.text();
            if (groupname == '消息' || groupname == '朋友') {
                return alert("禁止修改「" + groupname + "」目录");
            }
            if (updatedir == groupname) {
                return;
            }
            var dirid = $dirspan.attr('data-id');
            TalkNs.updateDirAjax(dirid, updatedir);
        });

        $('#itemckbox').unbind('click').click(function () {
            var ckbox = '<input type="checkbox" class="ckbox ckboxdel">';
            var page = $('#main').attr('data-mytype');
            switch (page) {
                case 'tree':
                    if ($(this).is(':checked')) {
                        $("#rslist > tr > td:nth-child(1)").prepend(ckbox);
                    } else {
                        $("#rslist > tr > td:nth-child(1) > input[type='checkbox'].ckboxdel").remove();
                    }
                    break;
                case 'friends':
                    if ($(this).is(':checked')) {
                        $("#friendslist > tr > td:nth-child(1)").prepend(ckbox);
                    } else {
                        $("#friendslist > tr > td:nth-child(1) > input[type='checkbox'].ckboxdel").remove();
                    }
                    break;
            }
        });

        $('#itemdel').unbind('click').click(function () {
            if ($('#itemckbox').is(':checked')) {
                var page = $('#main').attr('data-mytype');
                switch (page) {
                    case 'tree':
                        var $itemchecked = $("#rslist > tr > td:nth-child(1) > input[type='checkbox']:checked");
                        var talkid = $itemchecked.parent().attr('data-id');
                        break;
                    case 'friends':
                        var $itemchecked = $("#friendslist > tr > td:nth-child(1) > input[type='checkbox']:checked");
                        var talkid = $itemchecked.parent().attr('data-friendid');
                        var fuserid = $itemchecked.parent().attr('data-fuserid');
                        break;
                }

                var count = $itemchecked.length;
                if (count == 0) {
                    return alert('请选择 1 项删除');
                }
                if (count == 1) {
                    var tip = $itemchecked.parent().text();
                    tip = tip.length <= 10 ? tip.slice(0, 10) : tip.slice(0, 10) + '...';
                    if (confirm('确定要删除: ' + tip + ' 吗?')) {
                        TalkNs.delTalkAjax([talkid], $itemchecked.parent().parent(), fuserid);
                    }
                } else {
                    var talkids = [];
                    for(var i = 0; i < count; i++) {
                        var talkid = $itemchecked.eq(i).parent().attr('data-id');
                        talkids.push(talkid);
                    }
                    if (confirm('确定要删除选中的 ' + count + ' 项吗?')) {
                        TalkNs.delTalkAjax(talkids, $itemchecked.parent().parent(), fuserid);
                    }
                }
                
            } else {
                alert('请选择 1 项删除');
            }
        });

        $('#homeckbox').unbind('click').click(function () {
            if ($(this).is(':checked')) {
                var checked = 'checked';
            } else {
                var checked = 'unchecked';
            }
            TalkNs.loadGif();

            $.ajax({
                url: "/openhome",
                type: "get",
                async: true,
                cache: false,
                dataType: "json",
                data: {
                    checked: checked
                },
                success: function (data) {
                    TalkNs.clearLoadGif();
                    if(data.ok == false){
                        alert(data.msg);
                    } else {
                        alert(data.msg);
                    }
                    $('#openhome').attr({'title': data.msg});
                },
                error: function (data) {
                    TalkNs.toLogin(data.responseText);
                }
            });
        });

        $('#searchtree').keypress(function (e) {
            if (e.keyCode == 13) {
                var stxt = $(this).val();
                if (stxt.length > 0 && stxt.length < 20) {
                    TalkNs.searchTalkAjax(stxt);
                }
            }
        });


        $('#addfriendbtn').unbind('click').click(function (e) {
            var $addfriendwin = $('#addfriendwin');
            if ($addfriendwin.hasClass('hide')) {
                $addfriendwin.removeClass('hide');
                if (isPc() == true) {
                    $('#toacc').focus();
                }
                TalkNs.getFriendGroupsAjax($('.grouppanel'));
            } else {
                $addfriendwin.addClass('hide');
            }
        });

        iosBindLoginEnter();

        $('#editta').keydown(function (e) {
            clearTimeout(TalkNs.$saveTimer);
        });

        $('#editta').keypress(function (e) {
            if (e.ctrlKey && e.which == 13) {
                e.returnvalue = false;
                TalkNs.sendbtn();
                return false;
            }
        });

        $('#editta').keypress(function (e) {
            if (e.ctrlKey && e.keyCode == 19) {
                e.returnvalue = false;
                TalkNs.savebtn();
                return false;
            }
        });



        $('#addfirmsg').unbind('click').click(function (e) {
            var toacc = $('#toacc').val();
            var tomsg = $('#tomsg').val();
            if (toacc.length == 0 || toacc.length > 50) {
                return alert('对方账号在50字符以内');
            }
            if (tomsg.length > 30) {
                return alert('留言不超过30个字符');
            }
            var askgroupid = $('.grouppanel > select option:selected').val();
            TalkNs.addFriendMsgAjax(toacc, tomsg, askgroupid);
        });

        $('.friwinClose').click(function () {
            $('.addfriendWin').addClass('hide');
            $('#toacc').val('');
            $('#tomsg').val('');
        });

        $('#msglist').unbind('click').click(function (e) {
            e.stopPropagation();
            $('#groupname').text('消息');

            $(e.target).find('.redpoint').hide();
            TalkNs.getmsglistAjax();
        });

        bindFriendGroup();

        bindMsgboxScroll();

        $('.sendmsgbtn').unbind('click').click(function (e) {
            e.stopPropagation();
            var fuserid = $('.imwin').attr('data-fuserid');
            var $msginput = $('#msginput');
            var msg = $msginput.val();
            if (!fuserid || !msg || msg == '') {
                return;
            }

            $msginput.val('');
            if (isPc() == true) {
                $msginput.focus();
            }

            if (!socket || socket.disconnected == true) {
                var distip = '<div class="distip">您已经离线</div>';
                $('.msgrsbox').append(distip);
                return;
            }
            socket.emit('imsendmsg', { tomsg: msg, fuserid: fuserid });
        });

        iosBindSendMsgEnter();

        $('.backimwin').unbind('click').click(function (e) {
            e.stopPropagation();
            $('.imwin').addClass('hide');
        });

        $('#headimg').unbind('click').click(function (e) {
            var $headurlbox = $('.headurlbox');
            if ($headurlbox.hasClass('hide')) {
                $headurlbox.removeClass('hide');
                if (isPc() == true) {
                    $('#headinput').focus();
                }
            } else {
                $headurlbox.addClass('hide');
            }
            e.stopPropagation();
        });

        $('#changeheadbtn').unbind('click').click(function (e) {
            e.stopPropagation();
            var headurl = $('#headinput').val();
            if (!headurl || headurl == '' || headurl.length < 10 || headurl.length > 250) {
                return alert('新头像链接地址格式不正确');
            }
            $('#headinput').val('');
            TalkNs.updateHeadUrlAjax(headurl);
        });

        $('.headurlbox').unbind('click').click(function (e) {
            e.stopPropagation();
        });


        $('.imgurlbox').unbind('click').click(function (e) {
            e.stopPropagation();
        });

        $('#imgbtn').unbind('click').click(function (e) {
            var $headurlbox = $('.imgurlbox');
            if ($headurlbox.hasClass('hide')) {
                $headurlbox.removeClass('hide');
                if (isPc() == true) {
                    $('#insertimginput').focus();
                }
            } else {
                $headurlbox.addClass('hide');
            }
            e.stopPropagation();
        });

        $('#insertimgbtn').unbind('click').click(function (e) {
            e.stopPropagation();
            var headurl = $('#insertimginput').val();
            if (!headurl || headurl == '' || headurl.length < 10 || headurl.length > 250) {
                return alert('图片链接地址格式不正确');
            }
            $('#insertimginput').val('');
            var talkto = '<img src="' + headurl + '"/>';
            $('#ppanel > span.redcolor:nth-child(1)').remove();
            TalkNs.insertTalkto(talkto, null);
        });

        $('#main').unbind('click').click(function () {
            $('.headurlbox').addClass('hide');
            $('.imgurlbox').addClass('hide');
        });

        $('.mainboard').unbind('click').click(function () {
            $('.headurlbox').addClass('hide');
            $('.imgurlbox').addClass('hide');
        });

        $('#openjt').unbind('click').click(function () {
            var $openjt = $('#openjt');
            var openid = $openjt.attr('data-open');
            var talkid = $('#ppanel').attr('data-id');
            if(talkid){
                TalkNs.updateTalkOpenAjax($openjt, talkid, openid);
            }
        });

    },



    findSelected: function () {
        if ($('#ppanel div.block span.redborder').length > 0) {
            return $('#ppanel div.block span.redborder').eq(0);
        } else {
            return $('#ppanel div.block div.redborder > span.ptxt > a').eq(0);
        }
    },

    sendbtnfordtop: function () {
        var $editta = $('#editta');
        var talkto = $editta.val();
        if (talkto == '') {
            return TalkNs.edittaFocusInPc();;
        }

        if ($editta.attr('title') == '处于修改状态') {
            alert('请先完成或放弃修改，再插入新段落');
            return;
        }

        $('#ppanel > span').remove();
        TalkNs.insertTalkto(talkto, null, true);
        $('#handlepanel').show();
        TalkNs.edittaFocusInPc();
    },

    sendbtn: function () {
        var $editta = $('#editta');
        var talkto = $editta.val();
        if (talkto == '') {
            return;
        }

        if ($editta.attr('title') == '处于修改状态') {
            var $selectItem = TalkNs.findSelected();
            if ($selectItem && ($selectItem.hasClass('ptxt') || $selectItem.html() != '')) {
                $selectItem.html(talkto);
                if ($selectItem.is('a')) {
                    $selectItem.attr({'href':talkto});
                }

                TalkNs.resetToSend($editta, 'issendbtn');
                TalkNs.btnShowRed(null);
                var color = $('#colorSelect > option:selected').val();
                $selectItem.css({ color: color });
                $selectItem.removeClass('redborder');

                TalkNs.setSaveTimer();
                TalkNs.edittaFocusInPc();
            }
            return;
        }

        $('#ppanel > span').remove();
        TalkNs.insertTalkto(talkto, null);
        $('#handlepanel').show();
        TalkNs.edittaFocusInPc();
    },

    savebtn: function () {
        clearTimeout(TalkNs.$saveTimer);

        var uid = $('#headimg').attr('data-uid');
        if (uid == undefined) {
            return $('#loginWin').show();
        }
        var $ppanel = $('#ppanel');
        if ($ppanel.find('.ptxt').length == 0) {
            return alert('请先填写文字');
        }
        TalkNs.loadSaveTalk();
    },

    setSaveTimer: function () {
        clearTimeout(TalkNs.$saveTimer);
        TalkNs.$saveTimer = setTimeout(function () {
            TalkNs.loadSaveTalk('timersave');
        }, 10000);
    },

    loadSaveTalk: function (handsaved) {
        if (isLogin() == false) {
            return false;
        }
        var $ppanel = $('#ppanel');
        var talkid = $ppanel.attr('data-id');
        var title = $('#ppanel > div.block:nth-child(1)').find('span.ptxt').eq(0).text();
        var talk = $ppanel.html();

        var diridSelect = $('#dirSelect > option:selected').val();
        if (talkid == '' || talkid == 'null') {
            TalkNs.addTalkAjax(title, talk, diridSelect, handsaved);
        } else {
            var olddirid = $('#wordlist').attr('data-dirid');
            TalkNs.updateTalkAjax(title, talkid, talk, olddirid, diridSelect, handsaved);
        }
    },

    edittaFocusInPc: function () {
        if (isPc() == true) {
            $('#editta').focus();
            if ($('.loginWin').css('display') == 'block') {
                $('#loginacc').focus();
            }
        }
    },

    saveOK: function () {
        $('#saved').show();
        setTimeout(
            function () {
                $('#saved').hide();
            }, 5000);
    },

    loadGif: function () {
        if (TalkNs.$loading.hasClass('hide')) {
            TalkNs.$loading.removeClass('hide');
        } else {
            TalkNs.$loading.addClass('hide');
        }
    },

    clearLoadGif: function () {
        if (TalkNs.$loading.hasClass('hide') == false) {
            TalkNs.$loading.addClass('hide');
        }
        TalkNs.edittaFocusInPc();
    },


    getDivsByEnter: function (talkto, color) {
        var lines = talkto.split('\n');
        var count = lines.length;
        var divs = '';
        for (var i = 0; i < count; i++) {
            var line = lines[i];
            var headspace = line.substr(0, 8);
            if (headspace == "        ") {
                var div = ' <div class="linehead2em"><span class="ptxt" style="color:' + color + '">' + line + '</span></div>';
            } else {
                headspace = line.substr(0, 4);
                if (headspace == "    ") {
                    var div = ' <div class="linehead1em"><span class="ptxt" style="color:' + color + '">' + line + '</span></div>';
                } else {
                    headspace = line.substr(0, 2);
                    if (headspace == "  ") {
                        var div = ' <div class="lineheadhalfem"><span class="ptxt" style="color:' + color + '">' + line + '</span></div>';
                    } else {
                        var div = ' <div><span class="ptxt" style="color:' + color + '">' + line + '</span></div>';
                    }
                }
            }

            divs += div;
        }
        return divs;
    },

    removeSpaceEnter: function (talkto) {
        return talkto.replace(/ /g, '').replace(/\n/g, '');
    },

    getTime: function () {
        $.ajax({
            url: "/gettime",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {},
            success: function (data) {
                if (data) {
                    $('.sendtime').text(data.time);
                }
            },
            error: function (data) {
                TalkNs.toLogin(data.responseText);
            }
        });
    },

    insertTalkto: function (talkto, pos, dtop) {
        var $ppanel = $('#ppanel');
        var color = $('#colorSelect > option:selected').val();
        var istitle = false;
        if ($('#titlebtn').hasClass('redcolor') == true) {
            if ($ppanel.find('>div.talkTitle').length == 0) {
                var divs = TalkNs.removeSpaceEnter(talkto);
                divs = '<div><span class="ptxt title">' + divs + '</span></div>';

                var author = $('#headimg').attr('title');
                if (!author) {
                    author = '';
                }
                author = '<span class="author">' + author + '</span>';

                var sendtime = '<span class="sendtime"></span>';

                var newp = ' <div class="block talkTitle">' + divs + author + sendtime + '</div>';
                istitle = true;
            } else {
                return alert('已经存在标题了, 可以编辑已有的标题, 或删除后新增');
            }
        } else {
            var divs = TalkNs.getDivsByEnter(talkto, color);
            var httptext = $(divs).text();
            var httplink = TalkNs.removeSpaceEnter(httptext);
            if (httplink.substr(0,7) == 'http://' || httplink.substr(0,8) == 'https://') {
                divs = divs.replace(httplink, '<a href="' + httplink + '" target="_blank">' + httplink + '</a>');
            }

            switch (pos) {
                case 'down':
                    var newp = divs;
                    break;
                case 'up':
                    var newp = divs;
                    break;
                default:
                    var newp = '<div class="block">' + divs + '</div>';
            }
        }

        var $selectItem = TalkNs.findSelected();

        switch (pos) {
            case 'down':
                if ($selectItem && $selectItem.hasClass('ptxt') && $selectItem.hasClass('title') == false) {
                    $selectItem.parent().after(newp);//作为item插入到选中项的下面
                    TalkNs.resetAfterDownUpSend();
                } else if ($selectItem && $selectItem.html() != '' && $selectItem.hasClass('title') == false) {
                    $selectItem.parent().parent().after(newp);//作为item插入到选中项的下面
                    TalkNs.resetAfterDownUpSend();
                }
                break;
            case 'up':
                if ($selectItem && $selectItem.hasClass('ptxt') && $selectItem.hasClass('title') == false) {
                    $selectItem.parent().before(newp);//作为item插入到选中项的上面
                    TalkNs.resetAfterDownUpSend();
                } else if ($selectItem && $selectItem.html() != '' && $selectItem.hasClass('title') == false) {
                    $selectItem.parent().parent().before(newp);//作为item插入到选中项的上面
                    TalkNs.resetAfterDownUpSend();
                }
                break;
            default:
                if (istitle == true) {
                    $ppanel.prepend(newp);
                } else {
                    if ($selectItem && $selectItem.hasClass('ptxt')) {
                        if (dtop == true) {
                            $selectItem.parent().parent().before(newp);//作为block节点插入选中的上方(只往上)
                        } else {
                            $ppanel.append(newp);
                        }
                    } else if ($selectItem && $selectItem.html() != '') {
                        if (dtop == true) {
                            $selectItem.parent().parent().parent().before(newp);//作为block节点插入选中的上方(只往上)
                        } else {
                            $ppanel.append(newp);
                        }
                    } else {
                        $ppanel.append(newp);//作为新block插入到最底部(只往下)（只往上，和只往下，2者配合可以在文档任何地方插入block）
                    }
                }
                TalkNs.resetAfterDownUpSend();
        }

        var author = $('#headimg').attr('title');
        if (author) {
            $('.author').text(author);
        }
        var sendtime = $('.sendtime').text();
        if (sendtime == '') {
            TalkNs.getTime();
        }

        TalkNs.ptextOnClick();
        TalkNs.setSaveTimer();
        TalkNs.edittaFocusInPc();
    },

    getItemsOfDirlist: function ($target) {
        var dirid = $target.attr('data-id');
        if (dirid) {
            $('#dirlist > li > span').removeClass('underline redcolor');
            $target.addClass('underline redcolor');

            var dirname = $target.text();
            $('#updatedir').val(dirname);
            TalkNs.getDirItemsAjax(dirid, dirname);
        }
    },

    ptextOnClick: function () {

        $('#handlepanel').show();

        $('#ppanel').unbind('click').on('click', '.block', function (e) {

            if ($('#editta').attr('title') == '处于修改状态') {
                return false;
            }

            $('#fxbtn').css({ 'color': '#C45220' });
            $('#ppanel .redborder').removeClass('redborder');
            var $target = $(e.target);

            if ($target.is('span') && $target.hasClass('ptxt') == true) {
                $target.addClass('redborder');
            } else if ($target.is('div') && $target.hasClass('block') == false && $target.find('span.ptxt').eq(0).text().length == 0){
                $target.addClass('redborder');
            } else if ($target.is('div') && $target.find('> span.ptxt > a').length > 0) {
                $target.addClass('redborder');
            }

            e.stopPropagation();
        });

    },

    unSelected: function () {
        $('#ppanel .redborder').removeClass('redborder');
        TalkNs.resetToSend($('#editta'));
    },

    showCheckBox: function (showhide) {
        if (showhide) {
            $('#ppanel input.ckbox').removeClass('hide');
        } else {
            $('#ppanel input.ckbox').addClass('hide');
        }
    },

    resetToSend: function ($editta, issendbtn) {
        $editta.val('').css({ 'border-color': '' }).attr({ 'title': '' });
        $('#sendbtn').text('发送');
    },

    resetAfterDownUpSend: function () {
        $('#titlebtn').removeClass('redcolor');
        $('#editta').val('');
    },

    changeCurrentDirAjax: function (dirid) {
        $.ajax({
            url: "/changedir",
            type: "get",
            async: true,
            cache: false,
            dataType: "text",
            data: {
                dirid: dirid
            },
            success: function (data) {
                console.log(data);
            },
            error: function (data) {
            }
        });
    },

    addTalkAjax: function (title, talk, diridSelect, handsaved) {
        if (!handsaved) {
            TalkNs.loadGif();
        }

        $.ajax({
            url: "/addtalk",
            type: "post",
            async: true,
            cache: false,
            dataType: "text",
            data: {
                title: title,
                talk: talk,
                diridSelect: diridSelect
            },
            success: function (data) {
                TalkNs.clearLoadGif();

                if (data == '请先登录!') {
                    TalkNs.showLoginWin();
                } else if (data == 'faild') {
                    alert('保存失败');
                } else {
                    $('#wordlist').attr({ 'data-dirid': diridSelect });
                    $('#ppanel').attr({ 'data-id': data });
                    TalkNs.saveOK();
                }
            },
            error: function (data) {
                TalkNs.toLogin(data.responseText);
            }
        });
    },

    updateTalkAjax: function (title, talkid, talk, olddirid, diridSelect, handsaved) {
        if (!handsaved) {
            TalkNs.loadGif();
        }

        $.ajax({
            url: "/updatetalk",
            type: "post",
            async: true,
            cache: false,
            dataType: "text",
            data: {
                title: title,
                talkid: talkid,
                talk: talk,
                olddirid: olddirid,
                diridSelect: diridSelect
            },
            success: function (data) {
                TalkNs.clearLoadGif();

                if (data == '请先登录!') {
                    TalkNs.showLoginWin()
                } else if (data == 'faild') {
                    alert('保存失败');
                } else if (data == 'no') {
                    alert('编辑的文档可能已被删除, 已重新存入, 请在目录中重新打开');
                } else {
                    $('#wordlist').attr({ 'data-dirid': diridSelect });
                    if (olddirid != diridSelect) {
                        TalkNs.changeUrl(diridSelect);
                    }
                    TalkNs.saveOK();
                }
            },
            error: function (data) {
                TalkNs.toLogin(data.responseText);
            }
        });
    },

    delTalkAjax: function (talkids, $tr, fuserid) {
        TalkNs.loadGif();

        var mytype = $('#main').attr('data-mytype');
        $.ajax({
            url: "/deltalk",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                talkids: talkids,
                mytype: mytype,
                fuserid: fuserid
            },
            success: function (data) {
                TalkNs.clearLoadGif();

                if (data == '请先登录!') {
                    return TalkNs.toLogin(data);
                }

                alert(data.msg);

                switch (mytype) {
                    case 'tree':
                        if (data.ok == true) {
                            $tr.remove();
                            $('#itemnum').text($('#rslist > tr').length);
                        }
                        break;
                    case 'friends':
                        if (data.ok == true) {
                            $tr.remove();
                            $('#itemnum').text($('#friendslist > tr').length);
                        }
                        break;
                }
            },
            error: function (data) {
                TalkNs.toLogin(data.responseText);
            }
        });
    },

    updateTalkOpenAjax: function ($openjt, talkid, openid) {
        TalkNs.loadGif();

        $.ajax({
            url: "/updatetalkopen",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                talkid: talkid,
                openid: openid
            },
            success: function (data) {
                TalkNs.clearLoadGif();
                if(!data){
                    return alert('设置失败');
                }
                if (data.ok == false) {
                    if (data.msg == '请先登录!') {
                        TalkNs.showLoginWin()
                    } else {
                        alert('设置失败');
                    }
                } else {
                    if(data.isopen == 1) {
                        $openjt.attr({'data-open':1}).css({'color':'green'}).attr({'title':'点击后将从首页撤回'});
                    } else {
                        $openjt.attr({'data-open':0}).css({'color':'black'}).attr({'title':'点击后将发送到首页'});
                    }
                    alert(data.msg);
                }
            },
            error: function (data) {
                TalkNs.toLogin(data.responseText);
            }
        });
    },


    addDirAjax: function (newdir) {
        TalkNs.loadGif();
        var mytype = $('#main').attr('data-mytype');
        $.ajax({
            url: "/adddir",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                newdir: newdir,
                mytype: mytype
            },
            success: function (data) {
                TalkNs.clearLoadGif();

                alert(data.msg);
                if (data.ok == false) {
                    return;
                }

                switch (mytype) {
                    case 'tree':
                        var lihtml = '<li><span class="dirspan" data-id="' + data.newdirid + '">' + $('#newdir').val() + '</span></li>';
                        $('#dirlist').append(lihtml);
                        $('#newdir').val('');
                        break;
                    case 'friends':
                        var lihtml = '<li><span class="friendgroup dirspan" data-id="' + data.newgroupid + '">' + $('#newdir').val() + '</span></li>';
                        $('#grouplist').append(lihtml);
                        $('#newdir').val('');
                        bindFriendGroup();
                        break;
                }
            },
            error: function (data) {
                TalkNs.toLogin(data.responseText);
            }
        });
    },

    delDirAjax: function (dirid, $deldir, dirgroup) {
        TalkNs.loadGif();

        var mytype = $('#main').attr('data-mytype');
        $.ajax({
            url: "/deldir",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                dirid: dirid,
                dirgroup: dirgroup,
                mytype: mytype
            },
            success: function (data) {
                TalkNs.clearLoadGif();

                alert(data.msg);

                function resetDirInput() {
                    $('#updatedir').val('');
                    $('#newdir').val('');
                }

                switch (mytype) {
                    case 'tree':
                        if (data.ok == true) {
                            $deldir.remove();
                            resetDirInput();
                            TalkNs.getItemsOfDirlist($('#defaultdir'));
                        }
                        break;
                    case 'friends':
                        if (data.ok == true) {
                            $deldir.remove();
                            resetDirInput();
                            TalkNs.getmsglistAjax();
                        }
                        break;
                }

            },
            error: function (data) {
                TalkNs.toLogin(data.responseText);
            }
        });
    },

    delGroupAjax: function (dirid, $deldir, dir) {
        TalkNs.loadGif();

        var mytype = $('#main').attr('data-mytype');
        $.ajax({
            url: "/deldir",
            type: "get",
            async: true,
            cache: false,
            dataType: "text",
            data: {
                dirid: dirid,
                mytype: mytype
            },
            success: function (data) {
                TalkNs.clearLoadGif();

                if (data == 'faild') {
                    alert('删除目录「' + dir + '」失败, 请先登录');
                    TalkNs.toLogin();
                } else {
                    $deldir.remove();
                    alert('删除目录「' + dir + '」成功!');
                    TalkNs.getItemsOfDirlist($('#defaultdir'));
                }
            },
            error: function (data) {
                TalkNs.toLogin(data.responseText);
            }
        });
    },

    updateDirAjax: function (dirid, updatedir) {
        TalkNs.loadGif();

        var mytype = $('#main').attr('data-mytype');
        $.ajax({
            url: "/updatedir",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                dirid: dirid,
                updatedir: updatedir,
                mytype: mytype
            },
            success: function (data) {
                TalkNs.clearLoadGif();

                alert(data.msg);

                switch (mytype) {
                    case 'tree':
                        if (data.ok == true) {
                            $('#dirlist > li > span.redcolor').text(updatedir);
                            $('#dirname').text(updatedir);
                        }
                        break;
                    case 'friends':
                        if (data.ok == true) {
                            $('#grouplist > li > span.redcolor').text(updatedir);
                            $('#dirname').text(updatedir);
                        }
                        break;
                }
            },
            error: function (data) {
                TalkNs.toLogin(data.responseText);
            }
        });
    },

    getDirItemsAjax: function (dirid, dirname) {
        TalkNs.loadGif();

        var mytype = $('#main').attr('data-mytype');
        $.ajax({
            url: "/diritems",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                dirid: dirid,
                mytype: mytype
            },
            success: function (data) {
                TalkNs.clearLoadGif();

                switch (mytype) {
                    case 'tree':
                        $('#dirname').text(dirname).attr({ 'data-dirid': dirid });
                        TalkNs.handleItemsOfDirOrSearch(data);
                        break;
                    case 'friends':
                        $('#dirname').text(dirname).attr({ 'data-dirid': dirid });
                        TalkNs.handleItemsOfDirOrSearch(data);
                        break;
                }

            },
            error: function (data) {
                TalkNs.toLogin(data.responseText);
            }
        });
    },

    handleItemsOfDirOrSearch: function (data) {
        $('#itemckbox').removeAttr('checked');
        $rslist = $('#rslist');
        if (!data) {
            $('#itemnum').text('0');
            $rslist.empty();
        } else {
            var count = data.length;
            $('#itemnum').text(count);
            var trs = '';
            for (var i = 0; i < count; i++) {
                var row = data[i];
                trs += '<tr>';
                trs += '<td valign="top" data-dirid="' + row.dir_id + '" data-id="' + row.talk_id + '" data-pos="left">' + row.title + '</td>';
                trs += '<td valign="top" data-dirid="' + row.dir_id + '" data-id="' + row.talk_id + '" data-pos="right">' + row.create_time + '</td>';
                trs += '</tr>';
            }
            $rslist.empty().append(trs);


            $rslist.unbind('click').on('click', 'td', function (e) {
                e.stopPropagation();
                var $target = $(e.target);
                var tagname = $target.get(0).tagName;
                if (tagname != 'TD' || $target.text() == '') {
                    return;
                }

                var $td = $(this);
                var url = '/tree/' + $td.attr('data-dirid') + '-' + $td.attr('data-id');
                if ($td.attr('data-pos') == 'left') {
                    window.open(url, '_blank');
                } else {
                    location.href = url;
                }
                return false;
            });
        }
    },

    getDirs: function () {
        var cpage = $('#lmpanel').attr('data-cpage');
        console.log('cpage => ' + cpage);
        if (cpage && cpage != '') {
            TalkNs.showLoginWin();
            return;
        }
        var uid = $('#headimg').attr('data-uid');
        if (!uid) {
            console.log('22222222222222');
            return;
        }

        TalkNs.loadGif();

        $.ajax({
            url: "/getdirs",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                uid: uid
            },
            success: function (data) {
                TalkNs.clearLoadGif();

                if (data == 'faild') {
                    alert('获取失败');
                } else if (data == 'no') {
                    alert('没有数据');
                } else {
                    var olddirid = $('#wordlist').attr('data-dirid');
                    var options = '';
                    var count = data.length;
                    for (var i = 0; i < count; i++) {
                        var item = data[i];
                        if (item.dir_id == olddirid) {
                            options += '<option selected="selected" value="' + item.dir_id + '">' + item.dir + '</option>';
                        } else {
                            options += '<option value="' + item.dir_id + '">' + item.dir + '</option>';
                        }
                    }
                    $('#dirSelect').empty().html(options);
                }
            },
            error: function (data) {
                TalkNs.toLogin(data.responseText);
            }
        });
    },

    searchTalkAjax: function (stxt) {
        TalkNs.loadGif();

        $.ajax({
            url: "/searchtalk",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                stxt: stxt
            },
            success: function (data) {
                TalkNs.clearLoadGif();

                $('#dirname').text('搜索结果').attr({ 'data-dirid': '' });
                TalkNs.handleItemsOfDirOrSearch(data);
                $('#dirlist > li > span').removeClass('underline redcolor');
                $('#updatedir').val('');
            },
            error: function (data) {
                TalkNs.toLogin(data.responseText);
            }
        });
    },

    changeUrl: function (newdirid) {
        var arr = window.location.href.split('/');
        if (arr.length != 5) {
            return;
        }
        var params = arr[4].split('-');
        if (params.length != 2 || newdirid == params[0]) {
            return;
        }
        var newurl = window.location.origin + '/' + arr[3] + '/' + newdirid + '-' + params[1];
        history.replaceState(null, null, newurl);
    },

    btnShowRed: function ($redbtn) {
        $('#redspan > span').css({ color: '' });
        if ($redbtn != null) {
            $redbtn.css({ color: '#C40522' });
        }
    },


    toLogin: function (responseText) {
        TalkNs.clearLoadGif();
        if (responseText != 'faild') {
            alert(responseText);
        }
        location.href = '/';
    },



    showLoginWin: function () {
        $('.loginWin').show();
        if (isPc() == true) {
            $('#loginacc').focus();
        }
    },

    checkLogin: function () {
        var cookie = this.getCookieObjByName('cookieData');
        if (cookie && cookie.account && cookie.psw) {
            this.loginAjax(cookie.account, cookie.psw);
        } else {
            TalkNs.showLoginWin();
        }
    },

    checkSidForLogin: function () {
        var cookieObj = this.getCookieObjByName('accMD5');
        if (cookieObj && cookieObj.account && cookieObj.psw) {
            this.sendSessionId(cookieObj.session_id, 'wx');
        } else {

        }
    },

    getCookieObjByName: function (name) {
        var cookies = document.cookie;
        var cookieArr = cookies.split(';');
        var count = cookieArr.length;
        if (count == 0) {
            return null;
        }
        for (var i = 0; i < count; i++) {
            var oneCookieStr = cookieArr[i];
            var oneCookie = oneCookieStr.split('=');
            if (oneCookie.length != 2) {
                return null;
            }
            var cookieName = oneCookie[0];
            var cookieStr = oneCookie[1];
            if (name == cookieName) {
                return JSON.parse(decodeURIComponent(cookieStr));
            }
        }
        return null;
    },

    login: function () {
        var account = $('#loginacc').val();
        var psw = $('#loginpsw').val();
        if (account.length < 1 || account.length > 30) {
            alert('账号长度应为1-30字符');
            return;
        }
        if (psw.length < 6 || psw.length > 16) {
            alert('密码长度应为6-16字符');
            return;
        }
        $('#loginbtn').css({ 'background-color': 'silver' });
        this.loginAjax(account, psw);
    },

    regist: function () {
        var account = $('#registacc').val();
        var psw = $('#registpsw').val();
        if (account.length < 1 || account.length > 30) {
            alert('账号长度应为1-30字符');
            return;
        }
        if (psw.length < 6 || psw.length > 16) {
            alert('密码长度应为6-16字符');
            return;
        }
        this.registAjax(account, psw);
    },

    loginAjax: function (account, psw) {
        $.ajax({
            url: "/loging",
            type: "post",
            async: true,
            cache: false,
            dataType: "JSON",
            data: {
                account: account,
                psw: psw
            },
            success: function (data) {
                if (!data) {
                    alert('帐号或密码错误');
                } else {
                    if (data.msg == '登录成功') {
                        $('#loginpsw').val('');

                        var cpage = $('#lmpanel').attr('data-cpage');
                        if (cpage && cpage != '') {
                            return location.href = cpage;
                        }

                        var talk = $('#ppanel').html();
                        if (talk && talk.indexOf('<span class="redcolor">hi, 随手记录点什么吧!</span>') == -1) {
                            TalkNs.loginAfterSaveHello(talk);
                        } else {
                            window.location.reload();
                        }
                    } else {
                        alert(data.msg);
                    }
                }
                $('.loginForm input:nth(1)').focus();
                $('#loginbtn').css({ 'background-color': '#C40522' });
            },
            error: function (data) {
                // alert(data.responseText);
            }
        });
    },

    getHeadImgAjax: function () {
        if (isLogin() == false) {
            return false;
        }
        $.ajax({
            url: "/getheadimg",
            type: "get",
            async: true,
            cache: false,
            dataType: "JSON",
            data: {
            },
            success: function (data) {
                if (data && data.ok == true && data.headimg) {
                    $('#headimg').css({ 'background-image': 'url(' + data.headimg + ')' });
                }
            },
            error: function (data) {
                // alert(data.responseText);
            }
        });
    },

    loginAfterSaveHello: function (hello) {
        $.ajax({
            url: "/loginAfterSaveHello",
            type: "get",
            async: true,
            cache: false,
            dataType: "text",
            data: {
                hello: hello
            },
            success: function () {
                window.location.reload();
            },
            error: function (data) {
                alert(data.responseText);
            }
        });
    },

    registAjax: function (account, psw) {
        $.ajax({
            url: "/regist",
            type: "post",
            async: true,
            cache: false,
            dataType: "JSON",
            data: {
                account: account,
                psw: psw
            },
            success: function (data) {
                if (data && data.msg == '注册成功!') {
                    alert(data.msg);
                    $('#loginForm').show();
                    $('#registForm').hide();
                    $('.loginWin input').val('');
                    if (isPc() == true) {
                        $('#loginacc').focus();
                    }
                } else {
                    alert(data.msg);
                }
            },
            error: function (data) {
                console.log('regist => ', data);
                alert(data.responseText);
            }
        });
    },


    addFriendMsgAjax: function (toacc, tomsg, askgroupid) {
        TalkNs.loadGif();

        $.ajax({
            url: "/addfriendmsg",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                toacc: toacc,
                tomsg: tomsg,
                askgroupid: askgroupid
            },
            success: function (data) {
                TalkNs.loadGif();
                if (!data) {
                    alert('网络忙，请稍后再试');
                } else {
                    if (data.ok == true) {
                        alert(data.msg);
                        $('#toacc').val('');
                        $('#tomsg').val('');
                    } else {
                        alert(data.msg);
                    }
                }
            },
            error: function (data) {
                TalkNs.loadGif();
            }
        });
    },

    getmsglistAjax: function () {
        TalkNs.loadGif();

        $.ajax({
            url: "/getmsglist",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            success: function (data) {
                TalkNs.loadGif();

                $('#groupname').text('消息');

                $('#msglist span').addClass('redcolor');
                $('.friendgroup').removeClass('redcolor');

                $msgrslist = $('#msgrslist');
                $msgrslist.removeClass('hide');
                $('#friendslist').addClass('hide');

                if (!data) {
                    // $('#itemnum').text(0);
                    // $msgrslist.empty();
                    return console.log('no add friend msg');
                }
                // console.log(data);
                var count = data.length;
                $('#itemnum').text(count);

                var trs = '';
                var btns = '';
                for (var i = 0; i < count; i++) {
                    var row = data[i];
                    if (row.msgtype == 'addfriend') {
                        btns = '<div class="fribtns hide"><button>拒绝</button><button>接受</button></div>';
                    }
                    trs += '<tr>';
                    trs += '<td valign="top" class="oneaddfrimsg" data-msgid="' + row.msg_id + '" data-msgtype="' + row.msgtype + '" data-askuid="' + row.askuid + '" data-pos="left"><div>' + row.askacc + ': ' + row.msg + '</div>' + btns + '</td>';
                    trs += '<td valign="top" data-msgid="' + row.msg_id + '" data-pos="right"><div>' + row.thetime + '</div></td>';
                    trs += '</tr>';
                }
                if (count > 0) {
                    var oldlen = $('#itemnum').text();
                    var newlen = parseInt(oldlen) + count;
                    $('#itemnum').text(newlen);
                    $msgrslist.empty().append(trs);
                }


                $('.oneaddfrimsg').unbind('click').on('click', function (e) {
                    e.stopPropagation();
                    var $target = $(e.target);
                    var tagname = $target.get(0).tagName;

                    if (tagname == 'DIV') {
                        var $this = $(this);
                        var $select = $this.find('select');
                        if ($select.length > 0) {
                            if ($select.hasClass('hide')) {
                                $select.removeClass('hide');
                            } else {
                                $select.addClass('hide');
                            }
                        }

                        if ($target.parent().find('.fribtns').hasClass('hide')) {
                            $target.parent().find('.fribtns').removeClass('hide');
                            TalkNs.getFriendGroupsAjax($(this));
                        } else {
                            $target.parent().find('.fribtns').addClass('hide');
                        }
                        return;
                    }

                    if (tagname == 'BUTTON') {
                        var msgid = $target.parent().parent().attr('data-msgid');
                        var groupid = $target.parent().parent().find('select option:selected').val();
                        return TalkNs.handleAddfriMsg($target.text(), msgid, groupid, $target);
                    }
                });
            },
            error: function (data) {
                TalkNs.toLogin(data.responseText);
            }
        });
    },

    getfriendslistAjax: function (groupid) {
        TalkNs.loadGif();

        $.ajax({
            url: "/getfriendslist",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                groupid: groupid
            },
            success: function (data) {
                TalkNs.loadGif();

                $friendslist = $('#friendslist');

                if (!data) {
                    $('#itemnum').text(0);
                    $friendslist.empty();
                    return console.log('no msg');
                }
                // console.log(data);
                var count = data.length;
                $('#itemnum').text(count);

                var trs = '';
                for (var i = 0; i < count; i++) {
                    var row = data[i];

                    var hasin = hasInFriend($friendslist, row.fuser_id);
                    if (hasin == true) {
                        continue;
                    }

                    movebtn = '<div class="movebtn hide"><button>移动</button></div>';

                    trs += '<tr>';
                    trs += '<td valign="top" class="friend" data-friendid="' + row.friends_id + '" data-fuserid="' + row.fuser_id + '" data-groupid="' + row.group_id + '" data-pos="left"><div class="myfriendclick"><span class="friendacc">' + row.friend + '</span></div>' + '</td>';
                    trs += '<td valign="top" class="friendoption" data-groupid="' + row.group_id + '" data-pos="right"><div class="thetime">' + row.thetime + '</div>' + movebtn + '</td>';
                    trs += '</tr>';
                }
                $friendslist.removeClass('hide');
                $('#msgrslist').addClass('hide');
                $friendslist.append(trs);

                bindForMyFriend();
            },
            error: function (data) {
                TalkNs.toLogin(data.responseText);
            }
        });
    },

    handleAddfriMsg: function (handle, msgid, groupid, $target) {
        TalkNs.loadGif();

        $.ajax({
            url: "/handleaddfrimsg",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                refuseaccept: handle,
                msgid: msgid,
                groupid: groupid
            },
            success: function (data) {
                TalkNs.loadGif();
                if (!data) {
                    alert('网络忙，请稍后再试');
                } else {
                    if (data.ok == true) {
                        alert(data.msg);
                        $target.parent().parent().parent().remove();
                    } else {
                        alert(data.msg);
                    }
                }
            },
            error: function (data) {
                TalkNs.loadGif();
            }
        });
    },

    loadImWinByLeaveMsg: function (fuserid, fuseracc) {
        if (TalkNs.LeaveMsg) {
            var count = TalkNs.LeaveMsg.length;
            var leavemsgdiv = '';
            for (var i = 0; i < count; i++) {
                var lmsgarr = TalkNs.LeaveMsg[i];
                var lmsg = lmsgarr[0];
                if (lmsg.senderuid == fuserid) {

                    var lmsglen = lmsgarr.length;
                    for (var n = 0; n < lmsglen; n++) {
                        var onemsg = lmsgarr[n];
                        var facc = onemsg.senderacc;
                        var msg = onemsg.msg;

                        leavemsgdiv += '<div class="imone imleft">' +
                            '<div class="imacc">' + facc + ' ' + getTimeNow() + '</div>' +
                            '<div class="immsg">' + msg + '</div>' +
                            '</div>';

                    }

                    $('.msgrsbox').append(leavemsgdiv);
                    TalkNs.LeaveMsg.splice(i, 1);
                    break;

                }
            }

        }

        $('.imwin').attr({ 'data-fuserid': fuserid }).attr({ 'data-fuseracc': fuseracc }).removeClass('hide');
        $('.imwin .msgtip').text('好友: ' + fuseracc);

        if (isPc() == true) {
            $('#msginput').focus();
        }

        socket.emit('readedlmsg', { fuserid: fuserid });
    },

    getFriendGroupsAjax: function ($optionpanel, currentgroupip) {
        $.ajax({
            url: "/friendgroups",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {},
            success: function (data) {
                // console.log('friendgroups => ', data);
                if (!data || data.length == 0) {
                    alert('没有获取到您的朋友分组');
                } else {
                    //获取到朋友分组后，将其加载到指定地方
                    var count = data.length;
                    var options = '';
                    for (var i = 0; i < count; i++) {
                        var group = data[i];
                        var groupid = group.group_id;
                        var groupname = group.groupname;
                        if (groupid == currentgroupip) {
                            options += '<option selected="selected" value="' + groupid + '">' + groupname + '</option>';
                        } else {
                            options += '<option value="' + groupid + '">' + groupname + '</option>';
                        }
                    }
                    var select = '<select>' + options + '</select>';
                    var $select = $optionpanel.find('select');
                    if ($select.length == 0) {
                        $optionpanel.append(select);
                    } else {
                        $select.remove();
                        $optionpanel.append(select);
                    }
                }
            },
            error: function (data) {
                TalkNs.toLogin(data.responseText);
            }
        });
    },

    moveToGroupAjax: function (friend, groupid, $currenttr) {
        $.ajax({
            url: "/movetogroup",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                friend: friend,
                groupid: groupid
            },
            success: function (data) {
                if (!data) {
                    alert('操作不成功，请稍后再试');
                } else {
                    if (data.ok == false) {
                        alert(data.msg);
                    } else {
                        alert(data.msg);
                        $currenttr.remove();
                    }
                }
            },
            error: function (data) {
                TalkNs.toLogin(data.responseText);
            }
        });
    },

    updateHeadUrlAjax: function (headurl, handsaved) {
        if (!handsaved) {
            TalkNs.loadGif();
        }

        $.ajax({
            url: "/updateheadurl",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                headurl: headurl
            },
            success: function (data) {
                TalkNs.clearLoadGif();

                if (!data || data.ok == false) {
                    if (data.msg == '请先登录!') {
                        TalkNs.showLoginWin()
                    } else {
                        alert(data.msg);
                    }
                } else {
                    $('#headimg').css({ 'background-image': 'url(' + headurl + ')' });
                    $('.headinput').val('');
                    $('.headurlbox').addClass('hide');
                }
            },
            error: function (data) {
                TalkNs.toLogin(data.responseText);
            }
        });
    },

};

$(document).ready(function () {
    TalkNs.init();
});


var socket;
var mytimes = 0;

function connectInit() {

    if (!socket) {
        socket = io('', { 'reconnection': false });

        socket.on('connect', function () {
            console.log('connect success');
            socket.emit('ready');

            clearInterval(TalkNs.heart);
            TalkNs.heart = setInterval(function () {
                var senderacc = $('#headimg').attr('title');
                socket.emit('heart', { senderacc: senderacc });
            }, 20000);
        });

        socket.on('backheart', function (data) {
            // console.log('backheart');
        });

        socket.on('error', function (data) {
            console.log('connect error => ' + data);
        });

        socket.on('disconnect', function () {
            // alert('网络连接已断开');
            socket.connect();
            console.log('开始重新连接');
        });

        socket.on('askfriend', function () {
            TalkNs.getmsglistAjax();
        });

        socket.on('getmyleavemsg', function (data) {
            console.log(data);
            TalkNs.LeaveMsg = data;

            var count = data.length;
            if (count != 1) {
                return;
            }
            $('#itemnum').text(count);
            $msgrslist = $('#msgrslist');

            var lastindex = data[0].length - 1;
            var senderuid = 0;
            var senderacc = '';
            var lastmsg = '';

            var trs = '';
            var row = data[0][lastindex];
            trs += '<tr>';
            trs += '<td valign="top" class="friend" data-friendid="' + row.friendid + '" data-fuserid="' + row.senderuid + '" data-groupid="' + row.group_id + '" data-pos="left"><div class="myfriendclick"><span class="friendacc">' + row.senderacc + '</span><span class="leavemsg"> : ' + row.msg + '</span></div>' + '</td>';
            trs += '<td valign="top" data-msgid="' + row.msg_id + '" data-pos="right">' + row.thetime + '</td>';
            trs += '</tr>';
            senderuid = row.senderuid;
            senderacc = row.senderacc;
            lastmsg = row.msg;

            //先找到消息列表中是否存在接收消息的用户，存在：直接将最后一条消息附加在此用户右边；不存在：创建此用户记录，并加入消息列表
            var friends = $('#msgrslist span.friendacc');
            var $sendfriend = findFriendFromMsgrsList(friends, senderacc);
            if ($sendfriend) {
                $sendfriend.parent().find('.leavemsg').text(' : ' + lastmsg);
            } else {
                $msgrslist.append(trs);
            }

            if ($('.imwin').hasClass('hide') == false && senderuid > 0 && senderacc != '') {
                TalkNs.loadImWinByLeaveMsg(senderuid, senderacc);
            }


            $('.myfriendclick').unbind('click').on('click', function (e) {
                e.stopPropagation();
                var $this = $(this);
                var fuserid = $this.parent().attr('data-fuserid');
                var fuseracc = $this.find('.friendacc').text();

                TalkNs.loadImWinByLeaveMsg(fuserid, fuseracc);
            });

        });

        socket.on('sendmsgback', function (data) {
            if (data.online == false) {
                console.log('对方不在线');
            } else {
                console.log('对方在线');
            }
            var sendmsgdiv = '<div class="imone imright">' +
                '<div class="imacc">' + getTimeNow() + ' ' + data.sendmsg.senderacc + '</div>' +
                '<div class="immsg">' + data.sendmsg.msg + '</div>' +
                '</div>';
            var $msgbox = $('.msgbox');
            $msgbox.css({ overflow: 'hidden' });
            $('.msgrsbox').append(sendmsgdiv);
            window.isbottom = true;
            setScroll($msgbox);
        });

        socket.on('sendmsgblack', function () {
            var distip = '<div class="distip">请先加好友</div>';
            $('.msgrsbox').append(distip);

            var $msgbox = $('.msgbox');
            $msgbox.css({ overflow: 'hidden' });
            // $('.msgrsbox').append(distip);
            window.isbottom = true;
            setScroll($msgbox);
        });

        socket.on('recvmsg', function (data) {
            if (data) {
                console.log('收到他人发送来的信息');

                var $friend = findFriend($('#friendslist'), data.senderuid);

                var $msgrslist = $('#msgrslist');
                if ($msgrslist.hasClass('hide') == false) {

                    console.log('处于消息分组');
                    if($('.imwin').hasClass('hide') == true){
                        $('#msglist > span > span.redpoint').show();
                    }

                    var $friendmsglm = findFriend($msgrslist, data.senderuid);
                    if ($friendmsglm) {
                        console.log('消息列表中，存在此发送消息的用户。在消息列表中添加收到的用户消息');
                        if ($friendmsglm.find('.leavemsg').length == 0) {
                            $friendmsglm.find('.myfriendclick').append('<span class="leavemsg"> : ' + data.msg + '</span>');
                        } else {
                            $friendmsglm.find('.leavemsg').text(' : ' + data.msg);
                        }
                    } else {
                        console.log('消息列表中，不存在此发送消息的用户。创建此用户代码，并添加到消息列表');
                    }

                    if ($friend) {
                        console.log('好友分组中，接收消息的好友已被加载过，将消息附加到此发送用户');
                        if ($friend.find('.leavemsg').length == 0) {
                            $friend.find('.myfriendclick').append('<span class="leavemsg"> : ' + data.msg + '</span>');
                        } else {
                            $friend.find('.leavemsg').text(' : ' + data.msg);
                        }

                        //先找到消息列表中是否存在接收消息的用户，存在：直接将最后一条消息附加在此用户右边；不存在：创建此用户记录，并加入消息列表
                        var friends = $('#msgrslist span.friendacc');
                        var $sendfriend = findFriendFromMsgrsList(friends, data.senderacc);
                        if ($sendfriend) {
                            $sendfriend.parent().find('.leavemsg').text(' : ' + data.msg);
                        } else {
                            var friendtr = $friend.parent().parent().html();
                            $msgrslist.append(friendtr);
                        }

                    } else {
                        console.log('好友分组中，发送消息的好友还未被加载，消息将不附加到此发送用户');
                    }
                    bindForMyFriend();

                } else {

                    console.log('处于好友分组');
                    if ($friend) {

                        console.log('且好友已经被加载过');
                        if ($friend.find('.leavemsg').length == 0) {
                            $friend.find('.myfriendclick').append('<span class="leavemsg"> : ' + data.msg + '</span>');
                        } else {
                            $friend.find('.leavemsg').text(' : ' + data.msg);
                        }
                        // var groupid = $friend.attr('data-groupid');

                        //先找到消息列表中是否存在接收消息的用户，存在：直接将最后一条消息附加在此用户右边；不存在：创建此用户记录，并加入消息列表
                        var friends = $('#msgrslist span.friendacc');
                        var $sendfriend = findFriendFromMsgrsList(friends, data.senderacc);
                        if ($sendfriend) {
                            $sendfriend.parent().find('.leavemsg').text(' : ' + data.msg);
                        } else {
                            var friendtr = $friend.parent().parent().html();
                            $msgrslist.append(friendtr);
                            bindForMyFriend();
                        }

                    } else {
                        console.log('好友还没有被加载过');
                    }

                }


                var recvmsgdiv = '<div class="imone imleft">' +
                    '<div class="imacc">' + data.senderacc + ' ' + getTimeNow() + '</div>' +
                    '<div class="immsg">' + data.msg + '</div>' +
                    '</div>';
                var $msgbox = $('.msgbox');
                $msgbox.css({ overflow: 'hidden' });//防止不停的出现滚动条
                $('.msgrsbox').append(recvmsgdiv);
                setScroll($msgbox);
            }
        });

        socket.on('readedlmsgback', function (data) {
            if (TalkNs.LeaveMsg) {
                var count = TalkNs.LeaveMsg.length;
                for (var i = 0; i < count; i++) {
                    var lmsgarr = TalkNs.LeaveMsg[i];
                    var lmsg = lmsgarr[0];
                    if (lmsg.senderuid == data.fuserid) {
                        TalkNs.LeaveMsg.splice(i, 1);
                        break;
                    }
                }
            }
        });

    }

}

function findFriend($tbodylist, senderuid) {
    var $friends = $tbodylist.find('> tr > td.friend');
    if (!$friends) {
        return;
    }
    var count = $friends.length;
    for (var i = 0; i < count; i++) {
        var $friend = $($friends[i]);
        var fuserid = $friend.attr('data-fuserid');
        if (fuserid == senderuid) {
            return $friend;
        }
    }
}

function hasInFriend($tbodylist, frienduid) {
    var $friends = $tbodylist.find('> tr > td.friend');
    if (!$friends) {
        return false;
    }
    var count = $friends.length;
    for (var i = 0; i < count; i++) {
        var $friend = $($friends[i]);
        var fuserid = $friend.attr('data-fuserid');
        if (fuserid == frienduid) {
            return true;
        }
    }
    return false;
}

function bindForMyFriend() {
    $('.myfriendclick').unbind('click').on('click', function (e) {
        e.stopPropagation();
        $('#msglist > span > span.redpoint').hide();

        var $this = $(this);
        var fuserid = $this.parent().attr('data-fuserid');
        var fuseracc = $this.find('.friendacc').text();

        if (!TalkNs.LeaveMsg || TalkNs.LeaveMsg.length == 0) {
            $('.imwin').attr({ 'data-fuserid': fuserid }).attr({ 'data-fuseracc': fuseracc }).removeClass('hide');
            $('.imwin .msgtip').text('好友: ' + fuseracc);
            if (isPc() == true) {
                $('#msginput').focus();
            }
        } else {
            TalkNs.loadImWinByLeaveMsg(fuserid, fuseracc);
        }
    });

    $('.friendoption').unbind('click').on('click', function (e) {
        e.stopPropagation();
        var $this = $(this);
        var currentgroupid = $this.attr('data-groupid');

        var $target = $(e.target);
        if ($target.hasClass('thetime') == true) {
            if ($this.find('.movebtn').hasClass('hide') == false) {
                $this.find('.movebtn').addClass('hide');
                $this.find('select').addClass('hide');
            } else {
                $this.find('.movebtn').removeClass('hide');
                $this.find('select').remove();
                TalkNs.getFriendGroupsAjax($this, currentgroupid);
            }
        }
    });

    $('.movebtn').unbind('click').on('click', function (e) {
        e.stopPropagation();
        var $this = $(this);
        var groupid = $this.parent().find('select option:selected').val();
        var $currenttr = $this.parent().parent();
        var friend = $currenttr.find('td:nth()').find('.friendacc').text();
        TalkNs.moveToGroupAjax(friend, groupid, $currenttr);
    });
}

function addFrindRedPoint(groupid) {
    var $friendgroup = $('.friendgroup');
    if (isNaN(groupid) || !$friendgroup) {
        return;
    }
    var count = $friendgroup.length;
    for (var i = 0; i < count; i++) {
        var $group = $($friendgroup[i]);
        if ($group.attr('data-id') == groupid) {
            $group.find('.redpoint').show();
        }
    }
}

function bindFriendGroup() {
    $('.friendgroup').unbind('click').click(function (e) {
        e.stopPropagation();

        $('#msglist').removeClass('redcolor');
        $('#grouplist > li > span.redcolor').removeClass('redcolor');
        $target = $(e.target);
        $target.addClass('redcolor');
        $target.find('.redpoint').hide();

        var groupname = $(this).text();
        $('#groupname').text(groupname);
        var groupid = $(e.target).attr('data-id');

        $('#updatedir').val(groupname);

        TalkNs.getfriendslistAjax(groupid);
    });
}

function bindMsgboxScroll() {
    window.isbottom = true;

    $(".msgbox").scroll(function () {
        var nScrollHight = 0; //滚动距离总长(注意不是滚动条的长度)
        var nScrollTop = 0;   //滚动到的当前位置
        var nDivHight = $(".msgbox").height();
        nScrollHight = $(this)[0].scrollHeight;
        nScrollTop = $(this)[0].scrollTop;
        if (nScrollTop + nDivHight >= nScrollHight) {
            console.log("滚动条到底部了");
            window.isbottom = true;
        } else {
            console.log('滚动条不在底部');
            window.isbottom = false;
        }
    });
}

function setScroll($msgbox) {
    if (window.isbottom == true) {
        $msgbox.scrollTop($(".msgbox")[0].scrollHeight);//滚动到底部
    }

    setTimeout(function () {
        $msgbox.css({ overflow: 'auto' });//恢复滚动条，以便移动页面
    }, 500);
}

function homeScroll() {
    $(window).scroll(function(){
    　　var scrollTop = $(this).scrollTop();
    　　var scrollHeight = $(document).height();
    　　var windowHeight = $(this).height();
    　　if(scrollTop + windowHeight == scrollHeight){
            console.log("已经到最底部了！");
            TalkNs.loadGif();

            var homeid = window.location.href.split('/')[3];
            var url = '/gethomenextpage';
            if(homeid == 'index'){
                url = '/getindexnextpage'
            }
            var nextpage = parseInt($('#articlelist').attr('data-nextpage'));
            $.ajax({
                url: url,
                type: "get",
                async: true,
                cache: false,
                dataType: "json",
                data: {
                    homeid: homeid,
                    nextpage: nextpage
                },
                success: function (data) {
                    TalkNs.clearLoadGif();
                    if(!data) {
                        return $('.end').show();
                    }

                    if(data.ok == false){
                        // alert(data.msg);
                    } else {
                        var trs = '';
                        var count = data.length;
                        for (var i = data.length - 1; i >= 0; i--) {
                            var row = data[i];
                            trs += 
                            '<tr>' +
                                '<td>' +
                                    '<div><a href="../' + row.openurl + '" target="_blank">' + row.title + '</a></div>' +
                                    '<div>' + row.author + '</div>' +
                                '</td>' +
                                '<td>' +
                                    '<div style="background-image: url(' + row.headimg + ');">' +
                                    '</div>' +
                                '</td>' +
                                '<td>' + row.readcount + '</td>' +
                                '<td class="opentime">' + row.create_time + '</td>' +
                            '</tr>';
                        }

                        $('#articlelist').append(trs).attr({'data-nextpage': ++nextpage});
                        handleOpenTime();
                    }
                },
                error: function (data) {
                    // TalkNs.toLogin(data.responseText);
                }
            });
    　　}
    });
}

function iosBindSendMsgEnter() {
    var msginputelem = document.getElementById("msginput");
    if (!msginputelem) {
        return;
    }

    // msginputelem.addEventListener("input", function (e) {
    //     console.log('input原生事件中，e对象中，只有data属性，表示输入的字符，没有key属性');
    //     console.log(e);
    //     console.log('input实践中，原生js监听数字键，字母键，标点符号键的输入，e.key: ', e.key);
    // });

    msginputelem.addEventListener("keyup", function (e) {
        // console.log('keyup事件中，原生js监听Enter键的输入，e对象中，没有data属性，但是有key属性，表示输入的键名，包括 "Enter" 键名');
        // console.log(e);
        // console.log('keyup事件中，e.key: ', e.key);
        if (e.key == 'Enter') {
            $('.sendmsgbtn').trigger("click");
        }
    });
}

function iosBindLoginEnter() {
    var msginputelem = document.getElementById("loginpsw");
    if (!msginputelem) {
        return;
    }

    msginputelem.addEventListener("keyup", function (e) {
        if (e.key == 'Enter') {
            TalkNs.login();
        }
    });
}

function findFriendFromMsgrsList(friends, senderacc) {
    var count = friends.length;
    if (count > 0) {
        for (var i = 0; i < count; i++) {
            var $friend = $(friends[i]);
            if ($friend.text() == senderacc) {
                return $friend;
            }
        }
    }
}

function getTimeNow(){
    var time = new Date();
    var year = time.getFullYear();
    var month = time.getMonth() + 1;
    var today = time.getDate();

    var hours = time.getHours();
    hours = hours < 10 ? '0' + hours : hours;
    var minutes = time.getMinutes();
    minutes = minutes < 10 ? '0' + minutes : minutes;
    var seconds = time.getSeconds();
    seconds = seconds < 10 ? '0' + seconds : seconds;

    return year + '-' + month + '-' + today + ' ' + hours + ':' + minutes + ':' + seconds;
}

function isLogin() {
    if ($('#headimg').length == 0 || $('#headimg').attr('data-uid') == undefined) {
        return false;
    }
    return true;
}

function handletime(begin) {
    var begintime = parseInt(new Date(begin.replace(/-/g, '/')).getTime() / 1000);
    var nowtime = parseInt(new Date().getTime() / 1000);
    var difftime = nowtime - begintime;

    if(difftime < 60){
        return difftime + '秒前';
    }
    if(difftime < 60 * 60){
        var diffmin = parseInt(difftime / 60);
        if(diffmin == 0){
            diffmin = 1;
        }
        return diffmin + '分钟前';
    }
    if(difftime < 60 * 60 * 24){
        var diffhour = parseInt(difftime / 3600);
        if(diffhour == 0){
            diffhour = 1;
        }
        return diffhour + '小时前';
    }
    if(difftime < 60 * 60 * 24 * 30){
        var diffday = parseInt(difftime / (3600 * 24));
        if(diffday == 0){
            diffday = 1;
        }
        return diffday + '天前';
    }
    if(difftime < 60 * 60 * 24 * 30 * 12){
        var diffmonth = parseInt(difftime / (3600 * 24 * 30));
        if(diffmonth == 0){
            diffmonth = 1;
        }
        return diffmonth + '月前';
    }
    if(difftime < 60 * 60 * 24 * 30 * 12 * 100){
        var diffyear = parseInt(difftime / (3600 * 24 * 30 * 12));
        if(diffyear == 0){
            diffyear = 1;
        }
        return diffyear + '年前';
    }

    return begin;
}

function handleOpenTime() {
    var opentime = $('#articlelist > tr > td.opentime');
    var count = opentime.length;
    for(var i = 0; i < count; i++) {
        var $begintime = $(opentime[i]);
        var difftime = handletime($begintime.text());
        $begintime.text(difftime);
    }
    $('#articlelist').removeClass('hide');
}

// setInterval(function(){
// console.log('开始');
//         $.ajax({
//             url: "/uuuuu",
//             type: "get",
//             async: true,
//             cache: false,
//             dataType: "json",
//             data: {
//             },
//             success: function (data) {
//                 console.log(data);
//             },
//             error: function (data) {
//                 console.log(data.responseText);
//             }
//         });
// }, 2000);

var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');

var cookie = require('cookie');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var routes = require('./routes/index');

var session = require('express-session');
var sessionStore = new session.MemoryStore();

var app = express();

app.use(favicon(__dirname + '/public/favicon.ico'));


var server = require('http').createServer(app);
var io = require('socket.io').listen(server);

var im = require('./code/im');

var sqlite = require('./code/sqlite');

sqlite.logincheck();


// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.set('view options', { layout: false }); //关闭模板引擎

var partials = require('express-partials');
app.use(partials());

//app.use(favicon());
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());

var sessionkey = 'ou09890ro3uou987sfw';
app.use(session({
    //name,设置 cookie 中，保存 session 的字段名称，默认为 connect.sid
    key: sessionkey,
    store: sessionStore,//session 的存储方式，默认存放在内存中，也可以使用 redis，mongodb 等。express 生态中都有相应模块的支持
    secret: 'ilocat',//通过设置的 secret 字符串，来计算 hash 值并放在 cookie 中，使产生的 signedCookie 防篡改
    cookie: { secure: false, maxAge: global.outTime * 60 * 1000 },//设置cookie过期时间 5分钟,
    //当 secure 值为 true 时，cookie 在 HTTP 中是无效，在 HTTPS 中才有效
    resave: true,//是否允许session重新设置
    saveUninitialized: true,//是否设置session在存储容器中可以给修改
    rolling: true //是否按照原设定的maxAge值重设session同步到cookie中
}));

app.use(express.static(path.join(__dirname, 'public'))); //设置静态文件服务器


app.use('/', routes);

/// catch 404 and forward to error handler
app.use(function (req, res, next) {
    var err = new Error('Not Found');
    err.status = 404;
    next(err);
});

/// error handlers
// uncaughtException 避免程序崩溃
process.on('uncaughtException', function (err) {
    console.log('uncaughtException错误:\n', err);
});

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
    app.use(function (err, req, res, next) {
        res.status(err.status || 500);
        res.render('error', {
            // message: err.message,
            message: 'Not Found',//未找到指定页面时，显示在页面上的标题
            error: 'err'//显示的错误信息
        });
    });
}

// production error handler
// no stacktraces leaked to user
app.use(function (err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
        message: err.message,
        error: {}
    });
});

app.set('env', 'production');



//设置socket的session验证
io.use(function (socket, next) {
    if (socket.request.headers.cookie) {
        //解析socket请求发送来的cookie，并保存备用
        socket.request.cookies = cookie.parse(socket.request.headers.cookie);
        next();
    } else {
        return next(new Error('Missing cookie headers'));
    }
});



function getSession(msgType, socket, clientData) {

    var request = socket.request;

    console.log('msgType => ', msgType);
    console.log('clientData => ', clientData);

    cookieParser('ilocat')(request, {}, function (err) {
        request.cookie = cookie.parse(request.headers.cookie);
        var cookieKey = request.cookie[sessionkey];
        if (cookieKey === undefined) {
            console.log('cookieKey is undefined');
            return undefined;
        }
        request.sessionID = cookieParser.signedCookie(cookieKey, 'ilocat');
        request.sessionStore = sessionStore;

        request.sessionStore.get(request.sessionID, function (errs, sess) {

            if (errs) {
                return console.log(errs);
            }
            if (!sess) {
                return console.log('Invalid Session');
            }
            //session.save():把session中的数据重新保存到store中，用内存的内容去替换掉store中的内容。
            //这个方法在HTTP的响应后自动被调用。如果session中的数据被改变了（这个行为可以通过中间件的很多的配置来改变），
            //正因为如此这个方法一般不用显示调用。但是在长连接的websocket中这个方法一般需要手动调用

            request.session = new session.Session(request, sess);
			mysess = request.session;

            if (msgType === 'disconnect') {
                //此时，session中存放的数据已空，mysocket存在，但mysocket.disconnected = undefined
                // var mysocket = global.socketTable.getValues(12);
                // console.log('mysocket  => ', mysocket);
                // console.log('mysocket disconnected => ', mysocket.disconnected, ' end');
                // im.disconnect(mysess.userData.user_id);
                return false;
            }

            //检查用户是否是登录用户
            if (!mysess || !mysess.userData) {
                console.log('此连接用户还未登录');
                return socket.conn.close();
            }

            // console.log('此连接用户已登录过，继续检测是否是重复登录');
            // if (mysess.userData.canreceivmsg != true && zjh.hasInUsertable(mysess.userData.user_id) == true) {
            //     console.log('既不存在可以接收信息的标记，而且还能在用户列表找找到自己同名的账号，说明是重复登录');

            //     console.log('此连接用户重复登录, 找到第一个登录用户的socket，用它通知[账号已在别处登录]');
            //     var firstsock = zjh.getSocket(mysess.userData.user_id);
            //     firstsock.emit('anotherlogin', { msg: '您的账号已在其他地方登录' });
            //     console.log('切断第一个登录用户的socket连接');
            //     firstsock.conn.close();

            //     console.log('通知本次连接的用户，再连接一次');
            //     socket.emit('joinagain');//等待之前的登录用户断开连接，服务器删除此用户的用户信息。之后自己再加入
            //     return;
            // }
            // if (mysess.userData.canreceivmsg != true) {
            //     console.log('接收信息标记没有开启，现在开启并保存');
            //     mysess.userData.canreceivmsg = true;//此标记表明：用户不是重复登录的，可以一直接收用户后续发送的消息
            //     mysess.save();
            // }
            // console.log('接收信息标记已经被标记过，接收到消息');
            // console.log('userData => ', request.session.userData);

            //每次接收到用户的消息请求时，更新session过期时间
            if (!mysess.Cookie) {
                mysess.Cookie = 0;
            } else {
                mysess.Cookie += 1;
            }
            // console.log('request.session =>', socket.client.conn.request.session);
            mysess.save();

			var userdata = mysess.userData;
			var myuid = userdata.user_id;
			var myacc = userdata.account;

            switch (msgType) {
                case 'ready':
                    im.ready(myuid, socket);
                    break;
                case 'imsendmsg':
                    var fuserid = clientData.fuserid;
                    var fuseracc = clientData.fuseracc;
                    var msg = clientData.tomsg;
                    im.imSendMsg(socket, myuid, myacc, msg, fuserid);
                    break;
				case 'readedlmsg':
					var fuserid = clientData.fuserid;
					im.readedleavemsg(socket, myuid, fuserid);
					break;
            }

        });
    });

}



io.on('connection', function (socket) {

    socket.on('ready', function () {
        getSession('ready', socket);
    });

    socket.on('imsendmsg', function (clientData) {
        getSession('imsendmsg', socket, clientData);
    });

	socket.on('readedlmsg', function(clientData){
		getSession('readedlmsg', socket, clientData);
	});

    socket.on('disconnect', function () {
        console.log('接收到消息: disconnect');
        getSession('disconnect', socket);
    });

    socket.on('error', function (err) {
        console.log('接收到消息: err => ', err);
    });

    socket.on('heart', function (clientData) {
        console.log('接收到heart => ', clientData);
        socket.emit('backheart', { s: clientData.uid });
    });

});



var port = 8080;
server.listen(port);
console.log('server is ready for', port);
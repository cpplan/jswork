var express = require('express');
var router = express.Router();
var url = require('url');
var pub = require('../code/pub');


function getClientIp(req) {
    return req.headers['x-forwarded-for'] ||
    req.connection.remoteAddress ||
    req.socket.remoteAddress ||
    req.connection.socket.remoteAddress;
};

router.all('*', function (req, res, next) {
    console.log(' all url => ', req.url);

    var clientid = getClientIp(req);
    console.log('clientid: ', clientid);

    if(req.url.indexOf('.php') != -1 || clientid.indexOf('54.36.') != -1) {
        
        res.writeHead(404);
        res.end(null);
        return console.log('阻断访问');

        //return res.close();
        //return res.redirect('https://www.google.com/');
    }

    // res.header("Access-Control-Allow-Origin", "*");
    // res.header("Access-Control-Allow-Headers", "Content-Type,Content-Length, Authorization, Accept,X-Requested-With");
    // res.header("Access-Control-Allow-Methods", "POST,GET,OPTIONS");
    // res.header("X-Powered-By", ' 3.2.1');

    // if (req.method == 'OPTIONS') {
    //     var params = url.parse(req.url, true).query;
    //     console.log('params => ', params['st']);

    //     console.log('return OPTIONS');
    //     return res.sendStatus(200);//让option请求快速返回
    // }

    next();
});


router.get('/socket.io', function (req, res) {
    return res.end('/socket.io? ok');
});

router.get('/', function (req, res) {
    if (!req.session.lanid) {
        req.session.lanid = 'english';
    }
    if (req.session && req.session.userData) {
        if(req.session.userData.usertype == 1) {
            return res.redirect('/ahome');
        }
        return res.redirect('/usm');
    }

    var lantip = pub.getLanTip(req);
    var lanid = pub.getLanid(req);
    var lanname = global.lannameTable.getValue(lanid);//指定的语言

    res.render('login', {
        layout: 'login'
        , login: lantip.lan11, signup: lantip.lan12, account: lantip.lan13
        , password: lantip.lan14, newaccount: lantip.lan15, email: lantip.lan80
        , lanid: lanid, lanname: lanname
    });
});

router.get('/logout', function (req, res) {
    if (req.session && req.session.userData) {
        req.session.userData = null;
        req.session.save();
    }
    return res.redirect('/');
});

router.get('/gettime', function (req, res) {
    if (!req.session || !req.session.userData) {
        return res.end();
    }
    var myDate = new Date();
    var mytime = myDate.toLocaleString();
    return res.json({ time: mytime });
});




router.get('/:id', function (req, res) {
    //所有未被处理的请求，都由此来处理, 包括带参数请求
    console.log('/:id url => ', req.url);
    return res.redirect('/');
});

module.exports = router;
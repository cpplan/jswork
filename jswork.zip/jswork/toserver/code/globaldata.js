/**
 * 定义整个程序所使用的全局变量
 */

var HashTable = require('../code/hashtable');

/**
 * key存放用户的uid
 * value存放用户的session, 对方用户key（所以，通过key能相互找到对方），以及其他数据
 * 如：value => {sess:session, selfsock: socket, ready:false, bei: 1000, pubdata: data, otherkey:otherkey}
 */
global.gamersTable = HashTable.HashTableObj();

//用户的socket，每次连接到服务器后，加入到此表
global.socketTable = HashTable.HashTableObj();

//当对方不在线时，其他用户发送的消息临时存放在此表。等用户上线了再来此获取
global.msgTable = HashTable.HashTableObj();

//每个用户的黑名单，自己无法给黑名单的人发消息，黑名单里面的人也无法给我发消息
global.blackTable = HashTable.HashTableObj();




global.lanidHashTable = HashTable.HashTableObj();//保存用户所选择的语言标记

global.matchLock = HashTable.HashTableObj();//记录每种股票在线程执行数据库操作的时候的锁。防止多个线程同时执行同种股票的数据库操作

global.lastTxidForSuccess = '';//记录最近一次处理的txid，以便将重复的提交pass掉

global.usMkindexHashTable = HashTable.HashTableObj();//某个市场的指数

global.hkMkindexHashTable = HashTable.HashTableObj();//某个市场的指数

global.usStockHashTable = HashTable.HashTableObj();//存放开盘股票数据

global.hkStockHashTable = HashTable.HashTableObj();//存放开盘股票数据

global.usOpen = false;
global.hkOpen = false;

global.workers = [];//保存所有工作进程备用



//其他法币与美元的汇率
global.usCashRate = {
    HKD: 7.8
};

//每个币种兑换为$的兑换比率
global.coinRate = {
    STC: 1000,
    BTC: 10000,
    ETH: 1000,
    BCH: 1000
};

global.baseFloat = 1000000000000;

//交易手续费费率
global.stockFeet = {
    STC: 0.002,
    BTC: 0.001,
    ETH: 0.002,
    BCH: 0.002
};

//提现手续费费率
global.takeFeet = {
    STC: 0.002,
    BTC: 0.001,
    ETH: 0.002,
    BCH: 0.002
};

//证券类型
global.stockType = {
    stock: 'stock',
};

//支持的币种
global.coins = {
    STC: 'STC',
    BTC: 'BTC',
    ETH: 'ETH',
    BCH: 'BCH',
};




//====================用于操作页面时，提示文字，或用来修改页面文字======================

global.chinese_tip = {
    lan0: 'chinese',
    lan01: '买入股数必须为正整数',
    lan1: '卖出股数必须为正整数',
    lan2: '卖出股数已超过持有的股票数',
    lan3: '请填写最低卖出价，或选择现价卖出',
    lan4: '价格最多保留 2 位小数',
    lan401: '价格最多保留 3 位小数',
    lan5: '账号长度应为6-30字符',
    lan6: '密码长度应为6-16字符',
    lan7: '账号或密码错误',
    lan8: '登录成功',
    lan9: '注册成功',
    lan10: '持有',
    lan11: '登 录',
    lan12: '注 册',
    lan13: '账 号',
    lan14: '密 码',
    lan15: '新账号',
    lan22: ' 股 ',
    lan23: '请填写最高买入价，或选择现价买入',
    lan24: 'Email长度应为6-60字符',
    lan25: 'Email格式错误',

    lan35: '休盘',
    lan36: '开盘中',

    lan38: 'Stc地址格式错误',
    lan39: '请不要填写包括空格在内的特殊字符',
    lan40: '操作失败',
    lan41: '请先登录',
    lan42: '操作成功',
    lan43: '修改',

    lan44: '请填写数字，且小数不超过8位',
    lan45: '余额不足',

    lan46: '未处理',
    lan47: '已处理',
    lan48: '没有记录',

    lan49: '注册失败，请稍后再试',
    lan50: '已经被使用',
    lan51: '股票价格数据不存在',
    lan52: '余额不足以购买这些数量的股票',
    lan53: ' 成功购入 ',
    lan54: ' 股, 成交价: $',
    lan55: '购入',
    lan56: '股票失败',
    lan57: '股票数量不足',

    lan58: '已将 ',
    lan59: '股票设置为卖出',
    lan60: '设置 ',
    lan61: '股票卖单失败!',
    lan62: '关闭卖单成功',
    lan63: '关闭卖单失败，请稍候再试',
    lan64: '没有交易数据',
    lan65: '休盘中',

    lan66: '没有匹配到符合价格的卖单',

    lan67: '市场现价',

    lan68: '关闭卖单',
    lan69: '类型',
    lan70: '公司',
    lan71: '股票代码',
    lan72: '出售数量',
    lan73: '最低售价',
    lan74: '卖单用户ID',
    lan75: '挂单时间',
    lan76: '是否锁定',
    lan77: '已售出数量',
    lan78: '卖单状态',

    lan79: '操作错误',
    lan80: 'Email (可用于找回密码)',

    lan81: ' 下单成功',
    lan82: ' 下单失败',

    lan83: ' 成功售出 ',

    lan84: '下单数量',
    lan85: '下单价格',
    lan86: '下单时间',
    lan87: '已购数量',
    lan88: '关闭买单',

    lan89: '没有数据',
    lan90: '买单状态',
    lan91: '是',
    lan92: '否',
    lan93: '余额不足',
    lan94: '撮合中',
    lan95: '已完成',
    lan96: '时间',
    lan97: '成交价格',
    lan98: '已关闭',
    lan99: '（香港）',
};

global.chinesearr = [
    global.chinese_tip
];


global.english_tip = {
    lan0: 'english',
    lan01: 'The number of shares bought must be a positive integer',
    lan1: 'The number of shares sold must be a positive integer',
    lan2: 'The number of shares sold has exceeded the number of shares held',
    lan3: 'Please fill in the lowest offer or choose to sell at the current price',
    lan4: 'The price is reserved at most 2 decimal places',
    lan401: 'The price is reserved at most 3 decimal places',
    lan5: 'The account should be 6-30 characters',
    lan6: 'The password should be 6-16 characters',
    lan7: 'Incorrect account or password',
    lan8: 'Login successful',
    lan9: 'Registered successfully',
    lan10: 'Holding',
    lan11: 'Log in',
    lan12: 'Sign up',
    lan13: 'account',
    lan14: 'password',
    lan15: 'new account',
    lan22: ' shares ',
    lan23: 'Please fill in the highest purchase price, or choose the current purchase price',
    lan24: 'The email should be 6-30 characters',
    lan25: 'Wrong Email format',

    lan35: 'Closed',
    lan36: 'Opening',

    lan38: 'Fnc address format error',
    lan39: 'Please do not enter special chars',
    lan40: 'Operate failed',
    lan41: 'Please login first',
    lan42: 'Operate success',
    lan43: 'Change',

    lan44: 'fill in the Numbers with no more than 8 decimal places',
    lan45: 'Lack of balance',
    
    lan46: 'untreated',
    lan47: 'treated',
    lan48: 'There is no record',

    lan49: 'Registration failed. Please try again later',
    lan50: 'Already in use',
    lan51: 'Stock price data does not exist',
    lan52: 'The balance is not enough to buy these quantities of shares',
    lan53: ' Successful purchase ',
    lan54: ' shares, deal the price: $',
    lan55: 'buy',
    lan56: 'shares failed',
    lan57: 'Stock shortage',

    lan58: '',
    lan59: 'shares has been to set it to sell',
    lan60: 'set ',
    lan61: 'Stock sale failed!',
    lan62: 'Closed the sale order successfully',
    lan63: 'Failed to close the order, please try again later',
    lan64: 'No trading data',
    lan65: 'Closing',

    lan66: 'No match to sell order',

    lan67: 'The spot price',

    lan68: 'Close the sale',
    lan69: 'type',
    lan70: 'company',
    lan71: 'Stock code',
    lan72: 'Sell quantity',
    lan73: 'lowest price',
    lan74: 'Sale user ID',
    lan75: 'Sales time',
    lan76: 'Lock or not',
    lan77: 'Sold quantity',
    lan78: 'Complete or not',

    lan79: 'The operating error',
    lan80: 'Email (Retrieve password)',

    lan81: ' order success',
    lan82: ' order failed',

    lan83: ' Successfully sold ',

    lan84: 'Order quantity',
    lan85: 'Order price',
    lan86: 'Order time',
    lan87: 'Bought quantity',
    lan88: 'Closing order',

    lan89: 'No data',
    lan90: 'Status',
    lan91: 'Yes',
    lan92: 'No',
    lan93: 'Lack of balance',
    lan94: 'Matching',
    lan95: 'The deal',
    lan96: 'The time',
    lan97: 'Deal the price',
    lan98: 'Closed',
    lan99: '（HK Time）',
};

global.englisharr = [
    global.english_tip
];


//lanid对应的语言的所有文字
global.lantipTable = HashTable.HashTableObj();
global.lantipTable.add('english', global.english_tip);
global.lantipTable.add('chinese', global.chinese_tip);


//lanid对应的语言的正式名称
global.lannameTable = HashTable.HashTableObj();
global.lannameTable.add('english', 'English');
global.lannameTable.add('chinese', '中文');

//=================================== end ==========================================



//=================渲染页面的时候使用 start=============================
global.chinese_page = {
    lan10: '持有',
    lan16: '行情',
    lan1601: '美股',
    lan1602: '港股',
    lan1603: '美股',
    lan1604: '港股',
    lan17: '纳斯达克',
    lan18: '道琼斯',
    lan19: '标普500',
    lan1901: '恒生指数',

    lan20: '所有股票',
    lan21: '已购股票',
    lan22: '股票卖单',

    lan23: '昨收盘价',
    lan24: '今开盘价',
    lan25: '今区间价',
    lan26: '市值',
    lan2601: '美元',
    lan2602: '港元',
    lan27: '市盈率',

    lan28: '买入',
    lan29: '卖出',
    lan30: '买入股数',
    lan31: '市价买入',
    lan32: '卖出股数',
    lan33: '最低卖出价',
    lan34: '市价卖出',

    lan37: '退出',

    lan371: '余额',
    lan372: '平台接收币地址',
    lan373: '您的提币地址',
    lan374: '只能有一个地址',
    lan375: '修改',
    lan376: '新增',

    lan47: '详情',
    lan48: '提币',
    lan49: '提币数量',

    lan50: '股',
    lan51: '最高买入价',

    lan52: '软件',
    lan53: '股票买单',
    lan54: '确 定',
    lan55: '模拟炒股',
};

global.english_page = {
    lan10: 'Holding',
    lan16: 'Market',
    lan1601: 'Usm',
    lan1602: 'Hkm',
    lan1603: 'US Market',
    lan1604: 'HK Market',
    lan17: 'Nasdaq',
    lan18: 'Dow Jones',
    lan19: 'S&P 500',
    lan1901: 'HSI',

    lan20: 'All the stock',
    lan21: 'Bought stock',
    lan22: 'Selling stock',

    lan23: 'Closing price yesterday',
    lan24: 'Opening price today',
    lan25: 'Range price today',
    lan26: 'Market value',
    lan2601: 'USD',
    lan2602: 'HKD',
    lan27: 'P/e ratio',

    lan28: 'Buy',
    lan29: 'Sell',
    lan30: 'Buy quantity',
    lan31: 'Present price to buy',
    lan32: 'Sell quantity',
    lan33: 'Minimum selling price',
    lan34: 'Present price to sell',

    lan37: 'Log out',

    lan371: 'Balance',
    lan372: 'Platform Fnc Address',
    lan373: 'Your Withdraw Fnc Address',
    lan374: 'Only one address',
    lan375: 'Change',
    lan376: 'Add New',

    lan47: 'Details',
    lan48: 'Take',
    lan49: 'take amount',

    lan50: 'shares',
    lan51: 'Highest purchase price',

    lan52: 'Software',
    lan53: 'buying stock',
    lan54: 'OK',
    lan55: 'Stock Trading',
};

//lanid对应的语言的页面上的共同文字的翻译
global.lanpageTable = HashTable.HashTableObj();
global.lanpageTable.add('english', global.english_page);
global.lanpageTable.add('chinese', global.chinese_page);
//=================渲染页面的时候使用 end=============================







//===========================股票对应的公司名 start================================
global.english_ltd = {
    apple: 'Apple',
    facebook: 'Facebook',
    microsoft: 'Microsoft',
    google: 'Google',
    oracle: 'Oracle',
    intel: 'Intel',
    amd: 'Amd',
    nvidia: 'Nvidia',
    amazon: 'Amazon',
    ebay: 'eBay',

    tencent: 'Tencent',
    CKISF: 'CK Infrastructure Holdings Ltd',
    SHKP: 'Sun Hung Kai Properties',
    HSB: 'Hang Seng Bank',
    MTR: 'Mass Transit Railway',
    COPOWER: 'COPOWER',
    Towngas: 'Towngas',
    sandschina: 'sandschina',
    LINK: 'LINK',
    SCPLC: 'Standard chartered PLC',
    Henderson: 'Henderson Land',
};

global.chinese_ltd = {
    apple: '苹果公司',
    facebook: '脸谱',
    microsoft: '微软',
    google: '谷歌',
    oracle: '甲骨文',
    intel: '英特尔',
    amd: '超威半导体',
    nvidia: '英伟达',
    amazon: '亚马逊',
    ebay: '电子港湾',

    tencent: '腾讯控股',
    CKISF: '长江基建集团',
    SHKP: '新鸿基地产',
    HSB: '恒生银行',
    MTR: '港铁公司',
    COPOWER: '长和实业',
    Towngas: '香港中华煤气',
    sandschina: '金沙中国',
    LINK: '领展房产基金',
    SCPLC: '渣打集团',
    Henderson: '恒基地产',
};

//lanid对应的语言的所有公司名
global.ltdTable = HashTable.HashTableObj();
global.ltdTable.add('english', global.english_ltd);
global.ltdTable.add('chinese', global.chinese_ltd);
//===========================股票对应的公司名 end================================
var http = require('http');
var querystring = require('querystring');
var app = require('../app');

function connectAndSend(postData, options, callback) {

    var contents = querystring.stringify(postData);

    options.headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': contents.length
    };

    var req = http.request(options, function(res) {
        console.log('post callback');
        res.setEncoding('utf8');
        res.on('data', function(data) {
            console.log(data);
            login();

            if (callback) {
                if (data == '<h1>Not Found</h1>') {
                    console.log('Not Found');
                    return;
                }
                // callback(data); //接收到的post接口返回的数据，可能是html，也可能是其他数据类型
            }
        });
    });

    req.on('error', function(e) {
        console.log('error => ', e.message);
    });

    req.write(contents);
    req.end;

}

exports.sendPost = function() {
    var postData = querystring.stringify({
        account:'zhenfund',
        psw:'abc123'
    });

    var options = {
        host: '104.192.83.192',
        port: 80,
        path: '/tologin',
        method: 'POST'
    };

    loginpost(postData, options);
};


function login() {
    var postData = querystring.stringify({
        account:'zhenfund',
        psw:'abc123'
    });

    var options = {
        host: '104.192.83.192',
        port: 80,
        path: '/tologin',
        method: 'POST'
    };

    loginpost(postData, options);
};

function loginpost(postData, options, callback) {

    var contents = querystring.stringify(postData);

    options.headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': contents.length
    };

    var req = http.request(options, function(res) {
        console.log('post callback');
        res.setEncoding('utf8');
        res.on('data', function(data) {
            console.log(data);
            app.createClient();

            if (callback) {
                if (data == '<h1>Not Found</h1>') {
                    console.log('Not Found');
                    return;
                }
                // callback(data); //接收到的post接口返回的数据，可能是html，也可能是其他数据类型
            }
        });
    });

    req.on('error', function(e) {
        console.log('error => ', e.message);
    });

    req.write(contents);
    req.end;

}
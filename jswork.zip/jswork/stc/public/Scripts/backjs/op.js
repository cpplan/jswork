var opns = {

    $loading: null,
    isconn: null,
    mylan: null,
    thispage: null,

    init: function (isconn) {

        opns.$alertOrder = $('#alertOrder');

        opns.$alertWindow = $('#alertWindow');
        opns.$alertinfo = $('#alertinfo');
        opns.$alertok = $('#alertok');

        opns.$loading = $('#loading');

        opns.isconn = isconn;

        opns.thispage = $('#market').attr('page');
        opns.language = $('#langid').attr('lanid');


        opns.$alertok.click(function() {
            opns.$alertWindow.hide();
            opns.$alertinfo.text('');
        });

        $('.addressbtn').click(function () {
            var $takeaddress = $('.useraddress');
            if ($takeaddress.attr('disabled') == 'disabled') {
                $takeaddress.removeAttr('disabled');
                if (isPc()) {
                    $takeaddress.focus();
                }
                return;
            }

            var takeaddress = $('.useraddress').val();
            if (takeaddress.length != 34) {
                return opns.showAlert(opns.mylan.lan38);
            }
            opns.updateTakeAddress(takeaddress);
        });

        $('.takebtn').unbind('click').click(function () {
            var $takestcinp = $('.takestcinp');
            var takenum = $takestcinp.val();
            if (!isStc(takenum)) {
                return opns.showAlert(opns.mylan.lan44);
            }

            var balance = $('#stcbalance').text();
            if (!isStc(balance)) {
                return opns.showAlert(opns.mylan.lan45);
            }

            takenum = parseFloat(takenum);
            balance = parseFloat(balance);
            if (takenum > balance) {
                return opns.showAlert(opns.mylan.lan45);
            }

            opns.takeStc(takenum);
        });

        $('#takeview').unbind('click').click(function (e) {
            opns.getTakes();
            e.stopPropagation();
        });

        $('#headimg, #langid').unbind('click').click(function (e) {
            $('.headurlbox').addClass('hide');
            var $headurlbox = $(this).next();
            $headurlbox.removeClass('hide');

            if ($(this).attr('id') == 'headimg') {
                if ($('#coins > option').length == 0) {
                    opns.getCoins();
                } else {
                    var coin = $('#coins').find("option:selected").text();
                    if (coin) {
                        opns.getBalanceAndAddress(coin);
                    }
                }

            }
            e.stopPropagation();
        });

        $('#coins').unbind('change').change(function (e) {
            var coin = $(this).find("option:selected").text();
            if (coin) {
                opns.getBalanceAndAddress(coin);
            }
            e.stopPropagation();
        });

        $('#language > div').unbind('click').click(function (e) {
            var language = $(this).text();
            var lanid = $(this).attr('lanid');
            $('#langid').text(language).attr(lanid);

            opns.setMyLan(lanid);
            e.stopPropagation();
        });

        $('.headurlbox').unbind('click').click(function (e) {
            e.stopPropagation();
        });

        $('#main').unbind('click').click(function () {
            $('.headurlbox').addClass('hide');
        });

        $('#stockshow > input').click(function () {
            var radio = $(this).val();

            var $stocktablediv = $('#stocktablediv');
            var $stocktable = $('#stocktable');

            var $buyingstocktablediv = $('#buyingstocktablediv');
            var $sellingstocktablediv = $('#sellingstocktablediv');

            switch (radio) {
                case 'allstocks':
                    $buyingstocktablediv.hide();
                    $sellingstocktablediv.hide();
                    $stocktablediv.show();

                    $stocktable.show().find('tr').show();
                    $('.hasstock').parent().parent().parent().show();
                    break;
                case 'boughtstocks':
                    $buyingstocktablediv.hide();
                    $sellingstocktablediv.hide();
                    $stocktablediv.show();

                    opns.showBuystocks();
                    break;
                case 'buyingstocks':
                    $stocktablediv.hide();
                    $buyingstocktablediv.show();
                    $sellingstocktablediv.hide();
                    opns.getDirItemsAjax(6);
                    break;
                case 'sellingstocks':
                    $stocktablediv.hide();
                    $buyingstocktablediv.hide();
                    $sellingstocktablediv.show();
                    opns.getDirItemsAjax(7);
                    break;
            }
        });

        $('.stcbtn').click(function () {
            var $buyselldiv = $(this).nextAll();
            if ($buyselldiv.is(':hidden')) {
                $buyselldiv.show();
            } else {
                $buyselldiv.hide();
            }
        });

        $('.buybtn').click(function () {
            var $parent = $(this).parent();
            var buynum = $parent.find('> input.buynum').attr('value');
            if (!isPint(buynum)) {
                return opns.showAlert(opns.mylan.lan01);
            }

            var coin = $('#stocktable span.nowcoin').eq(0).text();

            var $parent3 = $parent.parent().parent();
            var stocktype = 'stock';
            var company = $parent3.find('.company-name').text();
            var stockcode = $parent3.find('.stockcode').text();

            $parent.find('> input.buynum').val('');
            var $updatenum = $parent.parent().parent().parent().find('>div.bluecolor');

            if ($(this).prev().prop('checked')) {
                return opns.buystock(coin, stocktype, company, stockcode, buynum, 'checkbox', $updatenum);
            }

            var buyprice = $parent.find('> input.buyprice').attr('value');
            if (buyprice == '') {
                return opns.showAlert(opns.mylan.lan23);
            }
            if(opns.thispage == 'hkm') {
                if (!isPriceHkd(buyprice)) {
                    return opns.showAlert(opns.mylan.lan401);
                }
            } else {
                if (!isPrice(buyprice)) {
                    return opns.showAlert(opns.mylan.lan4);
                }
            }

            $parent.find('> input').val('');
            opns.buystock(coin, stocktype, company, stockcode, buynum, buyprice, $updatenum);
        });


        $('.buyprice').click(function () {
            var $parent = $(this).parent();
            $parent.find('> input.buynow').prop('checked', false);
        });

        $('.buynow').click(function () {
            var $parent = $(this).parent();
            $parent.find('> input.buyprice').val('');
        });

        $('.sellprice').click(function () {
            var $parent = $(this).parent();
            $parent.find('> input.sellnow').prop('checked', false);
        });

        $('.sellnow').click(function () {
            var $parent = $(this).parent();
            $parent.find('> input.sellprice').val('');
        });

        $('.sellbtn').click(function () {
            var $parent = $(this).parent();
            var sellnum = $parent.find('> input.sellnum').attr('value');
            if (!isPint(sellnum)) {
                return opns.showAlert(opns.mylan.lan1);
            }

            var coin = $('#stocktable span.nowcoin').eq(0).text();

            var $parent3 = $parent.parent().parent();
            var hasstock = $parent3.prev().find('.hasstock').text();
            if (isPint(hasstock) && parseInt(hasstock) < parseInt(sellnum)) {
                return opns.showAlert(opns.mylan.lan2);
            }

            var stocktype = 'stock';
            var company = $parent3.find('.company-name').text();
            var stockcode = $parent3.find('.stockcode').text();

            var $updatenum = $parent.parent().parent().parent().find('>div.bluecolor');

            if ($(this).prev().prop('checked')) {
                $parent.find('> input.sellnum').val('');
                return opns.sellstock(coin, stocktype, company, stockcode, sellnum, 'checkbox', $updatenum);
            }

            var sellprice = $parent.find('> input.sellprice').attr('value');
            if (sellprice == '') {
                return opns.showAlert(opns.mylan.lan3);
            }
            if(opns.thispage == 'hkm') {
                if (!isPriceHkd(sellprice)) {
                    return opns.showAlert(opns.mylan.lan401);
                }
            } else {
                if (!isPrice(sellprice)) {
                    return opns.showAlert(opns.mylan.lan4);
                }
            }

            $parent.find('> input').val('');
            opns.sellstock(coin, stocktype, company, stockcode, sellnum, sellprice, $updatenum);
        });

        $('.nowcoin').text('FNC');

        this.getMyLan();

        this.getNumsOfMyStocks('stock');

        connectInit();

    },


    showAlert: function (info) {
        opns.$alertWindow.show();
        opns.$alertinfo.text(info);
    },

    showBuystocks: function () {
        var stocks = $('#articlelist123 div.bluecolor > span.hasstock');
        var count = stocks.length;
        for (var i = 0; i < count; i++) {
            var $stock = $(stocks[i]);
            if (isPint($stock.text())) {
                $stock.parent().parent().parent().show();
            } else {
                $stock.parent().parent().parent().hide();
            }
        }
    },

    loadGif: function () {
        if (opns.$loading.hasClass('hide')) {
            opns.$loading.removeClass('hide');
        } else {
            opns.$loading.addClass('hide');
        }
    },

    clearLoadGif: function (data) {
        stop(data);
        
        if (opns.$loading.hasClass('hide') == false) {
            opns.$loading.addClass('hide');
        }
    },

    error: function (data) {
        opns.clearLoadGif(data);
        console.log(data.responseText);
        opns.showAlert(opns.mylan.lan79);
    },


    setMyLan: function (lanid) {
        $.ajax({
            url: "/setmylan",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                lanid: lanid
            },
            success: function (data) {
                stop(data);
                location.href = '/' + opns.thispage;
            },
            error: function (data) {
                opns.error(data);
            }
        });
    },

    getMyLan: function () {
        $.ajax({
            url: "/getmylan",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {},
            success: function (data) {
                stop(data);
                
                if (data) {
                    var count = data.length;
                    if (count > 0) {
                        opns.mylan = data[0];
                        // console.log(opns.mylan);
                    }
                }
            },
            error: function (data) {
                opns.error(data);
            }
        });
    },

    getNumsOfMyStocks: function (stocktype) {
        opns.loadGif();

        $.ajax({
            url: "/getNumsOfMyStocks",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                coin: $('#stocktable span.nowcoin').eq(0).text(),
                stocktype: stocktype
            },
            success: function (data) {
                opns.clearLoadGif(data);

                if (data) {
                    var count = data.length;
                    if (count > 0) {
                        for (var i = 0; i < count; i++) {
                            var row = data[i];
                            var stockid = row.stockcode.split(':')[1];
                            $('#' + stockid + ' > div.bluecolor > span.hasstock').text(row.stocknum);
                        }
                    } else {
                        $('#articlelist123 span.hasstock').text(0);
                    }
                }

                if ($('#boughtstocks').attr('checked') == 'checked') {
                    opns.showBuystocks();
                }
            },
            error: function (data) {
                opns.error(data);
            }
        });
    },

    buystock: function (coin, stocktype, company, stockcode, buynum, buyprice, $updatenum) {
        opns.loadGif();

        $.ajax({
            url: "/buystock",
            type: "post",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                coin: coin,
                stocktype: stocktype,
                company: company,
                stockcode: stockcode,
                buynum: buynum,
                buyprice: buyprice
            },
            success: function (data) {
                opns.clearLoadGif(data);

                if (data) {
                    opns.showAlert(data.msg);
                }
            },
            error: function (data) {
                opns.error(data);
            }
        });
    },

    sellstock: function (coin, stocktype, company, stockcode, sellnum, sellprice, $updatenum) {
        opns.loadGif();

        $.ajax({
            url: "/sellstock",
            type: "post",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                coin: coin,
                stocktype: stocktype,
                company: company,
                stockcode: stockcode,
                sellnum: sellnum,
                sellprice: sellprice
            },
            success: function (data) {
                opns.clearLoadGif(data);

                if (data && data != '') {
                    if (data.ok == true) {
                        var oldnum = $updatenum.find('span.hasstock').text();
                        if (oldnum == '') {
                            return;
                        } else {
                            oldnum = parseInt(oldnum);
                        }
                        var total = oldnum - parseInt(sellnum);
                        $updatenum.find('span.hasstock').text(total);
                    }
                    opns.showAlert(data.msg);
                }
            },
            error: function (data) {
                opns.error(data);
            }
        });
    },


    updateTakeAddress: function (takeaddress) {
        var coin = $('#coins').find("option:selected").text();
        opns.loadGif();

        $.ajax({
            url: "/updateTakeAddress",
            type: "post",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                coin: coin,
                takeaddress: takeaddress
            },
            success: function (data) {
                opns.clearLoadGif(data);

                if (data && data != '') {
                    $('.useraddress').attr({ 'disabled': 'disabled' });
                    $('.addressbtn').text(opns.mylan.lan43);
                    return opns.showAlert(data.msg);
                }
                opns.showAlert(opns.mylan.lan40);
            },
            error: function (data) {
                opns.error(data);
            }
        });
    },

    takeStc: function (takenum) {
        var coin = $('#coins').find("option:selected").text();
        opns.loadGif();

        $.ajax({
            url: "/takestc",
            type: "post",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                coin: coin,
                takenum: takenum
            },
            success: function (data) {
                opns.clearLoadGif(data);

                if (data && data != '') {
                    if (data.ok == true) {
                        $('.takestcinp').val('');
                        var balance = $('#stcbalance').text();
                        var rest = parseFloat(balance) - parseFloat(takenum);
                        $('#stcbalance').text(parseFloat(rest).toFixed(8));
                        var newtr = '<tr><td class="size13">' + coin + '</td><td>' + takenum + '</td><td class="size13">' + 'no' + '</td></tr>';
                        $('#taketable').append(newtr);
                    }
                    opns.showAlert(data.msg);
                } else {
                    opns.showAlert(opns.mylan.lan40);
                }
            },
            error: function (data) {
                opns.error(data);
            }
        });
    },

    getTakes: function () {
        var coin = $('#coins').find("option:selected").text();
        opns.loadGif();

        $.ajax({
            url: "/gettakes",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                coin: coin
            },
            success: function (data) {
                opns.clearLoadGif(data);

                if (data) {
                    var count = data.length;
                    var $taketable = $('#taketable');
                    if (count > 0) {
                        $taketable.empty();
                        for (var i = 0; i < count; i++) {
                            var row = data[i];
                            var takenum = row.takenum;
                            var done = row.done == '' ? opns.mylan.lan46 : opns.mylan.lan47;
                            var newtr = '<tr><td class="size13">' + coin + '</td><td>' + takenum + '</td><td class="size13">' + done + '</td></tr>';
                            $taketable.append(newtr);
                        }
                    } else {
                        opns.showAlert(opns.mylan.lan48);
                    }
                }
            },
            error: function (data) {
                opns.error(data);
            }
        });
    },

    getCoins: function () {
        opns.loadGif();

        $.ajax({
            url: "/getcoins",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {},
            success: function (data) {
                opns.clearLoadGif(data);

                if (data && data.length > 0) {
                    var $coins = $('#coins');
                    $coins.empty();
                    var option = '';
                    for (var i = 0; i < data.length; i++) {
                        option += '<option>' + data[i].coin + '</option>';
                    }
                    $coins.append(option);

                    opns.getBalanceAndAddress(data[0].coin);
                }
            },
            error: function (data) {
                opns.error(data);
            }
        });
    },

    getBalanceAndAddress: function (coin) {
        $('#stcbalance').text(0);
        $('.useraddress').val('');
        $('#topupaddress').text('');
        $('.nowcoin').text(coin);

        opns.loadGif();

        $.ajax({
            url: "/getBalanceAndAddress",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: { coin: coin },
            success: function (data) {
                opns.clearLoadGif(data);

                if (data) {
                    $('#stcbalance').text(data.balance);
                    if(opns.thispage == 'hkm') {
                        $('#hkd').text(data.hkd);    
                    }
                    $('#topupaddress').text(data.topupaddress);
                    $('.useraddress').val(data.takeaddress);

                    opns.getNumsOfMyStocks('stock');
                }
            },
            error: function (data) {
                opns.error(data);
            }
        });
    },

    getDirItemsAjax: function (dirid) {
        var coin = $('#articlelist123 span.nowcoin').eq(0).text()
        opns.loadGif();

        var url = '/sellingstock';
        if(dirid == '6') {
            url = '/buyingstock';
        }

        $.ajax({
            url: url,
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: { coin: coin },
            success: function (data) {
                opns.clearLoadGif(data);

                if (!data) {
                    return opns.showAlert(opns.mylan.lan89);
                }
                if (data.ok == false) {
                    return location.href = data.url;
                }

                var $rslist = $('#sellingrslist');
                if(dirid == '6') {
                    $rslist = $('#buyingrslist');
                }
                opns.handleItemsOfDirOrSearch($rslist, dirid, data);
            },
            error: function (data) {
                opns.error(data);
            }
        });
    },

    handleItemsOfDirOrSearch: function ($rslist, dirid, data) {

        if (!data) {
            return $rslist.empty();
        } else {
            var trs = '';
            dirid = dirid.toString();
            var count = data.length;

            switch (dirid) {
                case '6':
                    for (var i = 0; i < count; i++) {
                        var row = data[i];
                        var done = row.buynum == row.boughtnum ? opns.mylan.lan91 : opns.mylan.lan92;
                        var islocked = row.islocked > 0 ? opns.mylan.lan91 : opns.mylan.lan92;
                        var closebuybtn = done == opns.mylan.lan91 ? '' : '<tr><td>' + opns.mylan.lan68 + ': </td><td><button class="addressbtn closebuybtn" data-id="' + row.buyorder_id + '">' + opns.mylan.lan88 + '</button></td></tr>';
                        var status = row.remarks > 0 ? opns.mylan.lan93 : opns.mylan.lan94;
                        if(row.buynum - row.boughtnum == 0) {
                            status = opns.mylan.lan95;
                        }

                        var buyprice = row.buyprice == 0 ? opns.mylan.lan67 : row.buyprice;

                        var detailtable = '<table class="hide showtable">'
                            + '<tr><td>ID: </td><td>' + row.buyorder_id + '</td></tr>'
                            + '<tr><td>' + opns.mylan.lan69 + ': </td><td>' + row.stocktype + '</td></tr>'
                            + '<tr><td>' + opns.mylan.lan71 + ': </td><td>' + row.stockcode + '</td></tr>'
                            + '<tr><td>' + opns.mylan.lan84 + ': </td><td>' + row.buynum + '</td></tr>'
                            + '<tr><td>' + opns.mylan.lan85 + ': </td><td>$' + buyprice + '</td></tr>'
                            + '<tr><td>' + opns.mylan.lan86 + ': </td><td>' + row.buytime + '</td></tr>'
                            + '<tr><td>' + opns.mylan.lan87 + ': </td><td>' + row.boughtnum + '</td></tr>'
                            + '<tr><td>' + opns.mylan.lan97 + ': </td><td>' + row.dealprice + '</td></tr>'
                            + '<tr><td>' + opns.mylan.lan76 + ': </td><td>' + islocked + '</td></tr>'
                            + '<tr><td>' + opns.mylan.lan90 + ': </td><td>' + status + '</td></tr>'
                            + closebuybtn
                            + '</table>';

                        trs += '<tr>';
                        trs += '<td valign="top" data-dirid="' + dirid + '" data-id="' + row.buyorder_id + '" data-pos="left"><div><span class="margin-r10">' + (i + 1) + '</span>' + row.company + '  ' + row.stockcode + ' [<span class="redcolor"> ' + row.buynum + ' </span>]</div>' + detailtable + '</td>';
                        trs += '<td valign="top" data-dirid="' + dirid + '" data-id="' + row.buyorder_id + '" data-pos="right">' + row.buytime + '</td>';
                        trs += '</tr>';
                    }
                    break;
                case '7':
                    for (var i = 0; i < count; i++) {
                        var row = data[i];
                        var done = row.sellnum == row.sellednum ? opns.mylan.lan91 : opns.mylan.lan92;
                        var islocked = row.islocked > 0 ? opns.mylan.lan91 : opns.mylan.lan92;
                        var closesellbtn = done == opns.mylan.lan91 ? '' : '<tr><td>' + opns.mylan.lan68 + ': </td><td><button class="addressbtn closesellbtn" data-id="' + row.sellorder_id + '">' + opns.mylan.lan68 + '</button></td></tr>';
    
                        var status = row.sellnum == row.sellednum ? opns.mylan.lan95 : opns.mylan.lan94;
                        var sellprice = row.lowestprice == 0 ? opns.mylan.lan67 : row.lowestprice;

                        var detailtable = '<table class="hide showtable">'
                            + '<tr><td>ID: </td><td>' + row.sellorder_id + '</td></tr>'
                            + '<tr><td>' + opns.mylan.lan69 + ': </td><td>' + row.stocktype + '</td></tr>'
                            + '<tr><td>' + opns.mylan.lan71 + ': </td><td>' + row.stockcode + '</td></tr>'
                            + '<tr><td>' + opns.mylan.lan72 + ': </td><td>' + row.sellnum + '</td></tr>'
                            + '<tr><td>' + opns.mylan.lan73 + ': </td><td>$' + sellprice + '</td></tr>'
                            + '<tr><td>' + opns.mylan.lan75 + ': </td><td>' + row.thetime + '</td></tr>'
                            + '<tr><td>' + opns.mylan.lan77 + ': </td><td>' + row.sellednum + '</td></tr>'
                            + '<tr><td>' + opns.mylan.lan76 + ': </td><td>' + islocked + '</td></tr>'
                            + '<tr><td>' + opns.mylan.lan78 + ': </td><td>' + status + '</td></tr>'
                            + closesellbtn
                            + '</table>';
    
                        trs += '<tr>';
                        trs += '<td valign="top" data-dirid="' + dirid + '" data-id="' + row.sellorder_id + '" data-pos="left"><div><span class="margin-r10">' + (i + 1) + '</span>' + row.company + '  ' + row.stockcode + ' [<span class="redcolor"> ' + row.sellnum + ' </span>]</div>' + detailtable + '</td>';
                        trs += '<td valign="top" data-dirid="' + dirid + '" data-id="' + row.sellorder_id + '" data-pos="right">' + row.thetime + '</td>';
                        trs += '</tr>';
                    }
                    break;
            }

            $rslist.empty().append(trs);


            $rslist.unbind('click').on('click', 'td', function (e) {
                e.stopPropagation();

                var $target = $(e.target);
                if ($target.hasClass('closebuybtn')) {
                    var tid = $target.attr('data-id');

                    return opns.buybackAjax($target, tid);
                }

                if ($target.hasClass('closesellbtn')) {
                    var tid = $target.attr('data-id');

                    return opns.sellbackAjax($target, tid);
                }

                var $td = $(this);
                var $detailtable = $td.find('>table');
                if ($detailtable.hasClass('hide')) {
                    $detailtable.removeClass('hide');
                } else {
                    $detailtable.addClass('hide');
                }
                return false;
            });

        }
    },

    buybackAjax: function ($target, tid) {
        opns.loadGif();

        $.ajax({
            url: "/buyback",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                tid: tid
            },
            success: function (data) {
                opns.clearLoadGif(data);

                if (data) {
                    if (data.ok == true) {
                        $target.parent().empty().append('<span class="redcolor">' + opns.mylan.lan98 + '</span>');
                    }
                    opns.showAlert(data.msg);
                }

            },
            error: function (data) {
                opns.error(data);
            }
        });
    },

    sellbackAjax: function ($target, tid) {
        opns.loadGif();

        $.ajax({
            url: "/sellback",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                tid: tid
            },
            success: function (data) {
                opns.clearLoadGif(data);

                if (data) {
                    if (data.ok == true) {
                        $target.parent().empty().append('<span class="redcolor">' + opns.mylan.lan98 + '</span>');
                        var $stock = $('#' + data.stockcode.split(':')[1]);
                        var num = $stock.find('.hasstock').text();
                        if (isZeroPlusNumber(num)) {
                            num = parseInt(num);
                            $stock.find('.hasstock').text(num + data.backnum);
                        }
                    }
                    opns.showAlert(data.msg);
                }

            },
            error: function (data) {
                opns.error(data);
            }
        });
    },

};


function isZeroPlusNumber(num) {
    if (num == '0' || isPint(num)) {
        return true;
    }
    return false;
}

function isPint(num) {
    var r = /^\+?[1-9][0-9]*$/;
    var flag = r.test(num);
    return flag;
}

function isPrice(num) {
    if (typeof(num) == 'undefined' || parseFloat(num) == 0) {
        return false;
    }
    var r = /(^[1-9](\d+)?(\.\d{1,2})?$)|(^0$)|(^\d\.\d{1,2}$)/;
    var flag = r.test(num);
    return flag;
}

function isPriceHkd(num) {
    if (typeof(num) == 'undefined' || parseFloat(num) == 0) {
        return false;
    }
    var r = /(^[1-9](\d+)?(\.\d{1,3})?$)|(^0$)|(^\d\.\d{1,3}$)/;
    var flag = r.test(num);
    return flag;
}

function isStc(num) {
    if (typeof(num) == 'undefined' || parseFloat(num) == 0) {
        return false;
    }
    var r = /(^[1-9](\d+)?(\.\d{1,8})?$)|(^0$)|(^\d\.\d{1,8}$)/;
    var flag = r.test(num);
    return flag;
}

function isPc() {
    var useragent = navigator.userAgent;
    if (useragent.indexOf('Mobile') > -1) {
        return false;
    } else {
        return true;
    }
}

function stop(data) {
    if(data && data.stopip == false) {
        location.href = '/';
    }
}

var socket;

function connectInit() {

    if (opns.isconn != true) {
        return;
    }

    if (!socket) {
        socket = io('/website', { 'reconnection': false });

        socket.on('connect', function () {
            console.log('connect success');
            socket.emit('join', {cntime: 'woefijwofdslsjifg', page: opns.thispage});
            console.log('join');
        });

        socket.on('backheart', function (data) {
            var nasdaqtime = data.st + '（eastern）';
            if (data.usOpen == false) {
                $('.us-etime-box').text(opns.mylan.lan35).removeClass('hide');
                $('.us-etime').text(nasdaqtime);
            } else {
                $('.us-etime-box').text(opns.mylan.lan36).removeClass('hide');
                $('.us-etime').text(nasdaqtime);
            }
        });

        socket.on('error', function (data) {
            console.log('connect error => ' + data);
        });

        socket.on('disconnect', function () {
            // socket.connect();
            // console.log('reconnect');
        });

        socket.on('usopen', function (data) {
            if(opns.thispage == 'usm') {
                usOpen(data);
            }
        });

        socket.on('umk', function (data) {
            if(opns.thispage == 'usm') {
                setNasdaqIndex(data);
            }
        });

        socket.on('hmk', function (data) {
            if(opns.thispage == 'hkm') {
                setHkIndex(data);
            }
        });

        socket.on('onestockdatau', function (data) {
            if(opns.thispage == 'usm') {
                setOneStockData(data);
            }
        });

        socket.on('onestockdatah', function (data) {
            if(opns.thispage == 'hkm') {
                setOneStockData(data);
            }
        });

        socket.on('stocktableu', function (data) {
            console.log('join ok');
            if(opns.thispage != 'usm') {
                return;
            }
            var count = data.alldata.length;
            for (var i = 0; i < count; i++) {
                var onestock = data.alldata[i];
                setOneStockData(onestock);
            }
        });

        socket.on('stocktableh', function (data) {
            console.log('join ok');
            if(opns.thispage != 'hkm') {
                return;
            }
            var count = data.alldata.length;
            for (var i = 0; i < count; i++) {
                var onestock = data.alldata[i];
                setOneStockData(onestock);
            }
        });

        socket.on('buyorder', function (data) {
            if (data && data.ok == true) {
                var stockid = data.stockcode.split(':');
                var $stockid = $('#' + stockid[1]);
                var oldnum = $stockid.find('span.hasstock').text();
                if (oldnum == '') {
                    oldnum = 0;
                } else {
                    oldnum = parseInt(oldnum);
                }
                var total = oldnum + parseInt(data.canbuynum);
                $stockid.find('span.hasstock').text(total);

                loadAlert(data.msg);
            }
        });

        socket.on('selled', function (data) {
            if (data && data.ok == true) {
                loadAlert(data.msg);
            }
        });
    }
}



function setOneStockData(data) {
    var stockcode = '#' + data.stockcode; 
    $(stockcode + ' span.stockcode').text(data.nasdaq + ':' + data.stockcode);
    $(stockcode + ' .stockprice').text(data.stockprice);
    $(stockcode + ' .priceupdown').text(data.updown);
    $(stockcode + ' .pricepercent').text(data.percent);

    var $stockparent = $(stockcode + ' .stockprice').parent();
    if(data.updown.indexOf('-') != -1) {
        if(opns.language == 'chinese') {
            $stockparent.removeClass('red').addClass('green');
        } else {
            $stockparent.removeClass('green').addClass('red');
        }
    } else {
        if(opns.language == 'chinese') {
            $stockparent.removeClass('green').addClass('red');
        } else {
            $stockparent.removeClass('red').addClass('green');
        }
    }

    var ttimearr = data.stocktime.split(':');
    var ttimenew = ttimearr[0] + ':' + ttimearr[1] + ':00';
    $(stockcode + ' .stocktime').text(ttimenew);

    $(stockcode + ' .yesterdaystockprice').text(data.yesterdayprice);
    $(stockcode + ' .todaystockprice').text(data.todayprice);
    $(stockcode + ' .rangestockprice').text(data.rangeprice);

    var marketvalue = data.marketvalue;
    var mvlen = marketvalue.length;
    var v = marketvalue.substring(0, mvlen - 1);
    var b = marketvalue.substring(mvlen - 1, mvlen);
    switch (opns.mylan.lan0) {
        case 'english':
            v = (Number(v) * 0.1).toFixed(3);
            b = 'b';
            break;
    }
    $('#' + data.stockcode + ' .marketvalue').text(v + b);
    $('#' + data.stockcode + ' .peratio').text(data.peratio);
}

function usOpen(data) {
    if ($('.us-etime').text() != data.nasdaqtime) {
        if(!opns.mylan) {
            return;
        }

        if (data.status_off == false) {
            $('.us-etime-box').text(opns.mylan.lan35).removeClass('hide');
        } else {
            $('.us-etime-box').text(opns.mylan.lan36).removeClass('hide');
        }
    }
}

function setNasdaqIndex(data) {
    if ($('.us-etime').text() != data.nasdaqtime) {
        $('#mkindex1').text(data.mkindex1);
        var $mkpercent1 = $('#mkpercent1');
        $mkpercent1.text(data.mkpercent1);

        $('#mkindex2').text(data.mkindex2);
        var $mkpercent2 = $('#mkpercent2');
        $mkpercent2.text(data.mkpercent2);

        $('#mkindex3').text(data.mkindex3);
        var $mkpercent3 = $('#mkpercent3');
        $mkpercent3.text(data.mkpercent3);

        if(opns.language != 'chinese') {

            if(data.mkpercent1.indexOf('-') != -1) {
                $mkpercent1.removeClass('green').addClass('red');
            } else {
                $mkpercent1.removeClass('red').addClass('green');
            }

            if(data.mkpercent2.indexOf('-') != -1) {
                $mkpercent2.removeClass('green').addClass('red');
            } else  {
                $mkpercent2.removeClass('red').addClass('green');
            }

            if(data.mkpercent3.indexOf('-') != -1) {
                $mkpercent3.removeClass('green').addClass('red');
            } else {
                $mkpercent3.removeClass('red').addClass('green');
            }

        } else {
            
            if(data.mkpercent1.indexOf('-') != -1) {
                $mkpercent1.removeClass('red').addClass('green');
            } else {
                $mkpercent1.removeClass('green').addClass('red');
            }

            if(data.mkpercent2.indexOf('-') != -1) {
                $mkpercent2.removeClass('red').addClass('green');
            } else {
                $mkpercent2.removeClass('green').addClass('red');
            }

            if(data.mkpercent3.indexOf('-') != -1) {
                $mkpercent3.removeClass('red').addClass('green');
            } else {
                $mkpercent3.removeClass('green').addClass('red');
            }

        }
    }
}

function setHkIndex(data) {
    if ($('.us-etime').text() != data.nasdaqtime) {
        $('#mkindex1').text(data.mkindex1);
        var $mkindexChange1 = $('#mkindexChange1');
        $mkindexChange1.text(data.mkindexChange1);
        var $mkpercent1 = $('#mkpercent1');
        $mkpercent1.text(data.mkpercent1);

        if(opns.language != 'chinese') {

            if(data.mkindexChange1.indexOf('-') != -1) {
                $mkindexChange1.removeClass('green').addClass('red');
                $mkpercent1.removeClass('green').addClass('red');
            } else {
                $mkindexChange1.removeClass('red').addClass('green');
                $mkpercent1.removeClass('red').addClass('green');
            }

        } else {
            
            if(data.mkindexChange1.indexOf('-') != -1) {
                $mkindexChange1.removeClass('red').addClass('green');
                $mkpercent1.removeClass('red').addClass('green');
            } else {
                $mkindexChange1.removeClass('green').addClass('red');
                $mkpercent1.removeClass('green').addClass('red');
            }

        }

        var nasdaqtime = data.stocktime;
        if(!opns.mylan) {
            return;
        }

        switch (opns.mylan.lan0) {
            case 'english':
                var dtarr = nasdaqtime.split(' ');
                var darr = dtarr[0].split('-');
                var md = darr[2] + '-' + darr[1];
                nasdaqtime = md + ' ' + dtarr[1];
                break;
        }
        if (data.status_off == false) {
            $('.us-etime-box').text(opns.mylan.lan35).removeClass('hide');
        } else {
            $('.us-etime-box').text(opns.mylan.lan36).removeClass('hide');
        }
        $('.us-etime').text(nasdaqtime + opns.mylan.lan99);
    }
}

function loadAlert(msg) {
    // opns.$alertOrder.text(msg).show();
    opns.showAlert(msg);
    setTimeout(
        function() {
            // opns.$alertOrder.text('').hide();
            opns.$alertWindow.hide();
            opns.$alertinfo.text('');
        },
        15000
    );
}


function checksocket() {
    if(!socket) {
        // console.log('refresh');
        location.href = window.location.href;
    }
    if(socket.disconnected == true) {
        // console.log('reconnect...');
        socket.connect();
    } else {
        socket.emit('heart');
    }
}

setInterval(checksocket, 20000);
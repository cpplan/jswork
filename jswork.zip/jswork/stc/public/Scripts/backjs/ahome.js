function isPc() {
    var useragent = navigator.userAgent;
    if (useragent.indexOf('Mobile') > -1) {
        return false;
    } else {
        return true;
    }
}

function isPlusNumber(words) {
    var reg = /^[1-9][0-9]*$/;
    return reg.test(words.toString());
};

var opns = {

    $loading: null,

    init: function () {

        opns.$loading = $('#loading');


        $('#coins').unbind('change').change(function (e) {
            var coin = $(this).find("option:selected").text();
            if (coin) {
                var $target = $('#dirlist > li > span.redcolor').eq(0);
                if ($target.hasClass('dirspan') == false) {
                    return;
                }
                opns.getItemsOfDirlist($target);
            }
            e.stopPropagation();
        });

        $('#dirlist').unbind('click').click(function (e) {
            e.stopPropagation();
            var $target = $(e.target);
            if ($target.hasClass('dirspan') == false) {
                return;
            }
            opns.getItemsOfDirlist($target);
        });

        $('.nextpage').unbind('click').click(function () {
            var pos = $(this).attr('data-pos');
            var nowpage = $('#nextpageinp').attr('data-page');
            var page = parseInt(nowpage);
            switch (pos) {
                case 'prev':
                    page -= 1;
                    break;
                case 'next':
                    page += 1;
                    break;
                default:
                    return;
            }
            if (page <= 0 || page > parseInt($('#pagetotal').text())) {
                return;
            }
            var dirid = $('#dirname').attr('data-dirid');
            var dirname = $('#dirname').text();
            opns.getDirItemsAjax(dirid, dirname, page);
        });

        $('#searchtree').keypress(function (e) {
            if (e.keyCode == 13) {
                var stxt = $(this).val();
                if (stxt.length > 0 && stxt.length < 100) {
                    var dirid = $('#dirname').attr('data-dirid');
                    var dirid = parseInt(dirid);
                    if (dirid <= 0) {
                        return;
                    }
                    opns.searchAdmin(dirid, stxt);
                }
            }
        });

        $('#nextpageinp').keypress(function (e) {
            if (e.keyCode == 13) {
                var page = parseInt($(this).val());
                if (page <= 0) {
                    return;
                }
                var dirid = $('#dirname').attr('data-dirid');
                var dirname = $('#dirname').text();
                opns.getDirItemsAjax(dirid, dirname, page);
            }
        });

        $('#headimg').unbind('click').click(function (e) {
            var $headurlbox = $('.headurlbox');
            if ($headurlbox.hasClass('hide')) {
                $headurlbox.removeClass('hide');
                if (isPc() == true) {
                    $('#headinput').focus();
                }
            } else {
                $headurlbox.addClass('hide');
            }
            e.stopPropagation();
        });

        $('.headurlbox').unbind('click').click(function (e) {
            e.stopPropagation();
        });

        $('.imgurlbox').unbind('click').click(function (e) {
            e.stopPropagation();
        });

        $('#main').unbind('click').click(function () {
            $('.headurlbox').addClass('hide');
            $('.imgurlbox').addClass('hide');
        });

        $('.mainboard').unbind('click').click(function () {
            $('.headurlbox').addClass('hide');
            $('.imgurlbox').addClass('hide');
        });

    },


    getItemsOfDirlist: function ($target) {
        var dirid = $target.attr('data-id');
        if (dirid) {
            $('#dirlist > li > span').removeClass('underline redcolor');
            $target.addClass('underline redcolor');

            var coin = $('#coins').find("option:selected").text();
            if(!coin) {
                return console.log('coin is null');
            }

            opns.getItemcountAndPagecountAjax(dirid);

            var dirname = $target.text();
            $('#updatedir').val(dirname);
            opns.getDirItemsAjax(dirid, dirname, 1);
        }
    },

    getItemcountAndPagecountAjax: function (dirid) {
        opns.loadGif();

        $.ajax({
            url: "/getitemcountandpagecount",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                dirid: dirid,
                coin: $('#coins').find("option:selected").text()
            },
            success: function (data) {
                opns.clearLoadGif();
                if (data) {
                    if (data.ok == false) {
                        return location.href = data.url;
                    }
                    $('#itemtotal').text(data.count);
                    var pages = 0;
                    if (data.count > 0 && data.count <= 10) {
                        pages = 1;
                    } else {
                        var rest = data.count % 10;
                        if (rest == 0) {
                            pages = data.count / 10;
                        } else {
                            pages = (data.count - rest) / 10 + 1;
                        }
                    }
                    $('#pagetotal').text(pages);
                }
            },
            error: function (data) {
                opns.toLogin(data);
            }
        });
    },

    getDirItemsAjax: function (dirid, dirname, page) {
        opns.loadGif();

        $.ajax({
            url: "/adiritems",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                dirid: dirid,
                page: page,
                coin: $('#coins').find("option:selected").text()
            },
            success: function (data) {
                opns.clearLoadGif();

                if (!data) {
                    $('#rslist').empty();
                    $('#itemnum').text(0);
                    return alert('no data');
                }
                if (data.ok == false) {
                    return location.href = data.url;
                }
                $('#dirname').text(dirname).attr({ 'data-dirid': dirid });
                opns.handleItemsOfDirOrSearch(dirid, data);
                if (page > 0) {
                    $('#nextpageinp').attr({ 'data-page': page }).val(page);
                }
            },
            error: function (data) {
                opns.toLogin(data);
            }
        });
    },

    handleItemsOfDirOrSearch: function (dirid, data) {
        $('#itemckbox').removeAttr('checked');
        var $rslist = $('#rslist');
        if (!data) {
            $('#itemnum').text('0');
            $rslist.empty();
        } else {
            var count = data.length;
            $('#itemnum').text(count);
            var trs = '';
            dirid = dirid.toString();

            switch (dirid) {
                case '1':
                    for (var i = 0; i < count; i++) {
                        var row = data[i];
                        var checkbox = '';
                        var yesno = '<span>否</span>';
                        if (row.islocked > 0) {
                            checkbox = 'checked="checked"';
                            var yesno = '<span>是</span>';
                        }
                        var checkboxhtml = '<input type="checkbox" ' + checkbox + ' class="islocked" data-dirid="' + dirid + '" data-tid="' + row.user_id + '" data-islocked="' + row.islocked + '" />';

                        var detailtable = '<table class="hide" data-dirid="' + dirid + '">'
                            + '<tr><td>ID: </td><td class="uid">' + row.user_id + '</td></tr>'
                            + '<tr><td>账号: </td><td>' + row.account + '</td></tr>'
                            + '<tr><td>余额: </td><td>' + row.balance + '</td></tr>'
                            // + '<tr><td>是否vip: </td><td>' + row.isvip + '</td></tr>'
                            + '<tr><td>注册时间: </td><td>' + row.create_time + '</td></tr>'
                            + '<tr><td>是否锁定: </td><td>' + checkboxhtml + yesno + '</td></tr>'
                            + '</table>';
                        trs += '<tr>';
                        trs += '<td valign="top" data-dirid="' + dirid + '" data-id="' + row.user_id + '" data-pos="left"><div>' + row.account + '</div>' + detailtable + '</td>';
                        trs += '<td valign="top" data-dirid="' + dirid + '" data-id="' + row.user_id + '" data-pos="right">' + row.create_time + '</td>';
                        trs += '</tr>';
                    }
                    break;
                case '2':
                    for (var i = 0; i < count; i++) {
                        var row = data[i];
                        var detailtable = '<table class="hide" data-dirid="' + dirid + '">'
                            + '<tr><td>ID: </td><td>' + row.usercoin_id + '</td></tr>'
                            + '<tr><td>币种: </td><td>' + row.coin + '</td></tr>'
                            + '<tr><td>充币地址: </td><td>' + row.topupaddress + '</td></tr>'
                            + '<tr><td>用户ID: </td><td>' + row.user_id + '</td></tr>'
                            + '<tr><td>是否锁定: </td><td>' + row.islocked + '</td></tr>'
                            + '<tr><td>创建时间: </td><td>' + row.thetime + '</td></tr>'
                            + '</table>';
                        trs += '<tr>';
                        trs += '<td valign="top" data-dirid="' + dirid + '" data-id="' + row.address_id + '" data-pos="left"><div><span class="size13">' + row.coin + ' </span>' + row.topupaddress + '</div>' + detailtable + '</td>';
                        trs += '<td valign="top" data-dirid="' + dirid + '" data-id="' + row.address_id + '" data-pos="right">' + row.thetime + '</td>';
                        trs += '</tr>';
                    }
                    break;
                case '3':
                    for (var i = 0; i < count; i++) {
                        var row = data[i];
                        var detailtable = '<table class="hide" data-dirid="' + dirid + '">'
                            + '<tr><td>ID: </td><td>' + row.topupstc_id + '</td></tr>'
                            + '<tr><td>币种: </td><td class="coin">' + row.coin + '</td></tr>'
                            + '<tr><td>数量: </td><td>' + row.amount + '</td></tr>'
                            + '<tr><td>确认数: </td><td>' + row.confirmations + '</td></tr>'
                            + '<tr><td>交易ID: </td><td>' + row.txid + '</td></tr>'
                            + '<tr><td>交易时间: </td><td>' + row.txtime + '</td></tr>'
                            + '<tr><td>区块哈希: </td><td>' + row.blockhash + '</td></tr>'
                            + '<tr><td>区块索引: </td><td>' + row.blockindex + '</td></tr>'
                            + '<tr><td>区块时间: </td><td>' + row.blocktime + '</td></tr>'
                            + '<tr><td>充币地址: </td><td>' + row.topupaddress + '</td></tr>'
                            + '<tr><td>记录时间: </td><td>' + row.thetime + '</td></tr>'
                            + '<tr><td>是否锁定: </td><td>' + row.islocked + '</td></tr>'
                            + '</table>';
                        trs += '<tr>';
                        trs += '<td valign="top" data-dirid="' + dirid + '" data-id="' + row.topupstc_id + '" data-pos="left"><div><span class="size13">' + row.coin + ' </span><span class="redcolor">' + row.amount + '</span> <= ' + row.topupaddress + '</div>' + detailtable + '</td>';
                        trs += '<td valign="top" data-dirid="' + dirid + '" data-id="' + row.topupstc_id + '" data-pos="right">' + row.thetime + '</td>';
                        trs += '</tr>';
                    }
                    break;
                case '4':
                    for (var i = 0; i < count; i++) {
                        var row = data[i];
                        var checkbox = '';
                        var yesno = '<span>否</span>';
                        var isdone = ' <span class="redcolor">[否]</span>';
                        var disabled = '';
                        if (row.done > 0) {
                            checkbox = 'checked="checked"';
                            yesno = '<span>是</span>';
                            isdone = ' <span class="bluecolor">[完成]</span>';
                            disabled = 'disabled="disabled"';
                        }
                        var checkboxhtml = '<input type="checkbox" ' + checkbox + ' class="isdone" data-dirid="' + dirid + '" data-stcid="' + row.takestc_id + '" data-islocked="' + row.done + '" ' + disabled + ' />';

                        var detailtable = '<table class="hide" data-dirid="' + dirid + '">'
                            + '<tr><td>ID: </td><td>' + row.takestc_id + '</td></tr>'
                            + '<tr><td>币种: </td><td class="coin">' + row.coin + '</td></tr>'
                            + '<tr><td>提币数量: </td><td>' + row.takenum + '</td></tr>'
                            + '<tr><td>提币地址: </td><td class="takeaddress">loading...</td></tr>'
                            + '<tr><td>用户ID: </td><td class="uid">' + row.user_id + '</td></tr>'
                            + '<tr><td>时间: </td><td>' + row.thetime + '</td></tr>'
                            + '<tr><td>是否锁定: </td><td>' + row.islocked + '</td></tr>'
                            + '<tr><td>是否完成: </td><td>' + checkboxhtml + yesno + '</td></tr>'
                            + '<tr><td>操作者: </td><td>' + row.operater + '</td></tr>'
                            + '</table>';
                        trs += '<tr>';
                        trs += '<td valign="top" data-dirid="' + dirid + '" data-id="' + row.takestc_id + '" data-pos="left"><div><span class="size13">' + row.takestc_id + '. ' + row.coin + '</span> ' + row.takenum + isdone + '</div>' + detailtable + '</td>';
                        trs += '<td valign="top" data-dirid="' + dirid + '" data-id="' + row.takestc_id + '" data-pos="right">' + row.thetime + '</td>';
                        trs += '</tr>';
                    }
                    break;
                case '5':
                    for (var i = 0; i < count; i++) {
                        var row = data[i];
                        var detailtable = '<table class="hide" data-dirid="' + dirid + '">'
                            + '<tr><td>ID: </td><td>' + row.stock_id + '</td></tr>'
                            + '<tr><td>用户ID: </td><td>' + row.user_id + '</td></tr>'
                            + '<tr><td>类型: </td><td>' + row.stocktype + '</td></tr>'
                            + '<tr><td>公司: </td><td>' + row.company + '</td></tr>'
                            + '<tr><td>代码: </td><td>' + row.stockcode + '</td></tr>'
                            + '<tr><td>持有数量: </td><td>' + row.stocknum + '</td></tr>'
                            + '<tr><td>是否锁定: </td><td>' + row.islocked + '</td></tr>'
                            + '</table>';
                        trs += '<tr>';
                        trs += '<td valign="top" data-dirid="' + dirid + '" data-id="' + row.stock_id + '" data-pos="left"><div>' + row.stockcode + ' [<span class="redcolor"> ' + row.stocknum + ' </span>]</div>' + detailtable + '</td>';
                        trs += '<td valign="top" data-dirid="' + dirid + '" data-id="' + row.stock_id + '" data-pos="right">' + row.thetime + '</td>';
                        trs += '</tr>';
                    }
                    break;
                case '6':
                    for (var i = 0; i < count; i++) {
                        var row = data[i];
                        var detailtable = '<table class="hide" data-dirid="' + dirid + '">'
                            + '<tr><td>ID: </td><td>' + row.buy_id + '</td></tr>'
                            + '<tr><td>类型: </td><td>' + row.stocktype + '</td></tr>'
                            + '<tr><td>公司: </td><td>' + row.company + '</td></tr>'
                            + '<tr><td>代码: </td><td>' + row.stockcode + '</td></tr>'
                            + '<tr><td>买入数量: </td><td>' + row.buynum + '</td></tr>'
                            + '<tr><td>买入价格: </td><td>$' + row.buyprice + '</td></tr>'
                            + '<tr><td>买入时间: </td><td>' + row.buytime + '</td></tr>'
                            + '<tr><td>卖单ID: </td><td>' + row.sellorder_id + '</td></tr>'
                            + '<tr><td>卖出用户ID: </td><td>' + row.sell_user_id + '</td></tr>'
                            + '<tr><td>买单ID: </td><td>' + row.buyorder_id + '</td></tr>'
                            + '<tr><td>买入用户ID: </td><td>' + row.buy_user_id + '</td></tr>'
                            + '<tr><td>是否锁定: </td><td>' + row.islocked + '</td></tr>'
                            + '</table>';
                        trs += '<tr>';
                        trs += '<td valign="top" data-dirid="' + dirid + '" data-id="' + row.buy_id + '" data-pos="left"><div>' + row.company + '  ' + row.stockcode + ' [<span class="redcolor"> ' + row.buynum + ' </span>]</div>' + detailtable + '</td>';
                        trs += '<td valign="top" data-dirid="' + dirid + '" data-id="' + row.buy_id + '" data-pos="right">' + row.buytime + '</td>';
                        trs += '</tr>';
                    }
                    break;
                case '7':
                    for (var i = 0; i < count; i++) {
                        var row = data[i];
                        var done = row.sellnum == row.sellednum ? 'yes' : 'no';

                        var detailtable = '<table class="hide" data-dirid="' + dirid + '">'
                            + '<tr><td>ID: </td><td>' + row.sellorder_id + '</td></tr>'
                            + '<tr><td>类型: </td><td>' + row.stocktype + '</td></tr>'
                            + '<tr><td>公司: </td><td>' + row.company + '</td></tr>'
                            + '<tr><td>代码: </td><td>' + row.stockcode + '</td></tr>'
                            + '<tr><td>卖出数量: </td><td>' + row.sellnum + '</td></tr>'
                            + '<tr><td>设的最低价: </td><td>$' + row.lowestprice + '</td></tr>'
                            + '<tr><td>卖单用户ID: </td><td>' + row.sell_user_id + '</td></tr>'
                            + '<tr><td>挂单时间: </td><td>' + row.thetime + '</td></tr>'
                            + '<tr><td>是否锁定: </td><td>' + row.islocked + '</td></tr>'
                            + '<tr><td>已售出数量: </td><td>' + row.sellednum + '</td></tr>'
                            + '<tr><td>完成与否: </td><td>' + done + '</td></tr>'
                            + '</table>';

                        trs += '<tr>';
                        trs += '<td valign="top" data-dirid="' + dirid + '" data-id="' + row.sellorder_id + '" data-pos="left"><div>' + row.company + '  ' + row.stockcode + ' [<span class="redcolor"> ' + row.sellnum + ' </span>]</div>' + detailtable + '</td>';
                        trs += '<td valign="top" data-dirid="' + dirid + '" data-id="' + row.sellorder_id + '" data-pos="right">' + row.thetime + '</td>';
                        trs += '</tr>';
                    }
                    break;
                case '8':
                    for (var i = 0; i < count; i++) {
                        var row = data[i];
                        var done = row.buynum == row.boughtnum ? 'yes' : 'no';
    
                        var detailtable = '<table class="hide" data-dirid="' + dirid + '">'
                            + '<tr><td>ID: </td><td>' + row.buyorder_id + '</td></tr>'
                            + '<tr><td>类型: </td><td>' + row.stocktype + '</td></tr>'
                            + '<tr><td>公司: </td><td>' + row.company + '</td></tr>'
                            + '<tr><td>代码: </td><td>' + row.stockcode + '</td></tr>'
                            + '<tr><td>购买数量: </td><td>' + row.buynum + '</td></tr>'
                            + '<tr><td>设的最高价: </td><td>$' + row.buyprice + '</td></tr>'
                            + '<tr><td>下单时间: </td><td>' + row.buytime + '</td></tr>'
                            + '<tr><td>下单用户ID: </td><td>' + row.buy_user_id + '</td></tr>'
                            + '<tr><td>已购入数量: </td><td>' + row.boughtnum + '</td></tr>'
                            + '<tr><td>是否锁定: </td><td>' + row.islocked + '</td></tr>'
                            + '<tr><td>完成与否: </td><td>' + done + '</td></tr>'
                            + '<tr><td>余额不足: </td><td>' + row.remarks + '</td></tr>'
                            + '</table>';
    
                        trs += '<tr>';
                        trs += '<td valign="top" data-dirid="' + dirid + '" data-id="' + row.sellorder_id + '" data-pos="left"><div>' + row.company + '  ' + row.stockcode + ' [<span class="redcolor"> ' + row.buynum + ' </span>]</div>' + detailtable + '</td>';
                        trs += '<td valign="top" data-dirid="' + dirid + '" data-id="' + row.sellorder_id + '" data-pos="right">' + row.buytime + '</td>';
                        trs += '</tr>';
                    }
                    break;

            }


            $rslist.empty().append(trs);


            $rslist.unbind('click').on('click', 'td', function (e) {
                e.stopPropagation();

                var $target = $(e.target);
                if ($target.hasClass('islocked')) {
                    var dirid = $target.attr('data-dirid');
                    var tid = $target.attr('data-tid');
                    var islocked = $target.attr('data-islocked');
                    var ischecked = parseInt(islocked) > 0 ? true : false;
                    return opns.islockedAjax($target, ischecked, dirid, tid, islocked);
                }

                if ($target.hasClass('isdone')) {
                    var tid = $target.attr('data-stcid');
                    var islocked = $target.attr('data-islocked');
                    var ischecked = parseInt(islocked) > 0 ? true : false;
                    return opns.isTakeDoneAjax($target, ischecked, islocked, tid);
                }

                var $td = $(this);
                var $detailtable = $td.find('>table');
                if ($detailtable.hasClass('hide')) {
                    $detailtable.removeClass('hide');

                    var dirid = $detailtable.attr('data-dirid');
                    switch (dirid) {
                        case '1':
                            var uid = $detailtable.find('td.uid').text();
                            opns.getCoinAddressOfUser(uid, $detailtable);
                            break;
                        case '4':
                            var uid = $detailtable.find('td.uid').text();
                            var coin = $detailtable.find('td.coin').text();
                            opns.getTakeAddress(uid, coin, $detailtable);
                            break;
                    }
                } else {
                    $detailtable.addClass('hide');
                }
                return false;
            });

        }
    },

    getCoinAddressOfUser: function (uid, $detailtable) {
        var coin = $('#coins').find("option:selected").text();
        opns.loadGif();

        $.ajax({
            url: "/getCoinAddressOfUser",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                uid: uid,
                coin: coin
            },
            success: function (data) {
                opns.clearLoadGif();

                if (data && data.ok == true) {
                    var count = data.rows.length;
                    var tr = '';
                    for(var i = 0; i < count; i++) {
                        var row = data.rows[i];
                        tr += '<tr><td>充币地址: </td><td>' + row.topupaddress + '</td></tr>'
                            + '<tr><td>提币地址: </td><td style="color: #C40522">' + row.takeaddress + '</td></tr>'
                    }
                    $detailtable.append(tr);
                } else {
                    // alert('no data');
                }
            },
            error: function (data) {
                opns.toLogin(data);
            }
        });
    },

    getTakeAddress: function (uid, coin, $detailtable) {
        opns.loadGif();

        $.ajax({
            url: "/gettakeaddress",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                uid: uid,
                coin: coin
            },
            success: function (data) {
                opns.clearLoadGif();

                if (data && data.ok == true) {
                    $detailtable.find('td.takeaddress').text(data.takeaddress);
                } else {
                    alert('no data');
                }
            },
            error: function (data) {
                opns.toLogin(data);
            }
        });
    },

    islockedAjax: function ($target, ischecked, dirid, tid, islocked) {
        opns.loadGif();

        $.ajax({
            url: "/islocked",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                dirid: dirid,
                tid: tid,
                islocked: islocked
            },
            success: function (data) {
                opns.clearLoadGif();

                if (data) {
                    if (data.ok) {
                        if (ischecked) {
                            $target.removeAttr('checked').attr({ 'data-islocked': data.islocked });
                        } else {
                            $target.attr({ 'checked': 'checked' }).attr({ 'data-islocked': data.islocked });
                        }

                        $target.next().text(data.yesno);
                        return alert(data.msg);
                    } else {
                        if (data.url) {
                            location.href = data.url;
                        } else {
                            if (ischecked) {
                                $target.attr({ 'checked': 'checked' });
                            } else {
                                $target.removeAttr('checked');
                            }
                            return alert(data.msg);
                        }
                    }
                }
            },
            error: function (data) {
                opns.toLogin(data);
            }
        });
    },

    isTakeDoneAjax: function ($target, ischecked, islocked, tid) {
        opns.loadGif();

        $.ajax({
            url: "/isTakeDone",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                tid: tid,
                islocked: islocked
            },
            success: function (data) {
                opns.clearLoadGif();

                if (data) {
                    if (data.ok) {
                        if (ischecked) {
                            $target.removeAttr('checked').attr({ 'data-islocked': data.islocked, 'disabled': 'disabled' });
                        } else {
                            $target.attr({ 'checked': 'checked', 'data-islocked': data.islocked, 'disabled': 'disabled' });
                        }

                        $target.next().text(data.yesno);
                        if(data.yesno == '是'){
                            $target.parent().parent().parent().parent().prev().find('span').eq(1).text('[完成]');
                        }
                        return alert(data.msg);
                    } else {
                        if (data.url) {
                            location.href = data.url;
                        } else {
                            if (ischecked) {
                                $target.attr({ 'checked': 'checked' });
                            } else {
                                $target.removeAttr('checked');
                            }
                            return alert(data.msg);
                        }
                    }
                }
            },
            error: function (data) {
                opns.toLogin(data);
            }
        });
    },

    searchAdmin: function (dirid, stxt) {
        opns.loadGif();

        $.ajax({
            url: "/searchadmin",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                dirid: dirid,
                stxt: stxt
            },
            success: function (data) {
                opns.clearLoadGif();

                if (data && data.ok == false) {
                    return location.href = data.url;
                }

                $('#dirname').text('搜索结果').attr({ 'data-dirid': dirid });
                opns.handleItemsOfDirOrSearch(dirid, data);
            },
            error: function (data) {
                opns.toLogin(data);
            }
        });
    },


    loadGif: function () {
        if (opns.$loading.hasClass('hide')) {
            opns.$loading.removeClass('hide');
        } else {
            opns.$loading.addClass('hide');
        }
    },

    clearLoadGif: function () {
        if (opns.$loading.hasClass('hide') == false) {
            opns.$loading.addClass('hide');
        }
    },

    toLogin: function (data) {
        opns.clearLoadGif();
        console.log(data.responseText);
        alert('操作错误');
    },

};

$(document).ready(function () {
    opns.init();
});
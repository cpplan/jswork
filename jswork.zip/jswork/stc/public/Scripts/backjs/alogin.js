
var opns = {

    $loading: null,
    isconn: null,
    mylan: null,

    loginInit: function () {

        opns.$loading = $('#loading');

        iosBindLoginEnter();

        $('#headimg, #langid').unbind('click').click(function (e) {
            $('.headurlbox').addClass('hide');
            var $headurlbox = $(this).next();
            $headurlbox.removeClass('hide');
            e.stopPropagation();
        });

        $('#language > div').unbind('click').click(function (e) {
            var language = $(this).text();
            var lanid = $(this).attr('lanid');
            $('#langid').text(language).attr(lanid);

            opns.setMyLan(lanid);
            e.stopPropagation();
        });

        $('.headurlbox').unbind('click').click(function (e) {
            e.stopPropagation();
        });

        $('body').unbind('click').click(function () {
            $('.headurlbox').addClass('hide');
        });

        $('#loginSpan').click(function () {
            $('.loginWin').show();
            $('#loginForm').show();
            $('#registForm').hide();
            if (isPc() == true) {
                $('#loginacc').focus();
            }
        });

        $('.winClose').click(function () {
            $('.loginWin').hide();
            $('.loginWin input').val('');
        });

        $('#loginbtn').unbind('click').click(function () {
            opns.login();
        });

        $('#toregist').click(function () {
            $('#loginForm').hide();
            $('#registForm').show();
            if (isPc() == true) {
                $('#registForm input').val('').eq(0).focus();
            }
        });

        $('#tologin').click(function () {
            $('#loginForm').show();
            $('#registForm').hide();
            if (isPc() == true) {
                $('#loginForm input').val('').eq(0).focus();
            }
        });

        $('#registbtn').unbind('click').click(function (e) {
            e.stopPropagation();
            opns.regist();
        });

        if (isPc()) {
            $('#loginacc').focus();
        }

        this.getMyLan();
    },

    login: function () {
        var account = $('#loginacc').val();
        var psw = $('#loginpsw').val();
        if (account.length < 3 || account.length > 30) {
            return alert(opns.mylan.lan5);
        }
        if (psw.length < 3 || psw.length > 16) {
            return alert(opns.mylan.lan6);
        }
        $('#loginbtn').css({ 'background-color': 'silver' });
        this.loginAjax(account, psw);
    },

    regist: function () {
        var account = $('#registacc').val();
        var psw = $('#registpsw').val();
        if (account.length < 3 || account.length > 30) {
            return alert(opns.mylan.lan5);
        }
        if (psw.length < 3 || psw.length > 16) {
            return alert(opns.mylan.lan6);
        }
        $('#registbtn').css({ 'background-color': 'silver' });
        this.registAjax(account, psw);
    },

    loginAjax: function (account, psw) {
        opns.loadGif();

        $.ajax({
            url: "/alogin",
            type: "post",
            async: true,
            cache: false,
            dataType: "JSON",
            data: {
                account: account,
                psw: psw
            },
            success: function (data) {
                opns.clearLoadGif();

                if (!data) {
                    alert(opns.mylan.lan7);
                } else {
                    if (data.ok) {
                        location.href = '/ahome';
                    } else {
                        alert(data.msg);
                    }
                }
                opns.clearLogin();
            },
            error: function (data) {
                opns.clearLogin();
                opns.error(data);
            }
        });
    },

    registAjax: function (account, psw) {
        opns.loadGif();

        $.ajax({
            url: "/aregist",
            type: "post",
            async: true,
            cache: false,
            dataType: "JSON",
            data: {
                account: account,
                psw: psw
            },
            success: function (data) {
                opns.clearLoadGif();

                if (data && data.ok == true) {
                    alert(data.msg);
                    $('#loginForm').show();
                    $('#registForm').hide();
                    $('.loginWin input').val('');
                    if (isPc() == true) {
                        $('#loginacc').focus();
                    }
                } else {
                    alert(opns.mylan.lan79);
                }
                opns.clearLogin();
            },
            error: function (data) {
                opns.clearLogin();
                opns.error(data);
            }
        });
    },

    loadGif: function () {
        if (opns.$loading.hasClass('hide')) {
            opns.$loading.removeClass('hide');
        } else {
            opns.$loading.addClass('hide');
        }
    },

    clearLoadGif: function () {
        if (opns.$loading.hasClass('hide') == false) {
            opns.$loading.addClass('hide');
        }
    },

    clearLogin: function () {
        $('#loginbtn').css({ 'background-color': '#C40522' });
        $('#registbtn').css({ 'background-color': '#C40522' });
    },

    error: function (data) {
        opns.clearLoadGif();
        console.log(data.responseText);
        alert('操作错误');
    },

    setMyLan: function (lanid) {
        $.ajax({
            url: "/setmylan",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {
                lanid: lanid
            },
            success: function (data) {
                location.href = '/ahome';
            },
            error: function (data) {
                opns.error(data);
            }
        });
    },

    getMyLan: function () {
        $.ajax({
            url: "/getmylan",
            type: "get",
            async: true,
            cache: false,
            dataType: "json",
            data: {},
            success: function (data) {
                if (data) {
                    var count = data.length;
                    if (count > 0) {
                        opns.mylan = data[0];
                        // console.log(opns.mylan);
                    }
                }
            },
            error: function (data) {
                opns.error(data);
            }
        });
    },


};


function iosBindLoginEnter() {
    var msginputelem = document.getElementById("loginpsw");
    if (!msginputelem) {
        return;
    }

    msginputelem.addEventListener("keyup", function (e) {
        if (e.key == 'Enter') {
            opns.login();
        }
    });
}

function isPc() {
    var useragent = navigator.userAgent;
    if (useragent.indexOf('Mobile') > -1) {
        return false;
    } else {
        return true;
    }
}
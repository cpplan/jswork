var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var pub = require('./code/pub');

var cookie = require('cookie');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var routes = require('./routes/index');

var session = require('express-session');
var sessionStore = new session.MemoryStore();

var app = express();

app.use(favicon(__dirname + '/public/favicon.ico'));


const http = require('http');
const hostname = 'fin.cx';
const httpServer = http.createServer((req, res) => {
    res.statusCode = 301;
    res.setHeader('Location', `https://${hostname}${req.url}`);
    res.end(); // make sure to call send() or end() to send the response
});


let https = require("https");
var fs = require('fs');
const httpsOption = {
    cert: fs.readFileSync('./ssl/www_fin_cx.crt'),
    ca: fs.readFileSync('./ssl/www_fin_cx.ca-bundle'),
    key: fs.readFileSync('./ssl/fin.cx.key')
}

var httpsServer = https.createServer(httpsOption, app).listen(443);
var io = require('socket.io').listen(httpsServer);

var im = require('./code/im');

var rb = require('./code/rb');
rb.loadRb();

var sqlite = require('./code/sqlite');


// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.set('view options', { layout: false }); //关闭模板引擎

var partials = require('express-partials');
app.use(partials());

//app.use(favicon());
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());

var sessionkey = 'ou09890ro3uou987sfw';
app.use(session({
    //name,设置 cookie 中，保存 session 的字段名称，默认为 connect.sid
    key: sessionkey,
    store: sessionStore,//session 的存储方式，默认存放在内存中，也可以使用 redis，mongodb 等。express 生态中都有相应模块的支持
    secret: 'ilocat',//通过设置的 secret 字符串，来计算 hash 值并放在 cookie 中，使产生的 signedCookie 防篡改
    cookie: { secure: false, maxAge: global.outTime * 60 * 1000 },//设置cookie过期时间 5分钟,
    //当 secure 值为 true 时，cookie 在 HTTP 中是无效，在 HTTPS 中才有效
    resave: true,//是否允许session重新设置
    saveUninitialized: true,//是否设置session在存储容器中可以给修改
    rolling: true //是否按照原设定的maxAge值重设session同步到cookie中
}));

app.use(express.static(path.join(__dirname, 'public'))); //设置静态文件服务器


app.use('/', routes);

/// catch 404 and forward to error handler
app.use(function (req, res, next) {
    var err = new Error('Not Found');
    err.status = 404;
    next(err);
});

/// error handlers
// uncaughtException 避免程序崩溃
process.on('uncaughtException', function (err) {
    console.log('uncaughtException错误:\n', err);
});

// development error handler
// will print stacktrace
// env: production,development
if (app.get('env') === 'development') {
    app.use(function (err, req, res, next) {
        res.status(err.status || 500);
        res.render('error', {
            message: err.message,
            // message: 'Not Found',//未找到指定页面时，显示在页面上的标题
            error: 'err'//显示的错误信息
        });
    });
}

// production error handler
// no stacktraces leaked to user
app.use(function (err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
        message: err.message,
        error: {}
    });
});

app.set('env', 'production');


function getClientIp(req) {
    return req.headers['x-forwarded-for'] ||
    req.connection.remoteAddress ||
    req.socket.remoteAddress ||
    req.connection.socket.remoteAddress;
};

//设置每一個來的socket的session验证
io.use(function (socket, next) {
    console.log(' ');
    var clientip = getClientIp(socket.request);
    console.log('clientip => ', clientip);

    if(clientip.indexOf('137.175.30.110') != -1) {
        console.log('137 ip client');
        return next();
    }

    console.log('设置每一個來的socket连接请求的session验证');
    if (socket.request.headers.cookie) {
        console.log('解析socket请求发送来的cookie，并保存备用');
        socket.request.cookies = cookie.parse(socket.request.headers.cookie);
        next();
    } else {
        console.log('不合规socket连接请求，断开此连接');
        return next(new Error('Server says Missing cookie headers'));
    }
});



function getSession(msgType, socket, clientData) {

    var request = socket.request;

    console.log('getSession() msgType => ', msgType);
    console.log('getSession() clientData => ', clientData);

    cookieParser('ilocat')(request, {}, function (err) {
        request.cookie = cookie.parse(request.headers.cookie);
        var cookieKey = request.cookie[sessionkey];
        if (cookieKey === undefined) {
            console.log('cookieKey is undefined');
            return undefined;
        }
        request.sessionID = cookieParser.signedCookie(cookieKey, 'ilocat');
        request.sessionStore = sessionStore;

        request.sessionStore.get(request.sessionID, function (errs, sess) {

            if (errs) {
                return console.log(errs);
            }
            if (!sess) {
                return console.log('Invalid Session');
            }
            //session.save():把session中的数据重新保存到store中，用内存的内容去替换掉store中的内容。
            //这个方法在HTTP的响应后自动被调用。如果session中的数据被改变了（这个行为可以通过中间件的很多的配置来改变），
            //正因为如此这个方法一般不用显示调用。但是在长连接的websocket中这个方法一般需要手动调用

            request.session = new session.Session(request, sess);
            mysess = request.session;

            if (msgType === 'disconnect') {
                //此时，session中存放的数据已空，mysocket存在，但mysocket.disconnected = undefined
                // var mysocket = global.socketTable.getValues(12);
                // console.log('mysocket  => ', mysocket);
                // console.log('mysocket disconnected => ', mysocket.disconnected, ' end');
                // im.disconnect(mysess.userData.user_id);
                return false;
            }

            // //检查用户是否是登录用户
            if (!mysess || !mysess.userData) {
                return console.log('此连接用户还未登录');
                // return socket.conn.close();
            }

            // console.log('此连接用户已登录过，继续检测是否是重复登录');
            // if (mysess.userData.canreceivmsg != true && zjh.hasInUsertable(mysess.userData.user_id) == true) {
            //     console.log('既不存在可以接收信息的标记，而且还能在用户列表找找到自己同名的账号，说明是重复登录');

            //     console.log('此连接用户重复登录, 找到第一个登录用户的socket，用它通知[账号已在别处登录]');
            //     var firstsock = zjh.getSocket(mysess.userData.user_id);
            //     firstsock.emit('anotherlogin', { msg: '您的账号已在其他地方登录' });
            //     console.log('切断第一个登录用户的socket连接');
            //     firstsock.conn.close();

            //     console.log('通知本次连接的用户，再连接一次');
            //     socket.emit('joinagain');//等待之前的登录用户断开连接，服务器删除此用户的用户信息。之后自己再加入
            //     return;
            // }
            // if (mysess.userData.canreceivmsg != true) {
            //     console.log('接收信息标记没有开启，现在开启并保存');
            //     mysess.userData.canreceivmsg = true;//此标记表明：用户不是重复登录的，可以一直接收用户后续发送的消息
            //     mysess.save();
            // }
            // console.log('接收信息标记已经被标记过，接收到消息');
            // console.log('userData => ', request.session.userData);

            //每次接收到用户的消息请求时，更新session过期时间
            if (!mysess.Cookie) {
                mysess.Cookie = 0;
            } else {
                mysess.Cookie += 1;
            }
            // console.log('request.session =>', socket.client.conn.request.session);
            mysess.save();

            var userdata = mysess.userData;
            var myuid = userdata.user_id;
            // var myacc = userdata.account;

            switch (msgType) {
                case 'join':
                    //如果多个页面的socket加入，则只有最后一个socket被保留，前面的socket会被后面的socket覆盖
                    //所以，通过最后一个加入的socket，可以发布公共信息
                    im.ready(myuid, socket);
                    break;
                // case 'imsendmsg':
                //     var fuserid = clientData.fuserid;
                //     var fuseracc = clientData.fuseracc;
                //     var msg = clientData.tomsg;
                //     im.imSendMsg(socket, myuid, myacc, msg, fuserid);
                //     break;
            }

        });
    });

}



io.of('website').on('connection', function (socket) {

    socket.on('join', function (clientData) {
        console.log('user join stockroom, clientData.page => ', clientData.page);
        console.log('usOpen: ', global.usOpen);
        socket.emit('backheart', { usOpen: global.usOpen, st: pub.getUsEastTime() });

        if(clientData.cntime != 'woefijwofdslsjifg') {
            return console.log(clientData.cntime + ' join bad check');
        }

        getSession('join', socket);
        
        switch(clientData.page) {
            case 'usm':

                socket.join('usStockRoom');
                if(global.usOpen == false) {
                    console.log('休盘中');
                }
                console.log('emit stocktableu in usm');
                socket.emit('stocktableu', {alldata:global.usStockHashTable.getValues()});

                console.log('usMkindexHashTable => ', global.usMkindexHashTable.getKeys());
                var oneUsmkIndexData = global.usMkindexHashTable.getValue('umk');
                console.log('oneUsmkIndexData => ', oneUsmkIndexData);
                if(oneUsmkIndexData) {
                    console.log('emit umk');
                    oneUsmkIndexData.status_off = global.usOpen;
                    socket.emit('umk', oneUsmkIndexData);//将股指和开盘标记信息发给自己
                }

            break;
            case 'hkm':

                socket.join('hkStockRoom');
                if(global.hkOpen == false) {
                    console.log('休盘中');
                } else {
                    console.log('开盘中');
                }
                console.log('emit stocktableh in hkm');
                socket.emit('stocktableh', {alldata:global.hkStockHashTable.getValues()});

                console.log('hkMkindexHashTable => ', global.hkMkindexHashTable.getKeys());
                var oneHkmkIndexData = global.hkMkindexHashTable.getValue('hmk');
                console.log('oneHkmkIndexData => ', oneHkmkIndexData);
                if(oneHkmkIndexData) {
                    console.log('emit hmk');
                    oneHkmkIndexData.status_off = global.hkOpen;
                    socket.emit('hmk', oneHkmkIndexData);//将股指和开盘标记信息发给自己
                }

            break;
            default:
                socket.join('stockroom');
        }
    });

    socket.on('usopen', function (oneIndexData) {
        return;
        //美股开盘与否的标记
        console.log('获取到数据源，usopen => ', oneIndexData);

        if(oneIndexData.check != 'sllweofpwosdjfosjfow') {
            return console.log(oneIndexData.check + ' bad check');
        }
        oneIndexData.check = null;

        global.usOpen = oneIndexData.status_off;

        workers[0].send({whatmsg:'usOpen', usOpen: global.usOpen});
        socket.broadcast.to('usStockRoom').emit('usopen', oneIndexData);//将美股开盘标记和时间，广播到美股页面所有人（自己除外）
    });

    socket.on('umkindex', function (oneIndexData) {
        //收到发来的某个市场指数，先存入数据结构，然后发送给客户端
        console.log('获取到数据源，umkindex => ', oneIndexData);

        if(oneIndexData.check != 'sllweofpwosdjfosjfow') {
            return console.log(oneIndexData.check + ' bad check');
        }
        oneIndexData.check = null;

        global.usMkindexHashTable.add('umk', oneIndexData);
        console.log('此时，所有umkindex key，global.usMkindexHashTable => ', global.usMkindexHashTable.getKeys());

        console.log(' ');
        console.log('emit umk in umkindex');
        oneIndexData.status_off = global.usOpen;//开盘标记
        socket.broadcast.to('usStockRoom').emit('umk', oneIndexData);//将美股指数（包括开盘标记)，广播到美股页面所有人（自己除外）
    });

    socket.on('ustockmsg', function (onestockData) {
        //收到发来的一支股票信息，先存入数据结构，然后发送给客户端
        console.log('获取到数据源，一只股票的onestockData => ', onestockData);

        if(onestockData.check != 'sllweofpwosdjfosjfow') {
            return console.log(onestockData.check + ' bad check');
        }
        onestockData.check = null;

        var stockid = onestockData.nasdaq + ':' + onestockData.stockcode;
        onestockData.stockid = stockid;
        global.usStockHashTable.add(stockid, onestockData);
        console.log('此时，所有股票的key，global.usStockHashTable => ', global.usStockHashTable.getKeys());
        // console.log('此时，所有股票的数据，global.usStockHashTable => ', global.usStockHashTable.getValues());
        
        console.log(' ');
        console.log('将股票数据同时发给worker进程保存');
        workers[0].send({whatmsg:'usOpen', usOpen: global.usOpen});
        workers[0].send({whatmsg:'onestockdataus', onestockdataus:onestockData});

        console.log('emit onestockdataus in ustockmsg');
        socket.broadcast.to('usStockRoom').emit('onestockdatau', onestockData);//将一支美股股票信息广播美股页面所有人（自己除外）
    });


    socket.on('hmkindex', function (oneIndexData) {
        //收到发来的某个市场指数，先存入数据结构，然后发送给客户端
        // console.log('获取到数据源，hmkindex => ', oneIndexData);

        if(oneIndexData.check != 'sllweofpwosdjfosjfow') {
            return console.log(oneIndexData.check + ' bad check');
        }
        oneIndexData.check = null;

        global.hkOpen = oneIndexData.status_off;//开盘标记
        workers[0].send({whatmsg:'hkOpen', hkOpen: global.hkOpen});

        global.hkMkindexHashTable.add('hmk', oneIndexData);
        console.log('此时，所有umkindex key，global.hkMkindexHashTable => ', global.hkMkindexHashTable.getKeys());

        console.log(' ');
        console.log('emit hkm in hmkindex');
        socket.broadcast.to('hkStockRoom').emit('hmk', oneIndexData);//将香港恒生指数（包括开盘标记)，广播到港股页面所有人（自己除外）
    });

    socket.on('hstockmsg', function (onestockData) {
        //收到发来的一支股票信息，先存入数据结构，然后发送给客户端
        // console.log('获取到数据源，hstockmsg一只股票的 => ', onestockData);

        if(onestockData.check != 'sllweofpwosdjfosjfow') {
            return console.log(onestockData.check + ' bad check');
        }
        onestockData.check = null;

        var stockid = onestockData.nasdaq + ':' + onestockData.stockcode;
        onestockData.stockid = stockid;
        global.hkStockHashTable.add(stockid, onestockData);
        console.log('此时，所有股票的key，global.hkStockHashTable => ', global.hkStockHashTable.getKeys());
        // console.log('此时，所有股票的数据，global.hkStockHashTable => ', global.hkStockHashTable.getValues());
        
        console.log(' ');
        console.log('将股票数据同时发给worker进程保存');
        workers[0].send({whatmsg:'hkOpen', hkOpen: global.hkOpen});
        workers[0].send({whatmsg:'onestockdatahk', onestockdatahk:onestockData});

        console.log('emit onestockdatahk in hstockmsg');
        socket.broadcast.to('hkStockRoom').emit('onestockdatah', onestockData);//将一支港股股票信息，广播到港股页面所有人（自己除外）
    });

    socket.on('hkd', function (data) {
        console.log('接收到消息: hkd => ', data);

        if(data.check != '12879898123789460437') {
            return console.log(data.check + ' bad check for hkd');
        }
        data.check = null;

        if(pub.isHkd(data.hkd) == false) {
            return console.log(data.hkd, ' is not HKD');
        }
        var HKD = parseFloat(data.hkd).toFixed(4);
        if(HKD > 6 && HKD < 9) {
            global.usCashRate.HKD = HKD;   
        }
        console.log("global.usCashRate.HKD => ", global.usCashRate.HKD);
        workers[0].send({whatmsg:'hkd', hkd: global.usCashRate.HKD});
    });


    socket.on('centerconnection', function (data) {
        console.log('接收到消息: centerconnection => ', data);

        if(data.check != 97981728376) {
            console.log(data.check + ' bad check for centerconnection');
            return socket.close();
        }
        
        if(data.whiteip) {
            global.okIpTable.add(data.whiteip, data.whiteip);
            console.log('当前websocket连接的客户端IP加入后，白名单: ', global.okIpTable.getValues());
        }

        console.log('centerconnection OK');
        socket.emit('serverok', {msg: 'OK'});
    });

    socket.on('cip', function (data) {
        console.log('接收到消息: cip => ', data);

        if(data.check != 'po0wer0psdi983sw9') {
            return console.log(data.check + ' bad check for cip');
        }
        data.check = null;

        if(!pub.isIpInt(data.ipa1) || !pub.isIpInt(data.ipa2) || !pub.isIpInt(data.ipa3) || !pub.isIpInt(data.ipa4)) {
            return console.log('ipa段不是ip地址');
        }
        if(!pub.isIpInt(data.ipb1) || !pub.isIpInt(data.ipb2) || !pub.isIpInt(data.ipb3) || !pub.isIpInt(data.ipb4)) {
            return console.log('ipb段不是ip地址');
        }

        sqlite.addIp(1, data);
    });

    socket.on('kop', function (data) {
        console.log('接收到消息: kop => ', data);

        if(data.check != 'lsdiuoiweoi097932') {
            return console.log(data.check + ' bad check for cip');
        }
        
        if(data.all == true) {
            console.log('清除白名单 前：', global.okIpTable.getValues());
            global.okIpTable.clear();
            console.log('清除白名单 后：', global.okIpTable.getValues());
            return socket.emit('clear white');
        }

        global.okIpTable.add(data.op, data.op);
        console.log('白名单: ', global.okIpTable.getValues());
    });


    // socket.on('disconnect', function () {
    //     console.log('接收到消息: disconnect');
    //     getSession('disconnect', socket);
    // });

    socket.on('error', function (err) {
        console.log('接收到消息: err => ', err);
    });

    socket.on('heart', function (clientData) {
        console.log('接收到heart => ', clientData);
        console.log('usOpen: ', global.usOpen);
        socket.emit('backheart', { usOpen: global.usOpen, st: pub.getUsEastTime() });
    });
});




const cpuNum = require('os').cpus().length - 1;

var port = 80;
httpServer.listen(port, () => {
    
    console.log(' ');
    console.log('httpServer is ready for', port);

    for (let i = 0; i < cpuNum; i++) {
        listenWorker(workers,i);
    }

});


//独立的工作进程代码

function listenWorker(workers, index) {
    console.log(' ');
    console.log('开始监听工作进程退出的消息，以便重启此进程 =======================================>');

    workers[index].on('exit',((index) => {
        return () => {
            console.log(' ');
            console.log('worker index = ', index, ' 崩溃，重新创建 i = ', index, ' 的woker');
            workers[index] = childProcess.fork('./code/worker.js');
            console.log('新 worker process - ' + workers[index].pid);
            
            listenWorker(workers,index);

            loadWork(workers, index);//加载创建好的进程
        }
    })(index));
}


//依据cpu核心数量，创建工作进程
const childProcess = require('child_process');
let workers = [];
global.workers = workers;

for (let i = 0; i < cpuNum; i++) {
    workers.push(childProcess.fork('./code/worker.js'));
    console.log('worker process - ' + workers[i].pid);
}


loadMatchWoker(workers, cpuNum);//加载所有创建的工作进程


function loadMatchWoker(workers, cpuNum) {
    for (let i = 0; i < cpuNum; i++) {
        loadWork(workers, i);
    }
}

function loadWork(workers, workerIndex) {

    console.log('worker nums : ', workers.length);

    var worker = workers[workerIndex];
    if(worker.isLoaded == true) {
        return console.log('此worker已经被加载过，无需再次加载');
    }
    console.log('此worker没有被加载，开始加载woker .............');
    worker.isLoaded = true;


    worker.on('message', (msg) => {
        console.log(' ');
        console.log('maseter 接收到worker的消息 ==============================>, msg: ', msg);

        if(msg) {
            switch(msg.evt) {
                case 'buyorderok':
                    console.log('buy_user_id : ', msg.buy_user_id);
                    var lanid = global.lanidHashTable.getValue(msg.buy_user_id);
                    console.log('==========> lanid : ', lanid);
                    if(lanid) {
                        var lantip = pub.getLanTipByLanid(lanid);
                        console.log('==========> lantip : ', lantip);
                        if(lantip) {
                            var sendmsg = { ok: true, msg: msg.coin + lantip.lan53 + msg.stockcode + ' ' + msg.canbuynum + lantip.lan54 + msg.buyprice, canbuynum: msg.canbuynum, stockcode: msg.stockcode };
                            im.sendMsg(msg.buy_user_id, 'buyorder', sendmsg);
                        }
                    }
                break;
                case 'sellorderok':
                    console.log('sell_user_id : ', msg.sell_user_id);
                    var lanid2 = global.lanidHashTable.getValue(msg.sell_user_id);
                    if(lanid2) {
                        var lantip2 = pub.getLanTipByLanid(lanid2);
                        if(lantip2) {
                            var msg1 = { ok: true, msg: msg.coin + lantip2.lan83 + msg.stockcode + ' ' + msg.canbuynum + lantip2.lan54 + msg.buyprice, canbuynum: msg.canbuynum, stockcode: msg.stockcode };
                            im.sendMsg(msg.sell_user_id, 'selled', msg1);
                        }
                    }
                break;
            }
        }
    });

    console.log('加载woker结束 .............');
}


//定时判断美股是否开盘，休盘
function checkUsmOpen () {
    if(pub.getStatus_Off_On() == false) {
        global.usOpen = false;
        console.log('call checkUsmOpen: 美股已休盘');
    } else {
        global.usOpen = true;
        console.log('call checkUsmOpen: 美股已开盘');
    }
}

checkUsmOpen();

setInterval(checkUsmOpen, 30000);

var sqlite = require('./sqlite');
var pub = require('./pub');
var HashTable = require('../code/hashtable');



var matchLock = HashTable.HashTableObj();//记录每种股票在线程执行数据库操作的时候的锁。防止多个线程同时执行同种股票的数据库操作

var hkOpen = false;
var usOpen = false;

var usStockHashTable = HashTable.HashTableObj();//存放开盘股票数据

var hkStockHashTable = HashTable.HashTableObj();//存放开盘股票数据

global.coinRate = {
    FNC: 10000,
    BTC: 10000,
    ETH: 1000,
    BCH: 1000
};

//其他法币与美元的汇率
global.usCashRate = {
    HKD: 7.8
};



process.on('message', (msg) => {
    pub.myconsole('worker 接收到master的消息 ==============================>');
    console.log('worker 接收到master的消息: ', msg.whatmsg);

    switch(msg.whatmsg) {
        case 'onestockdataus':
            var stockid = msg.onestockdataus.nasdaq + ':' + msg.onestockdataus.stockcode;
            usStockHashTable.add(stockid, msg.onestockdataus);
            // console.log('此时，所有股票的key，usStockHashTable => ', usStockHashTable.getKeys());
            // console.log('此时，所有股票的数据，usStockHashTable => ', usStockHashTable.getValues());
        break;
        case 'onestockdatahk':
            var stockid = msg.onestockdatahk.nasdaq + ':' + msg.onestockdatahk.stockcode;
            hkStockHashTable.add(stockid, msg.onestockdatahk);
            // console.log('此时，所有股票的key，hkStockHashTable => ', hkStockHashTable.getKeys());
            // console.log('此时，所有股票的数据，hkStockHashTable => ', hkStockHashTable.getValues());
        break;
        case 'usOpen':
            usOpen = msg.usOpen;
            loadMatchUs();
        break;
        case 'hkOpen':
            hkOpen = msg.hkOpen;
            // loadMatchHk();
        break;
        case 'hkd':
            global.usCashRate.HKD = msg.hkd;
        break;
        case 'lockstockanddelbuyorder':
            var stobj = msg.stobj;
            if(stobj && stobj.stockcode && handleMatchLock (matchLock, stobj.stockcode) == true) {
                console.log('worker 还未锁上，删除前，给 ' + stobj.stockcode + ' 加上锁，待删除指定数据后，解锁');
                stobj.workerMatchLock = matchLock;
                sqlite.deleteBuyorder (stobj);
            } else {
                console.log(stobj.stockcode, ' 已锁上，不执行删除');
            }
        break;
    }
});


function matchUs() {
    
    if(nowIndexUs < uslen) {
        
        if(usOpen == false) {
            return pub.myconsole('worker 美股都已休盘');
        }

        var stock = usStocks[nowIndexUs];
        console.log('worker usstock => ', stock);
        nowIndexUs++;

        //向主进程发消息，获取指定股票的现价
        var stockdata = usStockHashTable.getValue(stock.stockcode);
        console.log('worker us stockdata => ', stockdata);
        if (!stockdata) {
            console.log('worker 没有股票' + stock.stockcode + '的数据');
            console.log('worker 所有股票的key，usStockHashTable => ', usStockHashTable.getKeys());
            return;
        }

        if(!pub.isPrice(stockdata.stockprice)) {
            return console.log('worker matchUs() +> ', 'stockdata.stockprice bad');
        }

        var clientData = {coin: stock.coin, stocktype: stock.stocktype, company: stock.company, stockcode: stock.stockcode, nowprice: stockdata.stockprice, usCashRate: global.usCashRate};

        pub.myconsole('worker 调用撮合接口 Us');
        callMatchApi(clientData, 0);//place = 0 代表us

        if(nowIndexUs >= uslen) {
            nowIndexUs = 0;
        }
    } else {
        nowIndexUs = 0;
    }

}

function matchHk() {
    
    if(nowIndexHk < hklen) {
        
        if(hkOpen == false) {
            return pub.myconsole('worker 港股已休盘');
        }

        var stock = hkStocks[nowIndexHk];
        console.log('worker hkstock => ', stock);
        nowIndexHk++;

        //向主进程发消息，获取指定股票的现价
        var stockdata = hkStockHashTable.getValue(stock.stockcode);
        console.log('worker hk stockdata => ', stockdata);
        // console.log('hkStockHashTable => ',hkStockHashTable.getValues());
        if (!stockdata) {
            console.log('worker 没有股票' + stock.stockcode + '的数据');
            console.log('worker 所有股票的key，hkStockHashTable => ', hkStockHashTable.getKeys());
            return;
        }

        if(!pub.isPriceHkd(stockdata.stockprice)) {
            return console.log('worker matchHk() +> ', 'stockdata.stockprice bad');
        }

        var clientData = {coin: stock.coin, stocktype: stock.stocktype, company: stock.company, stockcode: stock.stockcode, nowprice: stockdata.stockprice, usCashRate: global.usCashRate};

        pub.myconsole('worker 调用撮合接口 for Hk');
        callMatchApi(clientData, 1);//place = 1 代表hk

        if(nowIndexHk >= hklen) {
            nowIndexHk = 0;
        }
    } else {
        nowIndexHk = 0;
    }

}


var usStocks = [
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'Apple',
        stockcode: 'NASDAQ:AAPL',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'Facebook',
        stockcode: 'NASDAQ:FB',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'Microsoft',
        stockcode: 'NASDAQ:MSFT',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'Google',
        stockcode: 'NASDAQ:GOOG',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'Oracle',
        stockcode: 'NYSE:ORCL',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'Intel',
        stockcode: 'NASDAQ:INTC',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'Amd',
        stockcode: 'NASDAQ:AMD',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'Nvidia',
        stockcode: 'NASDAQ:NVDA',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'Amazon',
        stockcode: 'NASDAQ:AMZN',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'eBay',
        stockcode: 'NASDAQ:EBAY',
    }
];

var hkStocks = [
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'COPOWER',
        stockcode: 'HK:00001',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'CKISF',
        stockcode: 'HK:01038',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'SHKP',
        stockcode: 'HK:00016',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'HSB',
        stockcode: 'HK:00011',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'MTR',
        stockcode: 'HK:00066',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'Towngas',
        stockcode: 'HK:00003',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'sandschina',
        stockcode: 'HK:01928',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'LINK',
        stockcode: 'HK:00823',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'SCPLC',
        stockcode: 'HK:02888',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'Henderson',
        stockcode: 'HK:00012',
    }
];


var nowIndexUs = 0;
const uslen = usStocks.length;
var usMatchRunning = false;

var nowIndexHk = 0;
const hklen = hkStocks.length;
var hkMatchRunning = false;


function loadMatchUs() {
    console.log('worker loadMatchUs()，开始执行发送需要撮合的股票名的循环 for Us');

    if(usOpen == 1 && uslen > 0 && usMatchRunning == false) {

        usMatchRunning = true;//标记为正在运行状态
        setInterval(matchUs, 30000);
        console.log('worker 美股撮合函数已启动');

    } else {
        return console.log('worker 美股已休盘，或撮合函数已启动。不需要执行loadMatchUs()');
    }
}

function loadMatchHk() {
    console.log('worker loadMatchHk()，开始执行发送需要撮合的股票名的循环 for Hk');

    if(hkOpen == true && hklen > 0 && hkMatchRunning == false) {

        hkMatchRunning = true;//标记为正在运行状态
        setInterval(matchHk, 2000);
        console.log('worker 港股撮合函数已启动');

    } else {
        return console.log('worker 港股已休盘，或撮合函数已启动。不需要执行loadMatchHk()');
    }
}


function callMatchApi(clientData, place) {

    try {
        var coin = clientData.coin;
        var stocktype = clientData.stocktype;
        var company = clientData.company;
        var stockcode = clientData.stockcode;
        var nowprice = clientData.nowprice;

        if(typeof(company) == 'undefined' || typeof(stockcode) == 'undefined') {
            return console.log('worker callMatchApi() +> ', 'special chars 1');
        }
        
        if (!pub.isAbc(coin) || isNaN(global.coinRate[coin]) || !pub.isAbc(stocktype)
         || company != pub.escape(company) || stockcode != pub.escape(stockcode)) {
            return console.log('worker callMatchApi() +> ', 'special chars 2');
        }

        // if(!pub.isPriceHkd(nowprice)) {
        //     return console.log('callMatchApi() +> ', 'nowprice bad');
        // }

        if(handleMatchLock (matchLock, stockcode) == false) {
            return;
        }

        var stobj = {coin: coin, stocktype: stocktype, company: company, stockcode: stockcode, place: place, usCashRate: clientData.usCashRate, workerMatchLock: matchLock};
        return sqlite.matchTrade(stobj, nowprice);
    } catch (error) {
        console.log('worker match error => ', error.message);
    }
}

function handleMatchLock (matchLock, stockcode) {
    //查找是否存在此股票的锁
    if(matchLock.containsKey(stockcode)) {
        //判断是否超时,超过10妙，就更新此锁的value, 为自己的当前时间
        var thetime = matchLock.getValue(stockcode);
        if(Date.now() - thetime >= 10000) {
            console.log('worker ' + stockcode + ' 存在锁，且锁的时间已经超时, 删除此锁，并返回');
            matchLock.remove(stockcode);
        } else {
            console.log('worker ' + stockcode + ' 存在锁，且没有超时，不作任何操作，并返回');
        }
        
        console.log('worker handleMatchLock() +> ', 'has lock');
        return false;//已锁，不可操作数据库
    }

    console.log('worker 没锁，给 ' + stockcode + ' 加上锁，待执行完数据库代码后，解锁');
    matchLock.add(stockcode, Date.now());
    return true;//没锁，可以操作数据库
}
// var cookies = require('cookies');
var sqlite3 = require('sqlite3').verbose();
var db = new sqlite3.Database('./code/db/main.db');
var ipdb = new sqlite3.Database('./code/db/ip.db');
var webwalletdb = new sqlite3.Database('./code/db/webwallet.db');

// var async = require('async');
var pub = require('../code/pub');
var jiami = require('../code/jiami');
var HashTable = require('../code/hashtable');
require('../code/globaldata');


const operate = {
    Insert: 'insert',
    Update: 'update'
}

//每个币种兑换为$的兑换比率
const coinRate = {
    FNC: 10000,
    BTC: 10000,
    ETH: 1000,
    BCH: 1000
};

//交易手续费费率
const stockFeet = {
    FNC: 0.001,
    BTC: 0.001,
    ETH: 0.002,
    BCH: 0.002
};

//证券类型
const stockType = {
    stock: 'stock',
};

var matchBuyorderTable = HashTable.HashTableObj();//存放待参与撮合的买单记录


exports.logincheck = function () {
    db.all("select count(user_id) from tuser", function (err, rows) {
        if (err == null) {
            if (rows.length > 0) {
                return console.log('count => ', rows.length);
            }
        }
        return console.log('login failed');
    });
};

exports.updateHeadUrl = function (res, user_id, headurl) {
    db.run('update tuser set headimg = ? where user_id = ? and islocked = 0', [headurl, user_id], function (err) {
        if (err === null) {
            if (this.changes > 0) {
                // res.json({ ok: true, msg: '设置头像成功' });
            } else {
                // res.json({ ok: false, msg: '设置头像失败' });
            }
        } else {
            console.log('出错: updateHeadUrl()更新数据', err.message);
            return res.json({ ok: false, msg: '操作失败' });
        }
    });
};

exports.getHeadImg = function (res, user_id) {
    db.all("select headimg from tuser where user_id = ? and islocked = 0", [user_id], function (err, rows) {
        if (err === null) {
            if (rows.length === 1) {
                return res.json({ ok: true, headimg: rows[0].headimg });
            }
        }
        res.end(null);
    });
};

exports.aregist = function (res, account, psw) {
    db.all('select admin_id from tadmin where account = ?', [account], function (err, rows) {
        if (err === null) {
            if (rows.length > 0) {
                return res.json({ msg: '账号「' + account + '」已经被使用' });
            } else {
                return addAdmin(res, account, psw);
            }
        } else {
            console.log('出错：regist()查询数据', err.message);
            return res.json({ ok: false, msg: '注册失败，请稍后再试' });
        }
    });
};

function addAdmin(res, account, psw) {

    var psw_sha1 = jiami.getJiamiCode(psw);
    // console.log('psw_sha1: ', psw_sha1);

    db.run('insert into tadmin (account,psw,create_time,islocked) values (?,?,?,?)', [account, psw_sha1, pub.getTimeNow(), 0], function (err) {
        if (err === null) {
            console.log('this.lastID = ' + this.lastID); //lastID == 最后插入行的ID
            if (this.lastID > 0) {
                return res.json({ ok: true, msg: '注册成功' });
            } else {
                return res.json({ ok: false, msg: '注册失败，请稍后再试' });
            }
        } else {
            console.log('出错: addAdmin()插入数据', err.message);
            return res.json({ ok: false, msg: '注册失败，请稍后再试' });
        }
    });

}


exports.regist = function (res, account, psw, email, lantip) {
    db.all('select user_id from tuser where account = ? or email = ?', [account, email], function (err, rows) {
        if (err === null) {
            if (rows.length > 0) {
                return res.json({ msg: account + ' or ' + email + ' ' + lantip.lan50 });
            } else {
                return insertNewAccount(res, account, psw, email, lantip);
            }
        } else {
            console.log('出错：regist()查询数据', err.message);
            return res.json({ ok: false, msg: lantip.lan49 });
        }
    });
};

function insertNewAccount(res, account, psw, email, lantip) {
    //创建新用户账号
    var psw_sha1 = jiami.getJiamiCode(psw);

    db.run('insert into tuser (account,psw,email,isvip,create_time,islocked,headimg) values (?,?,?,?,?,?,?)', [account, psw_sha1, email, 0, pub.getTimeNow(), 0, ''], function (err) {
        if (err === null) {
            if (this.lastID > 0) {
                console.log('创建新账号成功, 新用户ID: ', this.lastID);
                return res.json({ ok: true, msg: lantip.lan9 });
            } else {
                console.log('创建新账号失败');
            }
        } else {
            console.log('操作 出错: insertNewAccount()插入数据', err.message);
        }
        return res.json({ ok: false, msg: lantip.lan49 });
    });
}


exports.login = function (req, res, account, psw) {

    var psw_sha1 = jiami.getJiamiCode(psw);

    db.all("select * from tuser where account = ? and psw = ? and islocked = 0", [account, psw_sha1], function (err, rows) {
        if (err === null) {
            if (rows.length === 1) {
                console.log('login rows => ', rows);

                //登录的时候，查询自己的账号是否已经存在各种币的余额记录。如果没有：为每种不存在的币余额创建记录
                findCoins(rows[0].user_id);

                var userData = {
                    user_id: rows[0].user_id,
                    account: account,
                    psw: psw,
                    loginTime: pub.getTimeNow(),
                    // headimg: rows[0].headimg,
                };
                req.session.userData = userData;
                req.session.save();
                console.log('userData => ', userData);
                // setHttpCookie(res, userData.account, userData.psw); //登录成功后，设置cookie
                var lantip = pub.getLanTip(req);
                return res.json({ ok: true, msg: lantip.lan8 });
            }
        }
        res.end(null);
    });

};

function findCoins(user_id) {
    console.log('开始查找所有支持的币种...');
    db.all("select coin from tcointype where islocked = 0", function (err, rows) {
        if (err == null) {
            console.log('rows => ', rows);
            var count = rows.length;
            if (count > 0) {
                console.log('已找到所有支持的币种');

                for (var i = 0; i < count; i++) {
                    //检查登录用户的几个币种的充币地址是否存在。如果存在：不操作；不存在：先查找未被使用的币地址记录，然后占据之
                    hasCoinAddress(user_id, rows[i].coin);
                }

            } else {
                console.log('没有找到任何支持的币种');
            }
        } else {
            console.log('出错: findCoins() 查询数据', err.message);
        }
    });
}

function hasCoinAddress(user_id, coin) {
    console.log('检查登录用户是否已经拥有了' + coin + '币种的一个充币地址');
    db.all('select usercoin_id from tusercoin where user_id = ? and coin = ? order by usercoin_id asc limit 0,1', [user_id, coin], function (err, rows) {
        console.log('hasCoinAddress rows: ', rows);
        if (err === null) {
            if (rows.length > 0) {
                console.log('找到登录用户的一个' + coin + '充币地址: ', rows[0].usercoin_id, '，无须操作');
            } else {
                console.log('没有找到登录用户的一个' + coin + '充币地址, 需要找到一个未被使用的充币地址，并占据它');
                return findAndTakeUnuseTopupaddress(user_id, coin);
            }
        } else {
            console.log('出错: hasCoinAddress()查询数据', err.message);
        }
    });
}

function findAndTakeUnuseTopupaddress(user_id, coin) {
    console.log('选择一个没有被其他用户占用的充币地址');
    db.all('select usercoin_id from tusercoin where user_id = 0 and coin = ? and islocked = 0 order by usercoin_id asc limit 0,1', [coin], function (err, rows) {
        console.log('findAndTakeUnuseTopupaddress rows: ', rows);
        if (err === null) {
            if (rows.length > 0) {
                var usercoin_id = rows[0].usercoin_id;
                console.log('找到一个可用的' + coin + '充币地址: ', usercoin_id);
                return takeCoinAddress(user_id, usercoin_id);
            } else {
                console.log('没有找到可用的' + coin + '充币地址');
            }
        } else {
            console.log('出错: findAndTakeUnuseTopupaddress()查询数据', err.message);
        }
    });
}

function takeCoinAddress(user_id, usercoin_id) {
    console.log('让新用户占据未被使用的充币地址');
    db.run('update tusercoin set user_id = ? where usercoin_id = ? and user_id = 0 and islocked = 0', [user_id, usercoin_id], function (err) {
        if (err === null) {
            if (this.changes > 0) {
                console.log('让新用户占据这个充币地址成功');
            } else {
                console.log('让新用户占据这个充币地址失败');
            }
        } else {
            console.log('出错: takeCoinAddress()更新数据', err.message);
        }
    });
}



exports.alogin = function (req, res, account, psw) {

    var psw_sha1 = jiami.getJiamiCode(psw);
    // console.log('psw_sha1: ', psw_sha1);

    db.all("select * from tadmin where account = ? and psw = ? and islocked = 0", [account, psw_sha1], function (err, rows) {
        console.log('alogin rows => ', rows);
        if (err === null) {
            if (rows.length === 1) {
                var userData = {
                    admin_id: rows[0].admin_id,
                    account: account,
                    psw: psw,
                    usertype: 1,
                };
                req.session.userData = userData;
                req.session.save();
                console.log('userData => ', userData);
                // setHttpCookie(res, userData.account, userData.psw); //登录成功后，设置cookie
                var lantip = pub.getLanTip(req);
                return res.json({ ok: true, msg: lantip.lan8 });
            }
        }
        res.end(null);
    });

};

function setHttpCookie(res, account, psw) {
    var cookie_data = {
        gb: account,
        mb: psw
    };
    res.setHeader('Set-Cookie', ['cookieData=' + JSON.stringify(cookie_data)], { maxAge: 1000 * 60 * 60 * 24 * 365, path: '/', httpOnly: true });
}


exports.getNumsOfMyStocks = function (res, user_id, coin, stocktype) {

    db.all("select stock_id, stockcode, stocknum from tstock where user_id = ? and coin = ? and stocktype = ? and islocked = 0", [user_id, coin, stocktype], function (err, rows) {
        console.log('getNumsOfMyStocks => ', rows);
        if (err === null) {
            if (rows.length > 0) {
                return res.json(rows);
            } else {
                return res.json([]);
            }
        } else {
            console.log('error: getNumsOfMyStocks() => ', err.message);
            return res.json([]);
        }
    });

};




exports.createBuyOrderForUsHkRb = function (coin, stocktype, company, stockcode, buynum, buyprice, buy_user_id, place) {

    myconsole('createBuyOrderForUsHkRb');

    /**
     * 每只股票的未被撮合完成的买单少于3条，就自动新增1条
     */
    db.all("select count(buyorder_id) from tbuyorder where coin = ? and stocktype = ? and stockcode = ? and buynum > boughtnum", [coin, stocktype, stockcode], function (err, rows) {
        console.log('createBuyOrderForUsHkRb rows => ', rows);
        if (err == null) {

            var row = rows[0];
            if (row && row['count(buyorder_id)'] < 3) {
                switch(place) {
                    case 0:
                        createBuyOrderForUsRb (coin, stocktype, company, stockcode, buynum, buyprice, buy_user_id)
                        break;
                    case 1:
                        createBuyOrderForHkRb (coin, stocktype, company, stockcode, buynum, buyprice, buy_user_id)
                        break;
                }
            } else {
                if(pub.getRandomBetweenZeroToNine() > 6) {
                    console.log('随机确定是否删除 3 条未被撮合买单中的 1 条，通知worker进行删除操作: ', stockcode);
                    noticeWorkerDelBuyorder (coin, stocktype, stockcode, buy_user_id);
                }
            }

        } else {
            console.log('createBuyOrderForUsHkRb : ', err.message);
        }
    });

}

function createBuyOrderForUsRb (coin, stocktype, company, stockcode, buynum, buyprice, buy_user_id) {

    var stockdata = global.usStockHashTable.getValue(stockcode);
    if (!stockdata) {
        return console.log(' usrb 股票数据不存在：', stockcode);
    }

    if (buyprice > 0 && pub.isPrice(buyprice)) {
        console.log(' usrb 用户设置了最高买入限价');
        buyprice = Number(parseFloat(buyprice).toFixed(2));//用户设定的最高买入限价
    } else {
        console.log(' usrb 用户选择按市价买入');
        buyprice = 0;
    }

    db.run('insert into tbuyorder (coin, stocktype, company, stockcode, buynum, buyprice, buytime, buy_user_id, boughtnum, islocked, remarks) values (?,?,?,?,?,?,?,?,?,?,?)'
        , [coin, stocktype, company, stockcode, buynum, buyprice, pub.getTimeNow(), buy_user_id, 0, 0, 0], function (err) {
            if (err === null) {
                if (this.lastID > 0) {
                    console.log(coin + '新增 ' + buy_user_id + ' 的买单 ' + stockcode + ' 成功 usrb');
                } else {
                    console.log(coin + '新增 ' + buy_user_id + ' 的买单 ' + stockcode + ' 失败 usrb');
                }
            } else {
                console.log(' usrb 出错: createBuyOrderForUs()插入数据', err.message);
            }
        });
};

function createBuyOrderForHkRb (coin, stocktype, company, stockcode, buynum, buyprice, buy_user_id) {

    var stockdata = global.hkStockHashTable.getValue(stockcode);
    if (!stockdata) {
        return console.log(' hkrb 股票数据不存在：', stockcode);
    }
    
    if (buyprice != 'checkbox' && pub.isPriceHkd(buyprice)) {
        console.log(' hkrb 用户设置了最高买入限价');
        buyprice = Number(parseFloat(buyprice).toFixed(3));//用户设定的最高买入限价
    } else {
        console.log(' hkrb 用户选择按市价买入');
        buyprice = 0;
    }

    db.run('insert into tbuyorder (coin, stocktype, company, stockcode, buynum, buyprice, buytime, buy_user_id, boughtnum, islocked, remarks) values (?,?,?,?,?,?,?,?,?,?,?)'
        , [coin, stocktype, company, stockcode, buynum, buyprice, pub.getTimeNow(), buy_user_id, 0, 0, 0], function (err) {
            if (err === null) {
                if (this.lastID > 0) {
                    console.log(coin + '新增 ' + buy_user_id + ' 的买单 ' + stockcode + ' 成功 hkrb');
                } else {
                    console.log(coin + '新增 ' + buy_user_id + ' 的买单 ' + stockcode + ' 失败 hkrb');
                }
            } else {
                console.log(' hkrb 出错: createBuyOrderForHk()插入数据', err.message);
            }
        });
};

function noticeWorkerDelBuyorder (coin, stocktype, stockcode, buy_user_id) {
    // console.log('global.workers => ', global.workers);
    var worker = global.workers[0];
    if(worker) {
        console.log('lockstockanddelbuyorder msg');
        var stobj = {coin: coin, stocktype: stocktype, stockcode: stockcode, buy_user_id: buy_user_id};
        var mathLockMsg = {whatmsg: 'lockstockanddelbuyorder', stobj: stobj};
        worker.send(mathLockMsg);
    } else {
        console.log('>>>>>>>>>>>> lockstockanddelbuyorder msg error <<<<<<<<<<');
    }
};

exports.deleteBuyorder = function (stobj) {

    console.log('删除一条价格最小，时间最早的rb的买单记录');
    db.run('delete from tbuyorder where buyorder_id in (select buyorder_id from tbuyorder where coin = ? and stocktype = ? and stockcode = ? and boughtnum = 0 and buy_user_id = ? order by buyprice asc, buytime desc limit 0,1)'
    , [stobj.coin, stobj.stocktype, stobj.stockcode, stobj.buy_user_id], function (err) {
        if (err === null) {
            if (this.changes > 0) {
                console.log(stobj.stockcode, ' rb 成功：删除买单 ', stobj.buy_user_id);
            } else {
                console.log(stobj.stockcode, ' rb 失败：删除买单 ', stobj.buy_user_id);
            }
        } else {
            console.log('操作错误: deleteBuyorder() 删除记录 rb', err.message);
        }
        unlockMatchSimple(stobj);
    });

};



exports.createBuyOrderForUs = function (res, coin, stocktype, company, stockcode, buynum, buyprice, buy_user_id, lantip) {

    var stockdata = global.usStockHashTable.getValue(stockcode);
    if (!stockdata) {
        return res.json({ ok: false, msg: lantip.lan51 });
    }

    if (buyprice != 'checkbox' && pub.isPrice(buyprice)) {
        console.log('用户设置了最高买入限价');
        buyprice = Number(parseFloat(buyprice).toFixed(2));//用户设定的最高买入限价
    } else {
        console.log('用户选择按市价买入');
        buyprice = 0;
    }

    db.run('insert into tbuyorder (coin, stocktype, company, stockcode, buynum, buyprice, buytime, buy_user_id, boughtnum, islocked, remarks) values (?,?,?,?,?,?,?,?,?,?,?)'
        , [coin, stocktype, company, stockcode, buynum, buyprice, pub.getTimeNow(), buy_user_id, 0, 0, 0], function (err) {
            if (err === null) {
                if (this.lastID > 0) {
                    console.log(coin + '新增 ' + buy_user_id + ' 的买单 ' + stockcode + ' 成功');
                    return res.json({ok: true, msg: stockcode + lantip.lan81});
                } else {
                    console.log(coin + '新增 ' + buy_user_id + ' 的买单 ' + stockcode + ' 失败');
                }
            } else {
                console.log('出错: createBuyOrderForUs()插入数据', err.message);
            }
            return res.json({ok: false, msg: stockcode + lantip.lan82});
        });
};

exports.createBuyOrderForHk = function (res, coin, stocktype, company, stockcode, buynum, buyprice, buy_user_id, lantip) {

    var stockdata = global.hkStockHashTable.getValue(stockcode);
    if (!stockdata) {
        return res.json({ ok: false, msg: lantip.lan51 });
    }
    
    if (buyprice != 'checkbox' && pub.isPriceHkd(buyprice)) {
        console.log('用户设置了最高买入限价');
        buyprice = Number(parseFloat(buyprice).toFixed(3));//用户设定的最高买入限价
    } else {
        console.log('用户选择按市价买入');
        buyprice = 0;
    }

    db.run('insert into tbuyorder (coin, stocktype, company, stockcode, buynum, buyprice, buytime, buy_user_id, boughtnum, islocked, remarks) values (?,?,?,?,?,?,?,?,?,?,?)'
        , [coin, stocktype, company, stockcode, buynum, buyprice, pub.getTimeNow(), buy_user_id, 0, 0, 0], function (err) {
            if (err === null) {
                if (this.lastID > 0) {
                    console.log(coin + '新增 ' + buy_user_id + ' 的买单 ' + stockcode + ' 成功');
                    return res.json({ok: true, msg: stockcode + lantip.lan81});
                } else {
                    console.log(coin + '新增 ' + buy_user_id + ' 的买单 ' + stockcode + ' 失败');
                }
            } else {
                console.log('出错: createBuyOrderForHk()插入数据', err.message);
            }
            return res.json({ok: false, msg: stockcode + lantip.lan82});
        });
};



function myconsole(funcName) {
    console.log(' ');
    console.log(funcName,'() ====>');
}

/**
 * 买单：
 * 
 * 一、用户手动填写最高买入价
 * A.买入价 >= 市价
 * B.买入价 < 市价
 *
 * 二、用户点击复选框，选择按市价买入
 * C.买入价按市价（buyprice = 0），也就是找到此买单后，用市价作为买入价: buyprice = nowprice
 *
 * 三、测试
 * D.买入价只有3种可能性（与市价比较）
 * 1.买入价 > 市价
 * 2.买入价 = 市价
 * 3.买入价 < 市价
 *
 * E.从上述3种买入价买单中，可以确定参与撮合的最高买入价，要么 = 市价，要么 != 市价
 * F.原则是：找出所有买单中（设定了买入价，和按市价买入的），价格最大的那个。所以，先查询：买入价 != 0（市价），然后查询：买入价 = 0（市价）。比较2次查询的买入价，最大者参与撮合
 */

exports.matchTrade = function (stobj, nowprice) {

    myconsole('matchTrade');
    console.log('按非市价，时间最早，以及其他指定条件，先筛选出 2 个不同的用户id。然后，查找此 2 个buy_user_id的所有非市价买单记录');

    var sql1 = 'select buyorder_id, buynum, buyprice, buy_user_id, boughtnum, buytime from tbuyorder where buy_user_id '
                + 'in (select DISTINCT buy_user_id from tbuyorder where coin = ? and stocktype = ? and stockcode = ? '
                + 'and buynum > boughtnum and buyprice > 0 and islocked = 0 and remarks = 0 order by buyprice desc, buytime desc limit 0,2) and '
                + 'coin = ? and stocktype = ? and stockcode = ? and buynum > boughtnum and buyprice > 0 and islocked = 0 and remarks = 0 order by buyprice desc, buytime desc';
    var sqlparams = [stobj.coin, stobj.stocktype, stobj.stockcode, stobj.coin, stobj.stocktype, stobj.stockcode];

    db.all(sql1, sqlparams, function (err, rows) {
        console.log('matchTrade() rows => ', rows);
        if (err == null) {

            var len = rows.length;
            if (len > 0) {

                console.log('继续筛选：分别去掉 2（可能只有1个用户的记录） 个用户的多余的记录，都只留下价格最大的那条记录');

                console.log('rows的第一条记录，作为第一个用户的记录，然后依据buy_user_id, 取出他所有的买单记录，存入一个数组。并将不等于此buy_user_id的记录，存入另一个数组。分别计算他们各自的最大买价记录');
                var user1 = [];//存放一个用户的符合条件的买单记录
                var user2 = [];
                var temp_buy_user_id_1 = rows[0].buy_user_id;//第一个用户的id

                for(var i = 0; i < len; i++) {
                    var row = rows[i];
                    if(temp_buy_user_id_1 == row.buy_user_id) {
                        user1.push(row);//属于user1的买单记录
                    } else {
                        user2.push(row);
                    }
                }

                console.log('开始筛选 2 个用户各自的最大买价记录，筛选前：');
                console.log('user1 => ', user1);
                console.log('user2 => ', user2);

                while(user1.length > 1) {
                    //每次比较前 2 条记录的价格，价格小的记录被删除，直至剩下 1 条记录
                    if(user1[0].buyprice < user1[1].buyprice) {
                        user1.splice(0, 1);
                    } else {
                        user1.splice(1, 1);
                    }
                }

                while(user2.length > 1) {
                    //每次比较前 2 条记录的价格，价格小的记录被删除，直至剩下 1 条记录
                    if(user2[0].buyprice < user2[1].buyprice) {
                        user2.splice(0, 1);
                    } else {
                        user2.splice(1, 1);
                    }
                }

                console.log('筛选完成后：');
                console.log('user1 => ', user1);
                console.log('user2 => ', user2);

                var buyorder1 = user1[0];
                var buyorder2 = user2[0];

                if(!buyorder1 || !buyorder2) {
                    console.log('只有 1 个用户的买单存在，需要将按市价买入的买单包含进来，参与撮合。以防如果此买单撮合不成功（可能与符合价格条件的卖单是同一个用户），可以继续以其他用户的市价来参与撮合');
                    return findTopBuyorderWithMarketPrice (stobj, nowprice, buyorder1, buyorder2);
                }

                console.log('现在的市价为: ', nowprice);
                if(buyorder1.buyprice > nowprice && buyorder2.buyprice > nowprice) {
                    console.log('2 个用户的买入价，都 > 现在的市价，则无须将此 2 用户的按市价买入的买单包含进来参与撮合。因为如果 > 市价的买单都不能撮合成功，= 市价的买单更不可能撮合成功');

                    if(buyorder1.buyprice > buyorder2.buyprice) {
                        var first = buyorder1;
                        var second = buyorder2;
                    } else {
                        var first = buyorder2;
                        var second = buyorder1;
                    }

                    addMatchBuyorder(stobj, second, nowprice);
                    findLessThanLowestPriceInSellOrder(first.buyorder_id, stobj, first.buynum - first.boughtnum, first.buyprice, first.buy_user_id, nowprice);
                } else {
                    console.log('现在的市价 > 2 个用户至少其中的一个买入价，故，需要将按市价买入的买单包含进来，参与撮合。需要先按价格大小确定谁第一个参与撮合，谁最后参与撮合（如果撮合不成功的话）');
                    findTopBuyorderWithMarketPrice (stobj, nowprice, buyorder1, buyorder2);
                }

            } else {
                console.log('先筛选出 2 个用户id不同，购买价格处于最前面的 n 条买单记录: 没有记录。继续查找按市价购买的买单记录。');
                return findTopBuyorderWithMarketPrice (stobj, nowprice, buyorder1, buyorder2);
            }

        } else {
            console.log('matchTrade error : ', err.message);
            return unlockMatch(stobj);
        }
    });

};

function findTopBuyorderWithMarketPrice (stobj, nowprice, buyorder1, buyorder2) {

    //buyorder1, buyorder2有可能为空，需要据此做出设计

    myconsole('findTopBuyorderWithMarketPrice');
    console.log('nowprice, buyorder1, buyorder2 ', nowprice, buyorder1, buyorder2);
    console.log('按市价，时间最早，以及其他指定条件，先筛选出 1 个不同于 buyorder1, buyorder2 的用户id。然后，查找此buy_user_id的所有按市价买入的买单记录中，时间最早的那条记录');

    var buy_user_id_1 = buyorder1 && buyorder1.length == 1 ? buyorder1.buy_user_id : 0;
    var buy_user_id_2 = buyorder2 && buyorder2.length == 1 ? buyorder2.buy_user_id : 0;

    var sql = "select buyorder_id, buynum, buyprice, buy_user_id, boughtnum, buytime from tbuyorder where coin = ? and stocktype = ? and stockcode = ? and buynum > boughtnum and buyprice = 0 and islocked = 0 and remarks = 0 and buy_user_id != ? and buy_user_id != ? order by buytime desc limit 0,1";
    var sqlparams = [stobj.coin, stobj.stocktype, stobj.stockcode, buy_user_id_1, buy_user_id_2];

    db.all(sql, sqlparams, function (err, rows) {
        console.log('findTopBuyorderWithMarketPrice() rows => ', rows);
        if (err == null) {

            var buyorder123 = [];//存储等待按买价排列的买单记录
            if(buyorder1) {
                buyorder123.push(buyorder1);
            }
            if(buyorder2) {
                buyorder123.push(buyorder2);
            }
            
            if (rows.length > 0) {
                rows[0].buyprice = Number(nowprice);
                var buyorder3 = rows[0];
                buyorder123.push(buyorder3);
            }
            

            console.log('比较buyorder123中： buyorder1, buyorder2, buyorder3，依据价格大小，依次传入撮合函数');
            var len = buyorder123.length;

            if(len == 0) {
                console.log('没有找到符合条件的买单记录，结束本次撮合');
                return unlockMatch(stobj);
            }

            if(len == 1) {
                var first = buyorder123[0];
                console.log('只有 1 个符合条件的买单记录, first : ', first);
                return findLessThanLowestPriceInSellOrder(first.buyorder_id, stobj, first.buynum - first.boughtnum, first.buyprice, first.buy_user_id, nowprice);
            }

            if(len == 2) {
                console.log('有 2 个符合条件的买单记录，先按买单价格排序，然后用最大价格的记录参与撮合，剩余的那个存入table中，等待本次撮合结束后，将其也参与撮合');

                if(buyorder123[0].buyprice >= buyorder123[1].buyprice) {
                    var first = buyorder123[0];
                    var second = buyorder123[1];
                } else {
                    var first = buyorder123[1];
                    var second = buyorder123[0];
                }

                console.log('first, second : ', first, second);
                addMatchBuyorder(stobj, second, nowprice);
                return findLessThanLowestPriceInSellOrder(first.buyorder_id, stobj, first.buynum - first.boughtnum, first.buyprice, first.buy_user_id, nowprice);
            }

            if(len == 3) {
                console.log('有 3 个符合条件的买单记录，先按买单价格排序，然后用最大价格的记录参与撮合，剩余的那 2 个存入table中，等待本次撮合结束后，将其也参与撮合');

                if(buyorder1.buyprice >= buyorder2.buyprice && buyorder1.buyprice >= nowprice) {
                    
                    if(buyorder2.buyprice > nowprice) {
                        var first = buyorder1;
                        var second = buyorder2;
                        var third = buyorder3;
                    } else {
                        var first = buyorder1;
                        var second = buyorder3;
                        var third = buyorder2;
                    }

                } else {
                    
                    if(buyorder2.buyprice >= buyorder1.buyprice && buyorder2.buyprice >= nowprice) {

                        if(buyorder1.buyprice > nowprice) {
                            var first = buyorder2;
                            var second = buyorder1;
                            var third = buyorder3;
                        } else {
                            var first = buyorder2;
                            var second = buyorder3;
                            var third = buyorder1;
                        }

                    } else {

                        if(nowprice >= buyorder1.buyprice && nowprice >= buyorder2.buyprice) {
                            
                            if( buyorder1.buyprice > buyorder2.buyprice) {
                                var first = buyorder3;
                                var second = buyorder1;
                                var third = buyorder2;
                            } else {
                                var first = buyorder3;
                                var second = buyorder2;
                                var third = buyorder1;
                            }

                        }

                    }

                }

                console.log('first, second, third : ', first, second, third);
                
                addMatchBuyorder(stobj, second, nowprice);
                addMatchBuyorder(stobj, third, nowprice, 3);
                return findLessThanLowestPriceInSellOrder(first.buyorder_id, stobj, first.buynum - first.boughtnum, first.buyprice, first.buy_user_id, nowprice);
            }

        } else {
            console.log('matchTrade error : ', err.message);
            return unlockMatch(stobj);
        }
    });

};


function addMatchBuyorder(stobj, second, nowprice, third_3) {
    myconsole('addMatchBuyorder');

    var key = stobj.stockcode;
    if(third_3) {
        key = key + '_3';//标记为存入了第三个待撮合的买单记录
    }

    if(matchBuyorderTable.containsKey(key) == false) {
        console.log('addMatchBuyorder key => ', key);
        var stobj2 = {coin: stobj.coin, stocktype: stobj.stocktype, company: stobj.company, stockcode: stobj.stockcode, place: stobj.place, usCashRate: stobj.usCashRate};
        var second2 = {buyorder_id: second.buyorder_id, buynum: second.buynum - second.boughtnum, buyprice: second.buyprice, buy_user_id: second.buy_user_id, buytime: second.buytime};
        
        var matchObj2 = {order: second2, stobj: stobj2, nowprice: Number(nowprice)};
        matchBuyorderTable.add(key, matchObj2);
    }
    console.log('addMatchBuyorder matchBuyorderTable keys => ', matchBuyorderTable.getKeys());
    console.log('addMatchBuyorder matchBuyorderTable => ', matchBuyorderTable.getValues());
}

function unlockMatchSimple(stobj) {
    //直接简单的删除指定名称的锁
    myconsole('unlockMatchSimple');
    console.log('stobj.workerMatchLock => ', stobj.workerMatchLock.getKeys());

    var stockcode = stobj.stockcode;
    var workerMatchLock = stobj.workerMatchLock;//工作进程中传递过来的锁
    if(workerMatchLock) {
        workerMatchLock.remove(stockcode);
    }
    console.log(' ');
}

function unlockMatch (stobj, matchOk) {
    myconsole('unlockMatch');
    console.log('stobj.workerMatchLock => ', stobj.workerMatchLock.getKeys());

    var stockcode = stobj.stockcode;
    var workerMatchLock = stobj.workerMatchLock;//工作进程中传递过来的锁

    var key3 = stockcode + '_3';
    if(matchOk == true) {
        console.log('本次交易撮合成功，先删除待候补执行撮合的买单，并解锁：', stockcode, ', 本轮撮合结束。');
        matchBuyorderTable.remove(stockcode);
        matchBuyorderTable.remove(key3);

        if(workerMatchLock) {
            workerMatchLock.remove(stockcode);
        }
        return;
    }

    console.log('本次交易没有撮合成功，判断是否要执行候补买单，参与撮合');
    console.log('unlockMatch matchBuyorderTable keys => ', matchBuyorderTable.getKeys());
    console.log('unlockMatch matchBuyorderTable => ', matchBuyorderTable.getValues());

    if(matchBuyorderTable.containsKey(stockcode) == false && matchBuyorderTable.containsKey(key3) == false) {

        console.log('数据库操作执行完成，或执行中发生错误，' + stockcode + ' 已经解锁。可以开始下次的matchTrade()');
        if(workerMatchLock) {
            workerMatchLock.remove(stockcode);
        }
        console.log(' ');

    } else {

        console.log('本次交易没有撮合成功，正在判断是否存在排第 2 位的候补买单...');
        var matchObj = matchBuyorderTable.getValue(stockcode);
        console.log('排第 2 位的候补买单：matchObj 2 => ', matchObj);
        if(!matchObj) {
            console.log('排第 2 位的候补买单，不存在。继续查找是否存在排第 3 位的候补买单');
            matchObj = matchBuyorderTable.getValue(key3);
            console.log('排第 3 位的候补买单：matchObj 3 => ', matchObj);
        }
        if(!matchObj) {
            return console.log('matchBuyorderTable 已不存在 ', stockcode, ' 的所有候补买单，结束撮合');
        }
        
        var newstobj = {coin: matchObj.stobj.coin, stocktype: matchObj.stobj.stocktype, company: matchObj.stobj.company, stockcode: matchObj.stobj.stockcode
                    , place: matchObj.stobj.place, usCashRate: matchObj.stobj.usCashRate, workerMatchLock: stobj.workerMatchLock};

        var buyorder_id = matchObj.order.buyorder_id;
        var buynum = matchObj.order.buynum;
        var buyprice = matchObj.order.buyprice;
        var buy_user_id = matchObj.order.buy_user_id;
        var nowprice = matchObj.nowprice;

        if(matchBuyorderTable.containsKey(stockcode)) {
            console.log('matchBuyorderTable 删除排第 2 位的 ', stockcode);
            matchBuyorderTable.remove(stockcode);
        } else if (matchBuyorderTable.containsKey(key3)) {
            console.log('matchBuyorderTable 删除排第 3 位的 ', key3);
            matchBuyorderTable.remove(key3);
        }
        console.log('移除要被执行的候补买单后：matchBuyorderTable => ', matchBuyorderTable.getValues());

        console.log('执行候补买单，接着参与撮合');
        findLessThanLowestPriceInSellOrder(buyorder_id, newstobj, buynum, buyprice, buy_user_id, nowprice);
        
    }
};



/**
 * 从卖单（设定了最低卖价和按照市价出售的卖单）这2种卖单中，找出价格最低的记录，参与撮合
 * 
 * 卖单：
 *
 * 一、设定了最低卖出价
 * A.最小的卖出价 <= 最大的买入价，才能成交（与市价无关）
 * C.卖出价 > 最大的买入价（不能撮合）
 *
 * 二、用户点击复选框，选择按市价卖出（lowestprice = 0），也就是找到此卖单后，用市价作为卖出价: sellprice = nowprice
 * B.当前的市价 <= 最大的买入价，才能成交（与市价有关）
 *
 * 三、测试
 * D.卖出价只有3种可能性（与市价比较）
 * 1.卖出价 < 市价
 * 2.卖出价 = 市价
 * 3.卖出价 > 市价
 *
 * E.从上述3种卖出价卖单中，可以确定参与撮合的最低卖出价，要么 = 市价，要么 != 市价
 * F.原则是：找出所有卖单中（设定了卖出价，和按市价卖出的），价格最小的那个。所以，先查询：卖出价 = 0（市价），然后查询：卖出价 != 0（设定了最低卖价），比较这2次查询的卖价，最低者可以参与撮合
 */
function findLessThanLowestPriceInSellOrder(buyorder_id, stobj, buynum, topbuyprice, buy_user_id, nowprice) {

    myconsole('findLessThanLowestPriceInSellOrder');

    /**
     * ①.先查找设置了最低卖价的卖单，且卖家id != 买家id，价格按asc排列，时间按desc排列，获取最上面的一条
     * （卖出价格最低优先，时间最先优先原则）
     */
    console.log('buy_user_id, stobj, buynum, topbuyprice, nowprice: ', buy_user_id, stobj, buynum, topbuyprice, nowprice);

    db.all("select sellorder_id, sellnum, lowestprice, sell_user_id, sellednum from tsellorder where coin = ? and stocktype = ? and stockcode = ? and sellnum > sellednum and lowestprice > 0 and sell_user_id != ? and islocked = 0 order by lowestprice asc, thetime desc limit 0,1"
        , [stobj.coin, stobj.stocktype, stobj.stockcode, buy_user_id], function (err, rows) {
            console.log(' ');
            console.log('findLessThanLowestPriceInSellOrder rows => ', rows);
            if (err == null) {

                var lowestprice = rows.length == 0 ? 0 : rows[0].lowestprice;// 按 != 0 市价，查询出来的最低卖出价


                //②.接着查找设置为现价卖出的卖单，且卖家id != 买家id，依据时间按asc排列，获取最上面一条
                db.all("select sellorder_id, sellnum, lowestprice, sell_user_id, sellednum from tsellorder where coin = ? and stocktype = ? and stockcode = ? and sellnum > sellednum and lowestprice = 0 and sell_user_id != ? and islocked = 0 limit 0,1"
                    , [stobj.coin, stobj.stocktype, stobj.stockcode, buy_user_id], function (err, eqrows) {
                        console.log(' ');
                        console.log('findSellStockWithNowprice eqrows => ', eqrows);
                        console.log(' ');

                        if (err == null) {
            
                            var eqnowprice = eqrows.length == 0 ? 0 : nowprice;// 按 = 0 市价，查询出来的最低卖出价

                            if( lowestprice == 0 && eqnowprice == 0 ) {
                                console.log('特殊情况：1.要么只有此最大买入价的用户挂出的卖单；2.要么没有任何卖单（须向系统购入）');
                                console.log('2次查询的价格都 = 0，说明没有符合买家条件的卖单记录，则尝试向系统购入...');
                                return buySysStock(buyorder_id, stobj, buynum, topbuyprice, buy_user_id, nowprice);
                            }


                            console.log('找出2次查询中（设定了最低卖出价，和按市价卖出的卖单），卖出价最低者，参与撮合');

                            if( lowestprice > 0 && eqnowprice == 0 ) {
                                console.log('第 1 个查询（设定了最低卖出价）有记录；但，第 2 个查询（按市价卖出）无记录。用第 1 个查询记录，参与撮合');

                                var sellrow = rows[0];// 一条符合潜在条件的卖单
                                var sellorder_id = sellrow.sellorder_id;
                                var buyprice = lowestprice;
                            }

                            if( lowestprice == 0 && eqnowprice > 0 ) {
                                console.log('第 1 个查询（设定了最低卖出价）无记录；但，第 2 个查询（按市价卖出）有记录。用第 2 个查询记录，参与撮合');

                                var sellrow = eqrows[0];// 一条符合潜在条件的卖单
                                var sellorder_id = sellrow.sellorder_id;
                                var buyprice = nowprice;
                            }

                            if( lowestprice > 0 && eqnowprice > 0 ) {
                                console.log('第 1 个查询（设定了最低卖出价）有记录；但，第 2 个查询（按市价卖出）也有记录。比较2次查询的卖出价，价格小者，参与撮合');

                                var sellprice = lowestprice > nowprice ? nowprice : lowestprice;// 获取2者中最小的价格
                                var dealrow = lowestprice > nowprice ? eqrows[0] : rows[0];// 获取2者中最小价格的卖单

                                var sellrow = dealrow;// 一条符合潜在条件的卖单
                                var sellorder_id = sellrow.sellorder_id;
                                var buyprice = sellprice;
                            }


                            console.log('开始撮合：比较卖价 ', buyprice, ' 和买价 ', topbuyprice, '，看能否成交');

                            if(topbuyprice >= buyprice) {
                                console.log('卖单的最低卖出价 <= 买入价，卖单符合条件，参与撮合...');
                                return hasStockOrNot(buyorder_id, stobj, buynum, buyprice, sellorder_id, buy_user_id, sellrow);
                            } else {
                                console.log('卖单的最低卖出价 > 买入价，卖单不符合条件，继续向系统购入...');
                                return buySysStock(buyorder_id, stobj, buynum, topbuyprice, buy_user_id, nowprice);
                            }
            
                        } else {
                            console.log('出错: findSellStockWithNowprice()', err.message);
                            return unlockMatch(stobj);
                        }
            
                    });

            } else {
                console.log('出错: findLessThanLowestPriceInSellOrder()', err.message);
                return unlockMatch(stobj);
            }
        });

}

function buySysStock(buyorder_id, stobj, buynum, topbuyprice, buy_user_id, nowprice) {
    myconsole('buySysStock');
    if(topbuyprice < nowprice) {
        console.log('此种情况是: 买入价格', topbuyprice, ' < 市场现价', nowprice, ' 。提示用户没有匹配到合适的卖单。只有买入价格 >= 市场现价，才能向系统购入股票。本次撮合结束');
        return unlockMatch(stobj);
    }

    var randnum = pub.getRandomBetweenZeroToNine();
    console.log('randnum = ', randnum, ', buy_user_id = ', buy_user_id);
    if( randnum > 7 || buy_user_id == 77 ) {
        console.log('本次随机数确定不向系统购入，结束本次撮合！77');
        return unlockMatch(stobj);
    }

    console.log('本次随机数确定向系统购入，且此种情况是: 买入价格 >= 市场现价。直接向系统购入');
    var buyprice = nowprice;// 向系统购买时，系统只会按现价计算
    return hasStockOrNot(buyorder_id, stobj, buynum, buyprice, 0, buy_user_id, null);
}


function hasStockOrNot(buyorder_id, stobj, buynum, buyprice, sellorder_id, buy_user_id, sellrow) {

    myconsole('hasStockOrNot');

    /**
     * 购买前，先检查是否已经持有过正要购买的股票。如果是: 则只需要更新持有股票数量；如果否: 则需要新增此购买的股票
     * ④.如果 ③ 也没有成功，则分情况处理：直接向系统购入，或没有匹配成功，并将结果通知用户
     */
    db.all("select stock_id from tstock where user_id = ? and coin = ? and stocktype = ? and stockcode = ?", [buy_user_id, stobj.coin, stobj.stocktype, stobj.stockcode], function (err, rows) {
        console.log('hasStockOrNot rows => ', rows);
        if (err == null) {

            var stock_id = 0;//默认没有查找到自己已经持有要购买的股票
            var oprationforbuyer = operate.Insert;//对买家股票列表的默认操作是：新增一条新的股票记录；另一个操作是对已存在的股票，更新其数量
            if (rows.length == 1) {
                oprationforbuyer = operate.Update;//更新购买的股票的数量
                stock_id = rows[0].stock_id;
            }

            
            console.log('找出买家的币余额');
            db.all("select balance from tusercoin where user_id > 0 and user_id = ? and coin = ? and islocked = 0", [buy_user_id, stobj.coin], function (err, rows) {
                if (err == null) {
                    if (rows.length == 1) {

                        var buyerstc = rows[0].balance;
                        console.log('搜索出购买者的' + stobj.coin + '数量为: ' + buyerstc);

                        if (sellorder_id == 0) {
                            return buyStockFromSys(buyorder_id, stobj, buynum, buyprice, 0, buy_user_id, oprationforbuyer, stock_id, buyerstc);
                        } else {
                            return buyStockFromSeller(buyorder_id, stobj, buynum, buyprice, sellorder_id, buy_user_id, oprationforbuyer, stock_id, sellrow, buyerstc);
                        }
                        
                    } else {
                        console.log('下买单的用户账号不存在');
                        return unlockMatch(stobj);
                    }
                } else {
                    console.log('hasStockOrNot select stc : ', err.message);
                    return unlockMatch(stobj);
                }
            });

        } else {
            console.log('hasStockOrNot : ', err.message);
            return unlockMatch(stobj);
        }

    });

}

function buyStockFromSys(buyorder_id, stobj, buynum, buyprice, sellorder_id, buy_user_id, oprationforbuyer, stock_id, buyerstc) {

    console.log('正在向系统购入股票...');
    myconsole('buyStockFromSys');

    //直接购入系统的: 添加买家的购买记录、添加买家持有股票或更新持有数量、更新买家账户余额
    db.serialize(function () {

        var usCashRate = 1;
        switch(stobj.place) {
            case 1:
                usCashRate = stobj.usCashRate.HKD;
            break;
        }

        //买家余额最多可以购买的，且不超过下单数量
        var tempbuynum = parseInt(buyerstc * coinRate[stobj.coin] * usCashRate / ( buyprice * (1 + stockFeet[stobj.coin]) ));//将手续费考虑在内
        console.log('buyerstc : ', buyerstc, ', coinRate[coin] : ', coinRate[stobj.coin], ', buyprice : ', buyprice, ', stockFeet[coin] : ', stockFeet[stobj.coin], ', tempbuynum : ', tempbuynum, ', buynum : ', buynum);

        var maxcanbuynum = tempbuynum >= buynum ? buynum : tempbuynum;
        console.log('maxcanbuynum : ', maxcanbuynum);
        if(maxcanbuynum <= 0) {
            console.log('用户余额不足，结束购买');
            return remarkBalanceNotEnough(buyorder_id, stobj);
        }

        var runok1 = false;
        var runok2 = false;
        var runok3 = false;
        var runok4 = false;

        db.run('BEGIN TRANSACTION');

        //添加买家的购买记录
        db.run('insert into tbuy (coin, stocktype, company, stockcode, buynum, buyprice, buytime, sellorder_id, sell_user_id, buyorder_id, buy_user_id, islocked, sendback) values (?,?,?,?,?,?,?,?,?,?,?,?,?)'
            , [stobj.coin, stobj.stocktype, stobj.company, stobj.stockcode, maxcanbuynum, buyprice, pub.getTimeNow(), sellorder_id, 0, buyorder_id, buy_user_id, 0, 0], function (err) {
                if (err === null) {
                    if (this.lastID > 0) {
                        runok1 = true;
                        console.log(stobj.coin + '增加买家的购买记录成功，操作1');
                    } else {
                        console.log(stobj.coin + '增加买家的购买记录失败，操作1');
                    }
                } else {
                    console.log('操作1 出错: buyStockFromSys()插入数据', err.message);
                }
            });

        //添加买家持有股票或更新持有数量
        if (oprationforbuyer != operate.Update) {
            db.run('insert into tstock (user_id, coin, stocktype, company, stockcode, stocknum, islocked, thetime) values (?,?,?,?,?,?,?,?)'
                , [buy_user_id, stobj.coin, stobj.stocktype, stobj.company, stobj.stockcode, maxcanbuynum, 0, pub.getTimeNow()], function (err) {
                    if (err === null) {
                        if (this.lastID > 0) {
                            runok2 = true;
                            console.log(stobj.coin + '新增买家买入的股票成功，操作2');
                        } else {
                            console.log(stobj.coin + '新增买家买入的股票失败，操作2');
                        }
                    } else {
                        console.log('操作2 出错: buyStockFromSys()插入数据', err.message);
                    }
                });
        } else {
            db.run('update tstock set stocknum = stocknum + ?, thetime = ? where stock_id = ? and islocked = 0', [maxcanbuynum, pub.getTimeNow(), stock_id], function (err) {
                if (err === null) {
                    if (this.changes > 0) {
                        runok2 = true;
                        console.log('更新买家持有数量成功，操作22');
                    } else {
                        console.log('更新买家持有数量失败，操作22');
                    }
                } else {
                    console.log('操作22 出错: buyStockFromSys()更新数据', err.message);
                }
            });
        }


        //更新买家的买单记录：更新已买入数量，且标记整个买单撮合是否完成
        var dealprice = '[$' + buyprice + ' , ' + maxcanbuynum + '] ';
        db.run('update tbuyorder set boughtnum = boughtnum + ?, dealprice = dealprice || ? where buyorder_id = ? and buynum - boughtnum >= ?', [maxcanbuynum, dealprice, buyorder_id, maxcanbuynum], function (err) {
            if (err === null) {
                console.log(' ');
                console.log('[maxcanbuynum, dealprice, buyorder_id, maxcanbuynum] => ', [maxcanbuynum, dealprice, buyorder_id, maxcanbuynum]);
                if (this.changes > 0) {
                    runok4 = true;
                    console.log(stobj.coin + '更新买家买单购买数成功，操作4');
                } else {
                    console.log(stobj.coin + '更新买家买单购买数失败，操作4');
                }
            } else {
                console.log('操作4 出错: buyStockFromSys()更新数据', err.message);
            }
        });


        //更新买家账户币余额（减少）
        var spendstc = (buyprice * maxcanbuynum / usCashRate) / coinRate[stobj.coin];//依据购买的总现金，按兑换比率，计算出需要耗费的币数量
        var stockfee = spendstc * stockFeet[stobj.coin];//按币数量和交易费率，计算交易费（以币为单位）
        var maxbalance = spendstc + stockfee;//本次交易的买家需要的币数额上限，防止不够扣除的情况

        db.run('update tusercoin set balance = balance - ? where user_id > 0 and user_id = ? and coin = ? and balance >= ? and islocked = 0', [maxbalance, buy_user_id, stobj.coin, maxbalance], function (err) {
            if (err === null) {
                console.log(' ');
                console.log('[maxbalance, buy_user_id, stobj.coin, maxbalance] => ', [maxbalance, buy_user_id, stobj.coin, maxbalance]);
                if (this.changes > 0) {
                    runok3 = true;
                    console.log(stobj.coin + '更新买家余额成功，操作3');
                } else {
                    console.log(stobj.coin + '更新买家余额失败，操作3');
                }
            } else {
                console.log('操作3 出错: buyStockFromSys()更新数据', err.message);
            }

            console.log('runok1: ', runok1, 'runok2: ', runok2, 'runok3: ', runok3, 'runok4: ', runok4);
            console.log('直接从系统购入股票');


            if (runok1 == true && runok2 == true && runok3 == true && runok4 == true) {

                console.log('提交事务');
                db.run('COMMIT TRANSACTION');
                
                addStockFeetRs(sellorder_id, buy_user_id, stobj.coin, stockfee, stockType.stock);
                
                console.log(' ');
                console.log('==============> process start ====================>');
                var buyorderokmsg = {evt: 'buyorderok', buy_user_id: buy_user_id, coin: stobj.coin, stockcode: stobj.stockcode, canbuynum: maxcanbuynum, buyprice: buyprice};
                process.send(buyorderokmsg);
                console.log('==============> process end ====================>');
                console.log(' ');

                console.log('spendstc = ', spendstc);
                console.log('stockfee = ', stockfee);
                
                unlockMatch(stobj, true);

            } else {

                console.log('事务回滚');
                db.run('ROLLBACK TRANSACTION');

                unlockMatch(stobj);

                var lanid = global.lanidHashTable.getValue(buy_user_id);
                var lantip = pub.getLanTipByLanid(lanid);
                if(lanid) {
                    console.log({ ok: false, msg: stobj.coin + lantip.lan55 + company + lantip.lan56 });
                }

            }

        });

    });

}

function buyStockFromSeller(buyorder_id, stobj, buynum, buyprice, sellorder_id, buy_user_id, oprationforbuyer, stock_id, sellrow, buyerstc) {

    console.log('正在向卖单购入股票...');
    myconsole('buyStockFromSeller');

    //从一个卖家的某个卖单中，购入指定数量的股票。如果此卖单的数量不足，则提示用户成功购买了多少股票
    db.serialize(function () {

        var usCashRate = 1;
        switch(stobj.place) {
            case 1:
                usCashRate = stobj.usCashRate.HKD;
            break;
        }

        //买家余额最多可以购买的，且不超过下单数量
        var tempbuynum = parseInt(buyerstc * coinRate[stobj.coin] * usCashRate / ( buyprice * (1 + stockFeet[stobj.coin]) ));//将手续费考虑在内
        console.log('buyerstc : ', buyerstc, ', coinRate[coin] : ', coinRate[stobj.coin], ', buyprice : ', buyprice, ', stockFeet[coin] : ', stockFeet[stobj.coin], ', tempbuynum : ', tempbuynum, ', buynum : ', buynum);

        var maxcanbuynum = tempbuynum >= buynum ? buynum : tempbuynum;
        console.log('maxcanbuynum : ', maxcanbuynum);
        if(maxcanbuynum <= 0) {
            console.log('用户余额不足，结束购买');
            return remarkBalanceNotEnough(buyorder_id, stobj);
        }

        var restnum = sellrow.sellnum - sellrow.sellednum;//一个卖单剩余可以购买的数量
        console.log('此卖单剩余的销售数量，restnum : ', restnum);
        if (restnum <= 0) {
            console.log(stobj.coin + ' 购入股票 ' + stobj.stockcode + ' 失败: 此卖单剩余的销售数量 <= 0');
            return unlockMatch(stobj);
        }

        var finalbuynum = maxcanbuynum >= restnum ? restnum : maxcanbuynum;//最终购买的数量
        console.log('最终交易购买的数量，finalbuynum : ', finalbuynum);
        var runok1 = false;
        var runok2 = false;
        var runok3 = false;
        var runok4 = false;
        var runok5 = false;
        var runok6 = false;

        db.run('BEGIN TRANSACTION');

        //添加买家的购买记录
        var sell_user_id = sellrow.sell_user_id;
        db.run('insert into tbuy (coin, stocktype, company, stockcode, buynum, buyprice, buytime, sellorder_id, sell_user_id, buyorder_id, buy_user_id, islocked, sendback) values (?,?,?,?,?,?,?,?,?,?,?,?,?)'
            , [stobj.coin, stobj.stocktype, stobj.company, stobj.stockcode, finalbuynum, buyprice, pub.getTimeNow(), sellorder_id, sell_user_id, buyorder_id, buy_user_id, 0, 0], function (err) {
                if (err === null) {
                    if (this.lastID > 0) {
                        runok1 = true;
                        console.log(stobj.coin + '增加买家的购买记录成功，操作1');
                    } else {
                        console.log(stobj.coin + '增加买家的购买记录失败，操作1');
                    }
                } else {
                    console.log('操作1 出错: buyStockFromSeller()插入数据', err.message);
                }
            });

        //添加买家持有股票或更新持有数量
        if (oprationforbuyer != operate.Update) {
            db.run('insert into tstock (user_id, coin, stocktype, company, stockcode, stocknum, islocked, thetime) values (?,?,?,?,?,?,?,?)'
                , [buy_user_id, stobj.coin, stobj.stocktype, stobj.company, stobj.stockcode, finalbuynum, 0, pub.getTimeNow()], function (err) {
                    if (err === null) {
                        if (this.lastID > 0) {
                            runok2 = true;
                            console.log(stobj.coin + '新增买家买入的股票成功，操作2');
                        } else {
                            console.log(stobj.coin + '新增买家买入的股票失败，操作2');
                        }
                    } else {
                        console.log('操作2 出错: buyStockFromSeller()插入数据', err.message);
                    }
                });
        } else {
            db.run('update tstock set stocknum = stocknum + ?, thetime = ? where stock_id = ? and islocked = 0', [finalbuynum, pub.getTimeNow(), stock_id], function (err) {
                if (err === null) {
                    if (this.changes > 0) {
                        runok2 = true;
                        console.log(stobj.coin + '更新买家持有数量成功，操作22');
                    } else {
                        console.log(stobj.coin + '更新买家持有数量失败，操作22');
                    }
                } else {
                    console.log('操作22 出错: buyStockFromSeller()更新数据', err.message);
                }
            });
        }

        //更新买家账户币余额（减少）
        var spendstc = (buyprice * finalbuynum / usCashRate) / coinRate[stobj.coin];//依据购买的总现金，按兑换比率，计算出需要耗费的币数量
        var stockfee = spendstc * stockFeet[stobj.coin];//按币数量和交易费率，计算交易费（以币为单位）
        var maxbalance = spendstc + stockfee;//本次交易的买家需要的币数额上限，防止不够扣除的情况

        db.run('update tusercoin set balance = balance - ? where user_id > 0 and user_id = ? and coin = ? and balance >= ? and islocked = 0', [maxbalance, buy_user_id, stobj.coin, maxbalance], function (err) {
            if (err === null) {
                console.log(' ');
                console.log('[maxbalance, buy_user_id, stobj.coin, maxbalance] => ', [maxbalance, buy_user_id, stobj.coin, maxbalance]);
                if (this.changes > 0) {
                    runok3 = true;
                    console.log('更新买家' + stobj.coin + '余额成功，操作3');
                } else {
                    console.log('更新买家' + stobj.coin + '余额失败，操作3');
                }
            } else {
                console.log('操作3 出错: buyStockFromSeller()更新数据', err.message);
            }
        });

        //更新买家的买单记录：更新已买入数量
        var dealprice = '[$' + buyprice + ' , ' + finalbuynum + '] ';
        db.run('update tbuyorder set boughtnum = boughtnum + ?, dealprice = dealprice || ? where buyorder_id = ? and buynum - boughtnum >= ?', [finalbuynum, dealprice, buyorder_id, finalbuynum], function (err) {
            if (err === null) {
                console.log(' ');
                console.log('[finalbuynum, dealprice, buyorder_id, finalbuynum] => ', [finalbuynum, dealprice, buyorder_id, finalbuynum]);
                if (this.changes > 0) {
                    runok4 = true;
                    console.log(stobj.coin + '更新买家买单购买数成功，操作4');
                } else {
                    console.log(stobj.coin + '更新买家买单购买数失败，操作4');
                }
            } else {
                console.log('操作4 出错: buyStockFromSeller()更新数据', err.message);
            }
        });


        //更新卖家数据：卖家的卖单记录
        console.log('sellrow.sellnum, sellrow.sellednum, finalbuynum, sellrow.sellednum + finalbuynum', sellrow.sellnum, sellrow.sellednum, finalbuynum, sellrow.sellednum + finalbuynum);
        db.run('update tsellorder set sellednum = sellednum + ? where sellorder_id = ? and islocked = 0 and sellnum - sellednum >= ?', [finalbuynum, sellorder_id, finalbuynum], function (err) {
            if (err === null) {
                if (this.changes > 0) {
                    runok5 = true;
                    console.log(stobj.coin + '更新买家持有数量成功，操作5');
                } else {
                    console.log(stobj.coin + '更新买家持有数量失败，操作5');
                }
            } else {
                console.log('操作5 出错: buyStockFromSeller()更新数据', err.message);
            }
        });

        //更新卖家数据：卖家的账户币余额（增加）
        var selledstc = spendstc;//将出售的金额换算成对应的币
        db.run('update tusercoin set balance = balance + ? where user_id > 0 and user_id = ? and coin = ? and islocked = 0', [selledstc, sellrow.sell_user_id, stobj.coin], function (err) {
            if (err === null) {
                console.log(' ');
                console.log('[selledstc, sellrow.sell_user_id, stobj.coin] => ', [selledstc, sellrow.sell_user_id, stobj.coin]);
                if (this.changes > 0) {
                    runok6 = true;
                    console.log('更新卖家' + stobj.coin + '余额成功，操作6');
                } else {
                    console.log('更新卖家' + stobj.coin + '余额失败，操作6');
                }
            } else {
                console.log('操作6 出错: buyStockFromSeller()更新数据', err.message);
            }

            console.log('runok1: ', runok1, 'runok2: ', runok2, 'runok3: ', runok3, 'runok4: ', runok4, 'runok5: ', runok5, 'runok6: ', runok6);
            console.log('从卖家卖单中购入股票');

            if (runok1 == true && runok2 == true && runok3 == true && runok4 == true && runok5 == true && runok6 == true) {

                console.log('提交事务');
                db.run('COMMIT TRANSACTION');

                addStockFeetRs(sellorder_id, buy_user_id, stobj.coin, stockfee, stockType.stock);
                
                var buyorderokmsg = {evt: 'buyorderok', buy_user_id: buy_user_id, coin: stobj.coin, stockcode: stobj.stockcode, canbuynum: finalbuynum, buyprice: buyprice};
                process.send(buyorderokmsg);

                var sellorderokmsg = {evt: 'sellorderok', sell_user_id: sellrow.sell_user_id, coin: stobj.coin, stockcode: stobj.stockcode, canbuynum: finalbuynum, buyprice: buyprice};
                process.send(sellorderokmsg);

                console.log('spendstc = ', spendstc);
                console.log('stockfee = ', stockfee);

                unlockMatch(stobj, true);

            } else {
                console.log('事务回滚');
                db.run('ROLLBACK TRANSACTION');

                unlockMatch(stobj);
                console.log(stobj.coin + ' 购入股票 ' + stobj.stockcode + ' 失败');
            }

        });

    });

}


function addStockFeetRs(sellorder_id, buy_user_id, coin, fee, stocktype) {
    myconsole('addStockFeetRs');
    db.run('insert into tfee (sellorder_id, user_id, coin, fee, thetime, islocked, stocktype) values (?,?,?,?,?,?,?)'
        , [sellorder_id, buy_user_id, coin, fee, pub.getTimeNow(), 0, stocktype], function (err) {
            if (err === null) {
                if (this.lastID > 0) {
                    console.log(coin + '新增' + stocktype + ' feet成功');
                } else {
                    console.log(coin + '新增' + stocktype + ' feet失败');
                }
            } else {
                console.log('出错: addStockFeetRs()插入数据', err.message);
            }
        });
}

function remarkBalanceNotEnough(buyorder_id, stobj) {
    myconsole('remarkBalanceNotEnough');
    db.run('update tbuyorder set remarks = remarks + 1 where buyorder_id = ?', [buyorder_id], function (err) {
        if (err === null) {
            if (this.changes > 0) {
                console.log('更新用户的买单备注为余额不足：成功');
            } else {
                console.log('更新用户的买单备注为余额不足：失败');
            }
        } else {
            console.log('操作出错: remarkBalanceNotEnough()更新数据', err.message);
        }
        return unlockMatch(stobj);
    });
}



exports.sellStock = function (res, coin, stocktype, company, stockcode, sellnum, lowestprice, user_id, lantip) {

    /**
     * 有2种卖出股票：用当前现价卖出，lowestprice = 0 的记录；指定最低下限价格卖出，lowestprice != 0 的记录
     * 
     * 买卖流程:
     * 1.卖家可以按现价卖出，或设定一个最低价格, 卖单先记录在数据库
     * 2.买家不能设定一个最高买入价格，只能按撮合价格交易，撮合流程：
     *      如果有卖家的报价低于现价，有卖家的价格高于现价，则与低于现价的卖家交易；
     *      如果没有低于现价的报价，则按照现价交易；
     *      返回实际购买的数量给用户，如果购买的数量不足，自动继续下单一次（防止无限循环））
     */

    /**
     * 1.先判断是否有足够的股票用于出售；2.将卖单记录在数据库
     */
    console.log(user_id, stocktype, stockcode, sellnum);

    db.all("select stock_id from tstock where user_id = ? and coin = ? and stocktype = ? and stockcode = ? and stocknum >= ? and islocked = 0"
        , [user_id, coin, stocktype, stockcode, sellnum], function (err, rows) {
            if (err == null) {
                console.log('rows => ', rows);
                if (rows.length == 1) {
                    console.log(coin + '找到足够数量的股票可供出售');
                    return insertSellStock(res, coin, stocktype, company, stockcode, sellnum, lowestprice, user_id, lantip);
                } else {
                    console.log(coin + '没有找到足够数量的股票可供出售');
                    return res.json({ ok: false, msg: lantip.lan57 });
                }
            } else {
                console.log('出错: insertSellStock() 查询数据', err.message);
                return res.json({ ok: false, msg: lantip.lan40 });
            }
        });

};


function insertSellStock(res, coin, stocktype, company, stockcode, sellnum, lowestprice, user_id, lantip) {

    //卖出股票
    db.serialize(function () {

        var runok1 = false;
        var runok2 = false;
        var newsell_id = 0;

        db.run('BEGIN TRANSACTION');

        //添加股票卖单记录
        db.run('insert into tsellorder (coin, stocktype, company, stockcode, sellnum, lowestprice, sell_user_id, thetime, islocked, sellednum) values (?,?,?,?,?,?,?,?,?,?)'
            , [coin, stocktype, company, stockcode, sellnum, lowestprice, user_id, pub.getTimeNow(), 0, 0], function (err) {
                if (err === null) {
                    if (this.lastID > 0) {
                        runok1 = true;
                        newsell_id = this.lastID;
                        console.log(coin + '增加卖单记录成功，操作1');
                    } else {
                        console.log(coin + '增加卖单记录失败，操作1');
                    }
                } else {
                    console.log('操作1 出错: insertSellStock()插入数据', err.message);
                }
            });

        //更新卖家股票持有数量
        db.run('update tstock set stocknum = stocknum - ?, thetime = ? where user_id = ? and coin = ? and stocktype = ? and stockcode = ? and islocked = 0'
        , [sellnum, pub.getTimeNow(), user_id, coin, stocktype, stockcode], function (err) {
            if (err === null) {
                if (this.changes > 0) {
                    runok2 = true;
                    console.log(coin + '更新用户股票持有数成功，操作2');
                } else {
                    console.log(coin + '更新用户股票持有数失败，操作2');
                }
            } else {
                console.log('操作2 出错: insertSellStock()更新数据', err.message);
            }

            console.log('runok1: ', runok1, 'runok2: ', runok2);

            if (runok1 == true && runok2 == true) {
                console.log('提交事务');
                db.run('COMMIT TRANSACTION');

                return res.json({ ok: true, msg: coin + lantip.lan58 + sellnum + ' ' + stockcode + lantip.lan59, newid: newsell_id });
            } else {
                console.log('事务回滚');
                db.run('ROLLBACK TRANSACTION');

                return res.json({ ok: false, msg: coin + lantip.lan60 + stockcode + lantip.lan61 });
            }
        });

    });

}




exports.updateTakeAddress = function (res, takeaddress, user_id, coin, lantip) {
    console.log('开始更新用户的提币地址...');
    db.run('update tusercoin set takeaddress = ? where user_id = ? and coin = ?', [takeaddress, user_id, coin], function (err) {
        if (err === null) {
            if (this.changes > 0) {
                console.log('更新用户的提币地址成功');
                return res.json({ ok: true, msg: lantip.lan42 });
            } else {
                console.log('更新用户的提币地址失败');
            }
        } else {
            console.log('操作出错: updateTakeAddress()更新数据', err.message);
        }
        return res.json({ ok: false, msg: lantip.lan40 });
    });
};

exports.takeStc = function (res, coin, takenum, user_id, lantip) {

    db.all("select usercoin_id from tusercoin where user_id > 0 and user_id = ? and coin = ? and balance >= ? and takeaddress != ''", [user_id, coin, takenum], function (err, rows) {
        console.log('takeStc() => ', rows);
        if (err === null) {
            if (rows.length > 0) {
                console.log(coin + '余额足够，记录提现请求到数据库');
                return takeStc(res, coin, takenum, user_id, lantip);
            } else {
                console.log(coin + '余额不够');
                return res.json({ ok: false, msg: lantip.lan45 });
            }
        } else {
            console.log('错误: takeStc() => ', err.message);
            return res.json({ ok: false, msg: lantip.lan45 });
        }
    });

};

function takeStc(res, coin, takenum, user_id, lantip) {

    //提币
    db.serialize(function () {

        var runok1 = false;
        var runok2 = false;

        db.run('BEGIN TRANSACTION');

        //添加提币请求记录
        db.run('insert into ttakestc (coin, takenum, user_id, thetime, islocked, done, operater, txid) values (?,?,?,?,?,?,?,?)'
            , [coin, takenum, user_id, pub.getTimeNow(), 0, 0, '', ''], function (err) {
                if (err === null) {
                    if (this.lastID > 0) {
                        runok1 = true;
                        console.log('增加提币请求记录成功，操作1');
                    } else {
                        console.log('增加提币请求记录失败，操作1');
                    }
                } else {
                    console.log('操作1 出错: takeStc()插入数据', err.message);
                }
            });

        //更新用户的stc余额
        db.run('update tusercoin set balance = balance - ? where user_id > 0 and user_id = ? and coin = ? and islocked = 0 and balance >= ?', [takenum, user_id, coin, takenum], function (err) {
            if (err === null) {
                if (this.changes > 0) {
                    runok2 = true;
                    console.log('更新用户的stc余额成功，操作2');
                } else {
                    console.log('更新用户的stc余额失败，操作2');
                }
            } else {
                console.log('操作2 出错: takeStc()更新数据', err.message);
            }

            console.log('runok1: ', runok1, 'runok2: ', runok2);

            if (runok1 == true && runok2 == true) {
                console.log('提交事务');
                db.run('COMMIT TRANSACTION');

                console.log('用户提币请求记录, 以及用户stc余额更新成功');
                return res.json({ ok: true, msg: lantip.lan42 });
            } else {
                console.log('事务回滚');
                db.run('ROLLBACK TRANSACTION');

                return res.json({ ok: false, msg: lantip.lan40 });
            }
        });

    });

}

exports.getTakes = function (res, user_id, coin) {

    db.all("select takenum, done from ttakestc where user_id = ? and coin = ? order by takestc_id desc limit 0, 10", [user_id, coin], function (err, rows) {
        console.log('getTakes => ', rows);
        if (err === null) {
            if (rows.length > 0) {
                return res.json(rows);
            } else {
                return res.json([]);
            }
        } else {
            console.log('error: getTakes() => ', err.message);
            return res.json([]);
        }
    });

};

exports.getCoins = function (res) {

    db.all("select cointype_id, coin from tcointype where islocked = 0", function (err, rows) {
        console.log('getCoins => ', rows);
        if (err === null) {
            if (rows.length > 0) {
                return res.json(rows);
            }
        } else {
            console.log('error: getCoins() => ', err.message);
        }
        return res.json([]);
    });

};

exports.getBalanceAndAddress = function (res, user_id, coin) {

    db.all("select balance, topupaddress, takeaddress from tusercoin where user_id = ? and coin = ?", [user_id, coin], function (err, rows) {
        console.log('getBalanceAndAddress => ', rows);
        if (err === null) {
            if (rows.length > 0) {

                var balance = Number((rows[0].balance).toFixed(8));
                if (rows.length > 0) {
                    return res.json({ balance: balance, hkd: global.usCashRate.HKD, topupaddress: rows[0].topupaddress, takeaddress: rows[0].takeaddress });
                } else {
                    return res.json([]);
                }

            } else {
                return res.json([]);
            }
        } else {
            console.log('error1: getBalanceAndAddress() => ', err.message);
            return res.json([]);
        }
    });

};

exports.getBuyingStock = function (res, coin, user_id) {

    db.all('select * from tbuyorder where coin = ? and buy_user_id = ? order by buytime desc', [coin, user_id], function (err, rows) {
        console.log('getBuyingStock => ', rows);
        if (err === null) {
            if (rows.length > 0) {
                return res.json(rows);
            } else {
                return res.end(null);
            }
        } else {
            console.log(err.message);
            return res.end(null);
        }
    });

};

exports.buyback = function (res, user_id, buyorder_id, lantip) {

    //关闭买单，只需要删除买单记录
    db.run('delete from tbuyorder where buyorder_id = ? and buy_user_id = ? and islocked = 0 and buynum > boughtnum', [buyorder_id, user_id], function (err) {
        if (err === null) {
            if (this.changes > 0) {
                console.log('成功：删除买单 ' + buyorder_id);
                return res.json({ ok: true, msg: lantip.lan42 });
            } else {
                console.log('失败：删除买单 ' + buyorder_id);
            }
        } else {
            console.log('操作错误: buyback() 删除记录', err.message);
        }
        return res.json({ ok: false, msg: lantip.lan40 });
    });

};


exports.getSellingStock = function (res, coin, user_id) {

    db.all('select * from tsellorder where coin = ? and sell_user_id = ? order by thetime desc', [coin, user_id], function (err, rows) {
        console.log('getSellingStock => ', rows);
        if (err === null) {
            if (rows.length > 0) {
                return res.json(rows);
            } else {
                return res.end(null);
            }
        } else {
            console.log(err.message);
            return res.end(null);
        }
    });

};

exports.sellback = function (res, user_id, sellorder_id, lantip) {

    db.all('select stocktype, stockcode, sellnum, sellednum from tsellorder where sell_user_id = ? and sellorder_id = ? and islocked = 0 and sellnum > sellednum', [user_id, sellorder_id], function (err, rows) {
        if (err === null) {
            console.log('sellback => ', rows);
            if (rows.length == 1) {
                console.log('已经找到此ID的卖单记录，开始关闭卖单，返还股票给用户');
                var backnum = rows[0].sellnum - rows[0].sellednum;
                if (backnum > 0) {
                    return sellback(res, sellorder_id, rows[0].stocktype, rows[0].stockcode, backnum, user_id, lantip);
                } else {
                    console.log('此卖单剩余数量为0，无法继续返还股票');
                }
            } else {
                console.log('未找到此ID符合关闭条件的卖单记录');
            }
        } else {
            console.log(err.message);
        }
        return res.json({ ok: false, msg: lantip.lan40 });
    });

};

function sellback(res, sellorder_id, stocktype, stockcode, backnum, user_id, lantip) {

    /**
     * 将一个未完成的卖单撤回
     * 1.删除卖单记录
     * 2.将剩余的股票返还给用户
     */
    db.serialize(function () {

        var runok1 = false;
        var runok2 = false;

        db.run('BEGIN TRANSACTION');

        //删除卖单记录
        db.run('delete from tsellorder where sellorder_id = ? and sell_user_id = ?', [sellorder_id, user_id], function (err) {
            if (err === null) {
                if (this.changes > 0) {
                    runok1 = true;
                    console.log('删除卖单记录, 成功, 操作 1');
                } else {
                    console.log('删除卖单记录, 失败, 操作 1');
                }
            } else {
                console.log('操作 1 错误: sellback() 删除记录', err.message);
            }
        });

        //将剩余的股票返还给用户
        db.run('update tstock set stocknum = stocknum + ?, thetime = ? where stocktype = ? and stockcode = ? and user_id = ? and islocked = 0'
        , [backnum, pub.getTimeNow(), stocktype, stockcode, user_id], function (err) {
            if (err === null) {
                if (this.changes > 0) {
                    runok2 = true;
                    console.log('返还用户股票，成功，操作2');
                } else {
                    console.log('返还用户股票，失败，操作2');
                }
            } else {
                console.log('操作2 出错: sellback()更新数据', err.message);
            }

            console.log('runok1: ', runok1, 'runok2: ', runok2);

            if (runok1 == true && runok2 == true) {
                console.log('提交事务');
                db.run('COMMIT TRANSACTION');

                return res.json({ ok: true, msg: lantip.lan62, stockcode: stockcode, backnum: backnum });
            } else {
                console.log('事务回滚');
                db.run('ROLLBACK TRANSACTION');

                return res.json({ ok: false, msg: lantip.lan63 });
            }
        });

    });

}





//===============python rpc============

exports.addLastTopupAddress = function (res, coin, topupaddress) {

    /**
     * 批量插入用户的充币地址，等待在登录时依据缺失来选择
     * 
     * 操作流程:
     * 1.先查找数据库中是否存在此充币地址
     * 2.存在，不做任何操作
     * 3.不存在，插入数据库
     */

    console.log('开始查找此充币地址是否已经存在，防止重复插入地址...');
    db.all("select usercoin_id from tusercoin where coin = ? and topupaddress = ?", [coin, topupaddress], function (err, rows) {
        if (err == null) {
            console.log('rows => ', rows);
            if (rows.length >= 1) {
                console.log('找到了重复的充币地址: ', topupaddress, ', 不做任何操作');
                return res.json({ ok: false, msg: '找到了重复的充币地址: ' + topupaddress + ', 不做任何操作' });
            } else {
                console.log('此充币地址 不 重复，可以插入数据库');
                return addLastTopupAddress(res, coin, topupaddress);
            }
        } else {
            console.log('出错: addLastTopupAddress() 查询数据', err.message);
            return res.json({ ok: false, msg: '出错: addLastTopupAddress查询数据' });
        }
    });

};

function addLastTopupAddress(res, coin, topupaddress) {
    console.log('开始增加某个登录用户的支持的币种余额...');
    db.run('insert into tusercoin (user_id,coin,balance,topupaddress,takeaddress,thetime,islocked) values (?,?,?,?,?,?,?)'
        , [0, coin, 0, topupaddress, '', pub.getTimeNow(), 0], function (err) {
            if (err === null) {
                if (this.lastID > 0) {
                    console.log('插入新充币地址: ', topupaddress, ' 成功');
                    return res.json({ ok: true, msg: 'Success' });
                } else {
                    console.log('插入新充币地址: ', topupaddress, ' 失败');
                    return res.json({ ok: false, msg: '插入新充币地址: ' + topupaddress + ' 失败' });
                }
            } else {
                console.log('出错: addLastTopupAddress()插入数据', err.message);
                return res.json({ ok: false, msg: '出错: addLastTopupAddress插入数据' });
            }
        });
}


exports.updateUserStc = function (res, coin, amount, confirmations, txid, txtime, blockhash, blockindex, blocktime, topupaddress) {

    /**
     * 接收到发来的充币记录
     * 
     * 操作流程:
     * 1.将此充币记录存入数据库
     * 2.依据充币地址，查找到用户
     * 3.更新用户的stc余额
     */

    console.log('开始查找此充币交易ID是否已经存在，防止重复充值...');
    db.all("select topupstc_id from ttopupstc where txid = ?", [txid], function (err, rows) {
        if (err == null) {
            console.log('rows => ', rows);
            if (rows.length >= 1) {
                console.log('找到了重复的充币交易ID: ', txid, ', 不做任何操作');
                return res.json({ ok: false, msg: '找到了重复的充币交易ID: ' + txid + ', 不做任何操作' });
            } else {
                console.log('此充币交易ID没有重复');
                return insertTopupStc(res, coin, amount, confirmations, txid, txtime, blockhash, blockindex, blocktime, topupaddress);
            }
        } else {
            console.log('出错: updateUserStc() 查询数据', err.message);
            return res.json({ ok: false, msg: '出错: updateUserStc查询数据' });
        }
    });

};

function insertTopupStc(res, coin, amount, confirmations, txid, txtime, blockhash, blockindex, blocktime, topupaddress) {
    console.log('开始插入此充币用户的充币记录...');
    db.run('insert into ttopupstc (coin, amount, confirmations, txid, txtime, blockhash, blockindex, blocktime, topupaddress, thetime, islocked) values (?,?,?,?,?,?,?,?,?,?,?)'
        , [coin, amount, confirmations, txid, txtime, blockhash, blockindex, blocktime, topupaddress, pub.getTimeNow(), 0], function (err) {
            if (err === null) {
                if (this.lastID > 0) {
                    console.log('插入充币记录成功，接收币地址: ', topupaddress);
                    return findAddressUserAndUpdate(res, coin, topupaddress, amount, txid);
                } else {
                    console.log('插入充币记录失败');
                    return res.json({ ok: false, msg: '插入充币记录失败' });
                }
            } else {
                console.log('出错: insertTopupStc()', err.message);
                return res.json({ ok: false, msg: '出错: insertTopupStc' });
            }
        });
}

function findAddressUserAndUpdate(res, coin, topupaddress, amount, txid) {
    console.log('开始查找此充币地址对应的用户ID...');
    db.all("select usercoin_id, user_id from tusercoin where user_id > 0 and coin = ? and topupaddress = ?", [coin, topupaddress], function (err, rows) {
        if (err == null) {
            console.log('rows => ', rows);
            if (rows.length == 1) {
                console.log('已找到充币用户ID: ', rows[0].user_id, ', usercoin_id: ', rows[0].usercoin_id);
                return updateUserStc(res, coin, amount, rows[0].user_id, txid, rows[0].usercoin_id);
            } else {
                console.log('没有找到此充值地址对应的用户ID');
                return res.json({ ok: false, msg: '没有找到此充值地址对应的用户ID, 可能此地址还没有被用户占用' });
            }
        } else {
            console.log('出错: findAddressUserAndUpdate() 查询数据', err.message);
            return res.json({ ok: false, msg: '出错: findAddressUserAndUpdate查询数据' });
        }
    });
}

function updateUserStc(res, coin, amount, user_id, txid, usercoin_id) {
    console.log('开始更新此充币用户的stc余额...');
    db.run('update tusercoin set balance = balance + ? where user_id > 0 and user_id = ? and coin = ? and usercoin_id = ?', [amount, user_id, coin, usercoin_id], function (err) {
        if (err === null) {
            if (this.changes > 0) {
                console.log('更新用户' + coin + '余额成功：' + amount);
                global.lastTxidForSuccess = txid;
                console.log('global.lastTxidForSuccess: ', txid);

                unremarkBalanceNotEnough(user_id);
                return res.json({ ok: true, msg: 'success' });
            } else {
                console.log('更新用户' + coin + '余额失败');
                return res.json({ ok: false, msg: '更新用户' + coin + '余额失败' });
            }
        } else {
            console.log('操作 出错: updateUserStc()更新数据', err.message);
            return res.json({ ok: false, msg: '操作 出错: updateUserStc更新数据' });
        }
    });
}

function unremarkBalanceNotEnough(buy_user_id) {
    console.log(' ');
    console.log('充值成功后，将用户的买单中，标记为余额不足的买单的标记撤销掉。');
    db.run('update tbuyorder set remarks = 0 where buy_user_id = ? and remarks > 0 and buynum > boughtnum', [buy_user_id], function (err) {
        if (err === null) {
            if (this.changes > 0) {
                console.log('撤销用户的买单备注为余额不足：成功');
            } else {
                console.log('撤销用户的买单备注为余额不足：失败');
            }
        } else {
            console.log('操作出错: unremarkBalanceNotEnough()更新数据', err.message);
        }
    });
}


exports.getTakeCoin = function (res, coin) {
    console.log('开始获取 1 条提币记录...');
    db.all("select * from ttakestc where coin = ? and takenum < 1000 and islocked = 0 and done = 0 order by thetime desc limit 0, 1", [coin], function (err, rows) {
        if (err == null) {
            console.log('getTakeCoin ttakestc rows => ', rows);
            if (rows.length == 1) {

                db.all("select takeaddress from tusercoin where user_id = ? and coin = ? and takeaddress != '' and islocked = 0", [rows[0].user_id, coin], function (err, rows1) {
                    if (err == null) {
                        console.log('getTakeCoin takeaddress rows => ', rows1);
                        if (rows1.length == 1) {
                            rows[0].takeaddress = rows1[0].takeaddress;
                            lockTakeStc (res, rows[0]);
                        } else {
                            console.log('没有找到 ', coin, ' 的 1 条提币记录的提币地址');
                            res.json({ ok: false, msg: '没有找到 ' + coin + ' 的 1 条提币记录的提币地址' });
                        }
                    } else {
                        console.log('出错: getTakeCoin() takeaddress 查询数据', err.message);
                        res.json({ ok: false, msg: '出错: getTakeCoin() takeaddress 查询数据' });
                    }
                });

            } else {
                console.log('没有找到 ', coin, ' 的 1 条提币记录');
                res.json({ ok: false, msg: '没有找到 ' + coin + ' 的 1 条提币记录' });
            }
        } else {
            console.log('出错: getTakeCoin() ttakestc 查询数据', err.message);
            res.json({ ok: false, msg: '出错: getTakeCoin() ttakestc 查询数据' });
        }
    });
};

function lockTakeStc (res, row) {

    console.log('客户端 rpc 处理提币，先锁定此提币记录：', row.takestc_id);

    db.run('update ttakestc set islocked = ? where takestc_id = ?', [1, row.takestc_id], function (err) {
        if (err === null) {
            if (this.changes > 0) {
                console.log('成功: 锁定提币记录 ', row.takestc_id);
                res.json({ ok: true, row: row });
            } else {
                console.log('失败: 锁定提币记录 ', row.takestc_id);
                res.json({ ok: false, msg: '失败: 锁定提币记录 ' + row.takestc_id });
            }
        } else {
            console.log('出错: lockTakeStc()更新数据', err.message);
            res.json({ ok: false, msg: '出错: lockTakeStc()更新数据 => ' + err.message });
        }
    });

};

exports.getTakeCoinOk = function (res, takestc_id, txid) {

    console.log('客户端 rpc 处理提币成功，状态更新此提币记录：', takestc_id);

    db.run('update ttakestc set islocked = ?, done = ?, operater = "sys", txid = ? where takestc_id = ?', [2, 1, txid, takestc_id], function (err) {
        if (err === null) {
            if (this.changes > 0) {
                console.log('成功: 处理完提币记录 ', takestc_id);
                res.json({ ok: true });
            } else {
                console.log('失败: 处理完提币记录 ', takestc_id);
                res.json({ ok: false, msg: '失败: 处理完提币记录 ' + takestc_id });
            }
        } else {
            console.log('出错: getTakeCoinOk()更新数据', err.message);
            res.json({ ok: false, msg: '出错: getTakeCoinOk()更新数据' + err.message });
        }
    });

};

//===============python rpc============






//============admin====================

exports.getAdminDirItems = function (res, dir_id, page, coin) {

    var beginindex = (page - 1) * 10;
    var rsnum = 10;
    var sql = '';
    switch (dir_id) {
        case '1':
            sql = 'select a.user_id, a.account, a.email, a.isvip, a.create_time, a.islocked, b.coin, b.balance, b.topupaddress, b.takeaddress from tuser as a left join tusercoin as b on a.user_id = b.user_id and b.coin = ? order by a.user_id desc limit ?, ?';
            break;
        case '2':
            sql = 'select * from tusercoin where coin = ? order by usercoin_id desc limit ?, ?';
            break;
        case '3':
            sql = 'select * from ttopupstc where coin = ? order by topupstc_id desc limit ?, ?';
            break;
        case '4':
            sql = 'select * from ttakestc where coin = ? order by takestc_id desc limit ?, ?';
            break;
        case '5':
            sql = 'select * from tstock where coin = ? order by stock_id desc limit ?, ?';
            break;
        case '6':
            sql = 'select * from tbuy where coin = ? order by buy_user_id desc limit ?, ?';
            break;
        case '7':
            sql = 'select * from tsellorder where coin = ? order by sellorder_id desc limit ?, ?';
            break;
        case '8':
            sql = 'select * from tbuyorder where coin = ? order by buyorder_id desc limit ?, ?';
            break;
        default:
            return res.end(null);
    }

    console.log(page);
    console.log(beginindex, rsnum);

    db.all(sql, [coin, beginindex, rsnum], function (err, rows) {
        if (err === null) {
            console.log('getAdminDirItems => ', rows);
            if (rows.length > 0) {
                return res.json(rows);
            } else {
                return res.end(null);
            }
        } else {
            console.log(err.message);
            return res.end(null);
        }
    });

};

exports.getItemCountAndPageCount = function (res, dir_id, coin) {

    var sql = '';
    switch (dir_id) {
        case '1':
            sql = 'select count() as count from tuser';
            break;
        case '2':
            sql = 'select count() as count from tusercoin';
            break;
        case '3':
            sql = 'select count() as count from ttopupstc';
            break;
        case '4':
            sql = 'select count() as count from ttakestc';
            break;
        case '5':
            sql = 'select count() as count from tstock';
            break;
        case '6':
            sql = 'select count() as count from tbuy';
            break;
        case '7':
            sql = 'select count() as count from tsellorder';
            break;
        case '8':
            sql = 'select count() as count from tbuyorder';
            break;
        default:
            return res.end(null);
    }

    db.all(sql + ' where coin = ?', [coin], function (err, rows) {
        if (err === null) {
            console.log('getItemCountAndPageCount => ', rows);
            if (rows.length > 0) {
                return res.json(rows[0]);
            } else {
                return res.end(null);
            }
        } else {
            console.log(err.message);
            return res.end(null);
        }
    });

};

exports.getCoinAddressOfUser = function (res, uid, coin) {

    db.all('select coin, topupaddress, takeaddress, islocked from tusercoin where user_id = ? and coin = ?', [uid, coin], function (err, rows) {
        if (err === null) {
            console.log('getCoinAddressOfUser => ', rows);
            if (rows.length > 0) {
                return res.json({ ok: true, rows: rows });
            } else {
                return res.end(null);
            }
        } else {
            console.log(err.message);
            return res.end(null);
        }
    });

};

exports.getTakeAddress = function (res, uid, coin) {

    db.all('select takeaddress from tusercoin where user_id = ? and coin = ?', [uid, coin], function (err, rows) {
        if (err === null) {
            console.log('getTakeAddress => ', rows);
            if (rows.length > 0) {
                return res.json({ ok: true, takeaddress: rows[0].takeaddress });
            } else {
                return res.end(null);
            }
        } else {
            console.log(err.message);
            return res.end(null);
        }
    });

};

exports.searchAdminDirItems = function (res, dir_id, stxt) {

    var sql = '';
    var params = [];
    switch (dir_id) {
        case '1':
            sql = 'select user_id, account, email, isvip, create_time, islocked, takeaddress from tuser where user_id = ? or account = ? or takeaddress = ?';
            params = [stxt, stxt, stxt];
            break;
        case '2':
            sql = 'select * from tusercoin where coin = ? or topupaddress = ? or user_id = ?';
            params = [stxt, stxt, stxt];
            break;
        case '3':
            sql = 'select * from ttopupstc where txid = ? or topupaddress = ?';
            params = [stxt, stxt];
            break;
        case '4':
            sql = 'select * from ttakestc where coin = ? or takenum = ? or user_id = ? or operater = ?';
            params = [stxt, stxt, stxt, stxt];
            break;
        case '5':
            sql = 'select * from tstock where user_id = ? or stocktype = ? or stockcode = ?';
            params = [stxt, stxt, stxt];
            break;
        case '6':
            sql = 'select * from tbuy where stocktype = ? or company = ? or stockcode = ? or sellorder_id = ? or buyorder_id = ? or buy_user_id = ?';
            params = [stxt, stxt, stxt, stxt, stxt];
            break;
        case '7':
            sql = 'select * from tsellorder where stocktype = ? or company = ? or stockcode = ? or sell_user_id = ?';
            params = [stxt, stxt, stxt, stxt];
            break;
        default:
            return res.end(null);
    }

    db.all(sql, params, function (err, rows) {
        if (err === null) {
            console.log('searchAdminDirItems => ', rows);
            if (rows.length > 0) {
                return res.json(rows);
            } else {
                return res.end(null);
            }
        } else {
            console.log(err.message);
            return res.end(null);
        }
    });

};

exports.islockUpdate = function (res, dir_id, tid, islocked) {

    var sql = '';
    var table = '';
    var idname = '';
    switch (dir_id) {
        case '1':
            table = 'tuser';
            idname = 'user_id';
            break;
        case '2':
            table = 'tusercoin';
            idname = 'usercoin_id';
            break;
        case '3':
            table = 'ttopupstc';
            idname = 'topupstc_id';
            break;
        case '4':
            table = 'ttakestc';
            idname = 'takestc_id';
            break;
        case '5':
            table = 'tstock';
            idname = 'stock_id';
            break;
        case '6':
            table = 'tbuy';
            idname = 'buy_user_id';
            break;
        case '7':
            table = 'tsellorder';
            idname = 'sellorder_id';
            break;
        default:
            return res.json({ ok: false, msg: '操作错误1' });
    }

    if (table != '') {
        sql = 'update ' + table + ' set islocked = ' + islocked + ' where ' + idname + ' = ' + tid;
    }
    console.log('sql => ', sql);

    db.run(sql, function (err) {
        if (err === null) {
            if (this.changes > 0) {
                console.log('更新islocked成功');
                var yesno = islocked > 0 ? '是' : '否';
                return res.json({ ok: true, msg: '操作成功', islocked: islocked, yesno: yesno });
            } else {
                console.log('更新islocked失败');
            }
        } else {
            console.log('出错: islockUpdate()更新数据', err.message);
        }
        return res.json({ ok: false, msg: '操作错误2' });
    });

};

exports.isTakeDone = function (res, islocked, takestc_id, operater) {

    db.run('update ttakestc set done = ?, operater = ? where takestc_id = ?', [1, operater, takestc_id], function (err) {
        if (err === null) {
            if (this.changes > 0) {
                console.log('更新isTakeDone成功');
                var yesno = islocked > 0 ? '是' : '否';
                return res.json({ ok: true, msg: '操作成功', islocked: islocked, yesno: yesno });
            } else {
                console.log('更新isTakeDone失败');
            }
        } else {
            console.log('出错: isTakeDone()更新数据', err.message);
        }
        return res.json({ ok: false, msg: '操作错误2' });
    });

};

//============admin====================


//===================ip operate====================
exports.hasIp = function (req, res, ip, ip1, ip2, ip3, ip4, requrl, next) {
    console.log('\n先检查ip是否在数据库的某个IP段中...');

    ipdb.all("select ip_id from tip where ipa1 <= ? and ipa2 <= ? and ipa3 <= ? and ipa4 <= ? and ipb1 >= ? and ipb2 >= ? and ipb3 >= ? and ipb4 >= ? and islocked = 0"
    , [ip1, ip2, ip3, ip4, ip1, ip2, ip3, ip4], function (err, rows) {
        if (err == null) {
            console.log('hasIp rows => ', rows);
            
            if (rows.length > 0) {
                console.log('ip段中包含此IP');
                
                if(requrl == '/' || requrl == '/coin/login' || requrl == '/usm' || requrl == '/hkm' || requrl == '/ahome') {
                    res.render('nochina', {layout: 'nochina'});//get页面请求
                    // res.writeHead(404);
                    // res.end(null);
                } else {
                    res.send(global.nochina);//ajax请求
                }
            } else {
                req.session.ip = ip;
                req.session.save();
                console.log('ip段中不包含此IP, 可以访问。继续调用 next()');
                return next();
            }
        } else {
            console.log('出错: hasIp() 查询数据', err.message);
            res.json({ ok: false, msg: 'error' });
        }
    });
};

exports.addIp = function (country, ipab) {
    console.log('先检查IP段是否已经在数据库中...');

    ipdb.all("select ip_id from tip where country = ? and ipa1 = ? and ipa2 = ? and ipa3 = ? and ipa4 = ? and ipb1 = ? and ipb2 = ? and ipb3 = ? and ipb4 = ?"
    , [country, ipab.ipa1, ipab.ipa2, ipab.ipa3, ipab.ipa4, ipab.ipb1, ipab.ipb2, ipab.ipb3, ipab.ipb4], function (err, rows) {
        if (err == null) {
            console.log(' ');
            console.log('addIp rows => ', rows);
            if (rows.length == 0) {

                console.log('开始插入新的ip段到数据库中...');
                
                ipdb.run('insert into tip (country, ipa1, ipa2, ipa3, ipa4, ipb1, ipb2, ipb3, ipb4, ipcount, thetime, islocked) values (?,?,?,?,?,?,?,?,?,?,?,?)'
                , [country, ipab.ipa1, ipab.ipa2, ipab.ipa3, ipab.ipa4, ipab.ipb1, ipab.ipb2, ipab.ipb3, ipab.ipb4, ipab.ipcount, pub.getTimeNow(), 0], function (err) {
                    if (err === null) {
                        console.log(' ');
                        console.log('this.lastID = ' + this.lastID); //lastID == 最后插入行的ID
                        if (this.lastID > 0) {
                            console.log(ipab.ipcount + ' IP段插入成功');
                        } else {
                            console.log(ipab.ipcount + ' IP段插入失败');
                        }
                    } else {
                        console.log('出错: addIp() 插入数据', err.message);
                    }
                });

            } else {
                console.log(ipab.ipcount + ' IP段已经存在数据库中');
            }
        } else {
            console.log('出错: addIp() select 查询数据', err.message);
        }
    });
};
//===================ip operate====================



//=====================webwallet=====================
exports.findAndInsertNewWebWalletAccount = function (res, account, user_id, lantip) {
    webwalletdb.all('select user_id from tuser where account = ? and theuser_id = ?', [account, user_id], function (err, rows) {
        if (err === null) {
            if (rows.length == 0) {
                return insertNewWebWalletAccount(res, account, email, lantip);
            } else {
                sendWebWalletHtml(res, user_id, lantip);// 发送web wallet页面给浏览器
            }
        } else {
            console.log('出错: findAndInsertNewWebWalletAccount()查询数据', err.message);
            return res.json({ ok: false, msg: lantip.lan49 });
        }
    });
};

function insertNewWebWalletAccount(res, account, user_id, lantip) {

    //创建新用户账号
    // var psw_sha1 = jiami.getJiamiCode(psw);

    webwalletdb.run('insert into tuser (account,paypsw,balance,theuser_id,create_time,islocked) values (?,?,?,?,?,?)'
    , [account, '', 0, user_id, pub.getTimeNow(), 0], function (err) {
        if (err === null) {
            if (this.lastID > 0) {
                console.log('webwallet 创建新账号成功, 新用户ID: ', this.lastID);
                sendWebWalletHtml(res, user_id, lantip);// 发送web wallet页面给浏览器
            } else {
                console.log('webwallet 创建新账号失败');
            }
        } else {
            console.log('操作 出错: insertNewWebWalletAccount()插入数据', err.message);
        }
        return res.end(null);
    });

}

function sendWebWalletHtml(res, user_id, lantip) {
    webwalletdb.all('select * from tuser where account = ? and theuser_id = ?', [account, user_id], function (err, rows) {
        if (err === null) {
            if (rows.length == 0) {
                console.log('webwallet 没有查找到用户：', user_id, ' 的钱包信息');
                return res.end(null);
            } else {
                console.log('发送web wallet页面给浏览器');
                res.render('webwallet', {
                    layout: 'webwallet'
                    , login: lantip.lan11, signup: lantip.lan12, account: lantip.lan13
                    , password: lantip.lan14, newaccount: lantip.lan15, email: lantip.lan80
                    , lanid: lanid, lanname: lanname
                });
            }
        } else {
            console.log('出错: sendWebWalletHtml()查询数据', err.message);
            return res.json({ ok: false, msg: lantip.lan49 });
        }
    });
}

exports.getAllAddressOfUserFromeWebWallet = function (res, user_id, coin, lantip) {
    console.log('webwallet ajax从数据库获取用户：', user_id, ' 所有的web钱包地址');
    webwalletdb.all('select * from tusercoin where user_id = ? and coin = ?', [user_id, coin], function (err, rows) {
        if (err === null) {
            if (rows.length == 0) {
                return res.json({ ok: false, msg: lantip.lan49 });
            } else {
                return res.json(rows);
            }
        } else {
            console.log('出错: getAllAddressOfUserFromeWebWallet()查询数据', err.message);
            return res.json({ ok: false, msg: lantip.lan49 });
        }
    });
};

exports.createANewAddressOfWebWallet = function (res, user_id, coin, lantip) {
    console.log('webwallet 用户要求创建一个新的web钱包地址，选择一个没有被其他用户占用的web钱包充币地址');
    
    console.log('webwallet 先检查此用户所创建的地址是否已经达到5个（最多5个）');
    webwalletdb.all('select count(usercoin_id) from tusercoin where user_id = ? and coin = ? and islocked = 0', [user_id, coin], function (err, rows) {
        console.log('createANewAddressOfWebWallet rows: ', rows);
        if (err === null) {
            var row = rows[0];
            if (row && row['count(buyorder_id)'] < 5) {
                console.log('webwallet 用户：', user_id, ' 的web钱包地址还没有达到5个，可以创建新地址');
                return selectAndCreateANewAddressOfWebWallet (res, user_id, coin, lantip);
            } else {
                console.log('webwallet 用户：', user_id, ' 的web钱包地址已经达到5个');
            }
        } else {
            console.log('出错: createANewAddressOfWebWallet()查询数据', err.message);
        }
        return res.json({ ok: false, msg: lantip.lan49 });
    });
};

function selectAndCreateANewAddressOfWebWallet (res, user_id, coin, lantip) {
    console.log('webwallet 用户要求创建一个新的web钱包地址，选择一个没有被其他用户占用的web钱包充币地址');
    webwalletdb.all('select usercoin_id, topupaddress from tusercoin where user_id = 0 and coin = ? and islocked = 0 order by usercoin_id asc limit 0,1', [coin], function (err, rows) {
        console.log('selectAndCreateANewAddressOfWebWallet rows: ', rows);
        if (err === null) {
            if (rows.length > 0) {
                console.log('webwallet 找到一个可用的' + coin + '充币地址');
                return takeCoinAddressOfWebWallet(user_id, rows[0], lantip);
            } else {
                console.log('webwallet 没有找到可用的' + coin + '充币地址');
            }
        } else {
            console.log('出错: selectAndCreateANewAddressOfWebWallet()查询数据', err.message);
        }
        return res.json({ ok: false, msg: lantip.lan49 });
    });
};

function takeCoinAddressOfWebWallet(user_id, row, lantip) {
    console.log('webwallet 让新用户占据未被使用的充币地址');
    webwalletdb.run('update tusercoin set user_id = ? where usercoin_id = ? and user_id = 0 and islocked = 0', [user_id, row.usercoin_id], function (err) {
        if (err === null) {
            if (this.changes > 0) {
                console.log('webwallet 让新用户占据这个充币地址成功');
                return res.json({ ok: true, address: row.topupaddress });
            } else {
                console.log('webwallet 让新用户占据这个充币地址失败');
                return res.json({ ok: false, msg: lantip.lan49 });
            }
        } else {
            console.log('出错: takeCoinAddressOfWebWallet()更新数据', err.message);
        }
    });
}
//=====================webwallet=====================
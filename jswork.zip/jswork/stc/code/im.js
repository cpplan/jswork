var pub = require('../code/pub');
var HashTable = require('../code/hashtable');
require('../code/globaldata');


exports.ready = function (uid, socket) {
    console.log('添加socket到hash表中');
    addSocket(uid, socket);
};

exports.sendMsg = function (touserid, msgtype, msg) {

    console.log('所有socket uid => ', global.socketTable.getKeys());

    var tosocket = global.socketTable.getValue(touserid);

    if (tosocket && tosocket.disconnected == false) {
        console.log('对方在线，直接发送通知给: ', touserid);
        console.log('msg: ', msg);

        return tosocket.emit(msgtype, msg);
    }
    console.log('对方不在线, 无须发送通知');
};

function disconnect(uid) {
    console.log('断开前，所有socket uid => ', getSocketKeys());

    console.log('用户断开了连接，从socket列表中删除此人的scoket');
    removeSocket(uid);

    console.log('断开后，所有socket uid => ', getSocketKeys());
}

exports.disconnect = disconnect;

function addSocket(uid, socket) {
    console.log('添加前，所有socket uid => ', getSocketKeys());
    global.socketTable.add(uid, socket);
    console.log('添加后，所有socket uid => ', getSocketKeys());
}

function removeSocket(uid) {
    console.log('删除', uid, ' socket前，所有socket keys => ', getSocketKeys());
    global.socketTable.remove(uid);
    console.log('删除', uid, ' socket后，所有socket keys => ', getSocketKeys());
}

function getSocketKeys() {
    return global.socketTable.getKeys();
}

function emit(uid, socket, event, data) {
    if (!socket || socket.disconnected == true) {
        console.log('socket已断开，删除此socket');
        return removeSocket(uid);
    }
    socket.emit(event, data);
}
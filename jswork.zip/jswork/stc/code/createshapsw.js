var crypto = require('crypto');

var psw = 'appleltd';
var sha1 = crypto.createHash('sha1');
var jiamiCode = sha1.update(psw).digest('hex');
console.log(jiamiCode);

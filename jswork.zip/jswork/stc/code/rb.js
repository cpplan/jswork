var pub = require('../code/pub');
var sqlite = require('../code/sqlite');


exports.loadRb = function () {
    pub.myconsole('启动Rb程序');
    setInterval(rbUs, 15000);
    // setInterval(rbHk, 10000);
};


function rbUs() {
    
    if(nowIndexUs < uslen) {
        
        if(global.usOpen == false) {
            return pub.myconsole('rb 美股都已休盘');
        }

        var stock = usStocks[nowIndexUs];
        console.log('rb usstock => ', stock);
        nowIndexUs++;
        console.log(' ');

        //向主进程发消息，获取指定股票的现价
        var stockdata = global.usStockHashTable.getValue(stock.stockcode);
        console.log('rb stockdata => ', stockdata);
        if (!stockdata) {
            console.log('rb 没有股票' + stock.stockcode + '的数据');
            console.log('rb 所有股票的key，global.usStockHashTable => ', global.usStockHashTable.getKeys());
            // console.log('所有股票的数据，global.usStockHashTable => ', global.usStockHashTable.getValues());
            return;
        }

        if(!pub.isPrice(stockdata.stockprice)) {
            console.log(stockdata.stockprice,', rbUs() buyprice bad');
        } else {
            var buynum = randBuynum(20);
            var buyprice = randPrice(stockdata.stockprice);
            var buy_user_id = 77;
    
            var clientData = {coin: stock.coin, stocktype: stock.stocktype, company: stock.company, stockcode: stock.stockcode, buynum: buynum, buyprice: buyprice, buy_user_id: buy_user_id};
    
            pub.myconsole('rb 调用rb接口 Us');
            callRbApi(clientData, 0);//place = 0 代表us
        }

        if(nowIndexUs >= uslen) {
            nowIndexUs = 0;
        }
    } else {
        nowIndexUs = 0;
    }

}

function rbHk() {

    if(nowIndexHk < hklen) {
        
        if(global.hkOpen == false) {
            return pub.myconsole('rb 港股已休盘');
        }

        var stock = hkStocks[nowIndexHk];
        console.log('rb hkstock => ', stock);
        nowIndexHk++;
        console.log(' ');

        //向主进程发消息，获取指定股票的现价
        var stockdata = global.hkStockHashTable.getValue(stock.stockcode);
        console.log('rb stockdata => ', stockdata);
        // console.log('global.hkStockHashTable => ',global.hkStockHashTable.getValues());
        if (!stockdata) {
            console.log('rb 没有股票' + stock.stockcode + '的数据');
            console.log('rb 所有股票的key，global.hkStockHashTable => ', global.hkStockHashTable.getKeys());
            // console.log('所有股票的数据，global.hkStockHashTable => ', global.hkStockHashTable.getValues());
            return;
        }

        if(!pub.isPriceHkd(stockdata.stockprice)) {
            console.log(stockdata.stockprice,', rbHk() buyprice bad');
        } else {
            var buynum = randBuynum(20);
            var buyprice = randPrice(stockdata.stockprice);
            var buy_user_id = 77;
    
            var clientData = {coin: stock.coin, stocktype: stock.stocktype, company: stock.company, stockcode: stock.stockcode, buynum: buynum, buyprice: buyprice, buy_user_id: buy_user_id};
    
            pub.myconsole('rb 调用rb接口 Hk');
            callRbApi(clientData, 1);//place = 1 代表hk
        }

        if(nowIndexHk >= hklen) {
            nowIndexHk = 0;
        }
    } else {
        nowIndexHk = 0;
    }

}

function randBuynum(basenum) {
    //随机产生购买数量
    var decbuynum = pub.getRandomBetweenZeroToNine();//确定倍数
    var buynum = decbuynum == 0 ? basenum : decbuynum * basenum;
    console.log('rb randBuynum : ', buynum);
    
    return buynum;
}

function randPrice(baseprice, place) {
    baseprice = Number(baseprice);

    //随机产生 + -，随机产生价格小数
    var randop = pub.getRandomBetweenZeroToNine();//确定 +、-
    var decprice = pub.randomNum(0, 3) * 0.1;//确定价格的小数部分：0 - 0.3
    console.log('rb decprice : ', decprice);
    if(decprice == 0) {
        console.log('rb randPrice = 0, 按市价买入');
        return 0;
    }

    var randPrice = randop < 5 ? baseprice + decprice : baseprice - decprice;
    console.log('rb randPrice : ', randPrice);

    if(place == 0) {
        randPrice = Number(randPrice.toFixed(2));
    } else {
        randPrice = Number(randPrice.toFixed(3));
    }
    return randPrice;
}


var usStocks = [
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'Apple',
        stockcode: 'NASDAQ:AAPL',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'Facebook',
        stockcode: 'NASDAQ:FB',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'Microsoft',
        stockcode: 'NASDAQ:MSFT',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'Google',
        stockcode: 'NASDAQ:GOOG',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'Oracle',
        stockcode: 'NYSE:ORCL',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'Intel',
        stockcode: 'NASDAQ:INTC',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'Amd',
        stockcode: 'NASDAQ:AMD',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'Nvidia',
        stockcode: 'NASDAQ:NVDA',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'Amazon',
        stockcode: 'NASDAQ:AMZN',
    },
    {
        coin: 'FNC',
        stocktype: 'stock',
        company: 'eBay',
        stockcode: 'NASDAQ:EBAY',
    }
];

var hkStocks = [
    // {
    //     coin: 'FNC',
    //     stocktype: 'stock',
    //     company: 'COPOWER',
    //     stockcode: 'HK:00001',
    // },
    // {
    //     coin: 'FNC',
    //     stocktype: 'stock',
    //     company: 'CKISF',
    //     stockcode: 'HK:01038',
    // },
    // {
    //     coin: 'FNC',
    //     stocktype: 'stock',
    //     company: 'SHKP',
    //     stockcode: 'HK:00016',
    // },
    // {
    //     coin: 'FNC',
    //     stocktype: 'stock',
    //     company: 'HSB',
    //     stockcode: 'HK:00011',
    // },
    // {
    //     coin: 'FNC',
    //     stocktype: 'stock',
    //     company: 'MTR',
    //     stockcode: 'HK:00066',
    // },
    // {
    //     coin: 'FNC',
    //     stocktype: 'stock',
    //     company: 'Towngas',
    //     stockcode: 'HK:00003',
    // },
    // {
    //     coin: 'FNC',
    //     stocktype: 'stock',
    //     company: 'sandschina',
    //     stockcode: 'HK:01928',
    // },
    // {
    //     coin: 'FNC',
    //     stocktype: 'stock',
    //     company: 'LINK',
    //     stockcode: 'HK:00823',
    // },
    // {
    //     coin: 'FNC',
    //     stocktype: 'stock',
    //     company: 'SCPLC',
    //     stockcode: 'HK:02888',
    // },
    // {
    //     coin: 'FNC',
    //     stocktype: 'stock',
    //     company: 'Henderson',
    //     stockcode: 'HK:00012',
    // }
];


var nowIndexUs = 0;
const uslen = usStocks.length;

var nowIndexHk = 0;
const hklen = hkStocks.length;


function callRbApi(clientData, place) {
    try {
        var coin = clientData.coin;
        var stocktype = clientData.stocktype;
        var company = clientData.company;
        var stockcode = clientData.stockcode;
        var buyprice = clientData.buyprice;

        if(typeof(company) == 'undefined' || typeof(stockcode) == 'undefined') {
            return console.log('rb callRbApi() +> ', 'special chars 1');
        }
        
        if (!pub.isAbc(coin) || isNaN(global.coinRate[coin]) || !pub.isAbc(stocktype)
         || company != pub.escape(company) || stockcode != pub.escape(stockcode)) {
            return console.log('rb callRbApi() +> ', 'special chars 2');
        }

        return sqlite.createBuyOrderForUsHkRb(coin, stocktype, company, stockcode, clientData.buynum, buyprice, clientData.buy_user_id, place);
    } catch (error) {
        console.log('rb callRbApi error => ', error.message);
    }
}
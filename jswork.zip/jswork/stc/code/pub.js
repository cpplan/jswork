var HashTable = require('../code/hashtable');


exports.logout = function (waiting_user_id, self_user_id) {
    //用户退出，则需要将自己从对手用户的otherkey中删除，并从列表中删除
    var waitingGamerValue = global.gamersTable.getValue(waiting_user_id);
    waitingGamerValue.otherkey = null;

    global.gamersTable.remove(self_user_id);
};

exports.createName = function (nameLen) {
    var abcs = 'ABCDEFGHIJKLMNPQRSTUVWXY23456789';
    var max = abcs.length;
    var name = '';

    for (var i = 0; i < nameLen; i++) {
        var index = exports.randomNum(0, 31);
        if (index >= max) {
            index = 0;
        }
        var char = abcs.substr(index, 1);
        name += char;
    }

    return name;
};

//生成从minNum到maxNum的随机数
exports.randomNum = function (minNum, maxNum) {
    var random = 0;
    switch (arguments.length) {
        case 1:
            random = parseInt(Math.random() * minNum + 1, 10);
            break;
        case 2:
            random = parseInt(Math.random() * (maxNum - minNum + 1) + minNum, 10);
            break;
    }
    return random;
};

//产生0 - 9的随机数
exports.getRandomBetweenZeroToNine = function () {
    return parseInt(Math.random().toString().split('.')[1].substr(0, 1));
};





function getDateOfToday() {
    var time = new Date();
    var month = time.getMonth() + 1;
    month = month < 10 ? '0' + month : month;
    var day = time.getDate();
    day = day < 10 ? '0' + day : day;
    return time.getFullYear().toString() + '-' + month + '-' + day;
}

exports.getTimeNow = function () {
    var time = new Date();
    var hours = time.getHours();
    hours = hours < 10 ? '0' + hours : hours;
    var minutes = time.getMinutes();
    minutes = minutes < 10 ? '0' + minutes : minutes;
    var seconds = time.getSeconds();
    seconds = seconds < 10 ? '0' + seconds : seconds;

    return getDateOfToday() + ' ' + hours + ':' + minutes + ':' + seconds;
};

exports.getTimeNowForYz = function (outTime) {
    var time = new Date();
    time.setMinutes(time.getMinutes() - outTime);
    var hours = time.getHours();
    hours = hours < 10 ? '0' + hours : hours;
    var minutes = time.getMinutes();
    minutes = minutes < 10 ? '0' + minutes : minutes;
    var seconds = time.getSeconds();
    seconds = seconds < 10 ? '0' + seconds : seconds;

    return getDateOfToday() + ' ' + hours + ':' + minutes + ':' + seconds;
};



function replaceAnyWords(words, any, replace) {
    //替换words中所有的any为replace
    var reg = new RegExp(any, "g");
    var newwords = words.replace(reg, replace);
    // console.log('newwords => ', newwords);
    return newwords;
}

exports.replaceAny = function (words, any, replace) {
    //替换words中所有的any为replace
    return replaceAnyWords(words, any, replace);
};

exports.replaceSpace = function (words) {
    //替换所有空格
    var reg = new RegExp(" ", "g");
    var newwords = words.replace(reg, '');
    return newwords;
};

exports.isPlusNumber = function (words) {
    //判断正整数
    if (typeof (words) == 'undefined') {
        return false;
    }
    var reg = /^[1-9][0-9]*$/;
    return reg.test(words.toString());
};

exports.isZeroPlusNumber = function (words) {
    //判断非负正整数
    if (words == '0' || exports.isPlusNumber(words)) {
        return true;
    }
    return false;
};

exports.isMinusNumber = function (words) {
    //判断负整数
    if (typeof (words) == 'undefined') {
        return false;
    }
    var reg = /^-[1-9][0-9]*$/;
    return reg.test(words.toString());
};

exports.isAbc = function (words) {
    //判断是否是字母
    if (typeof (words) == 'undefined') {
        return false;
    }
    var reg = /^[a-zA-Z]+$/;
    return reg.test(words);
};

exports.isAddress = function (words) {
    //判断是否是字母和数字
    if (typeof (words) == 'undefined') {
        return false;
    }
    var reg = /^[a-zA-Z0-9]+$/;
    return reg.test(words);
};

exports.isTxid = function (words) {
    //判断是否是字母和数字
    return exports.isAddress(words);
};

exports.isBlockhash = function (words) {
    //判断是否是字母和数字
    return exports.isAddress(words);
};

exports.isAbcOrNumOrUnderline = function (words) {
    //判断是否是字母数字或下划线
    if (typeof (words) == 'undefined') {
        return false;
    }
    var reg = /^[a-zA-Z0-9_]+$/;
    return reg.test(words);
};

exports.isAccount = function (words) {
    //判断是否是字母数字或下划线
    if (typeof (words) == 'undefined') {
        return false;
    }
    var reg = /^[a-zA-Z0-9_]{6,30}$/;
    return reg.test(words);
};

exports.isEmail = function (words) {
    if (typeof (words) == 'undefined') {
        return false;
    }
    var reg = /^[a-z]([a-z0-9]*[-_]?[a-z0-9]+)*@([a-z0-9]*[-_]?[a-z0-9]+)+[\.][a-z]{2,3}([\.][a-z]{2})?$/i;
    return reg.test(words);
};

exports.isPassword = function (words) {
    //判断是否是字母数字或下划线
    if (typeof (words) == 'undefined') {
        return false;
    }
    var reg = /^[a-zA-Z0-9_]{6,16}$/;
    return reg.test(words);
};

exports.escape = function (words) {

    console.log('escape handle ', words);

    //比较特殊的字符先删除掉
    words = exports.replaceSpace(words);
    words = replaceAnyWords(words, '&mdash', '');//删除&mdash
    words = replaceAnyWords(words, '"', '');//删除"
    words = replaceAnyWords(words, "'", '');//删除'

    if (words.length == 0) {
        return words;
    }

    //带\的都表示需要转义才能使用
    // words = replaceAnyWords(words, '\\\?', '');//删除?
    words = replaceAnyWords(words, '\\\*', '');//删除*
    words = replaceAnyWords(words, '\\\$', '');//删除$
    words = replaceAnyWords(words, '\\\^', '');//删除^
    words = replaceAnyWords(words, '\\\(', '');//删除(
    words = replaceAnyWords(words, '\\\)', '');//删除)
    words = replaceAnyWords(words, '\\\[', '');//删除[
    words = replaceAnyWords(words, '\\\]', '');//删除]
    words = replaceAnyWords(words, '\\\|', '');//删除|
    // words = replaceAnyWords(words, '\\\.', '');//删除.

    words = replaceAnyWords(words, '\\\\', '');//删除"1\\2"中的\
    // words = replaceAnyWords(words, '\/', '');//删除/

    if (words.length == 0) {
        return words;
    }

    var pattern = "~`!@#%{};<>,";//不需要转义就可以直接使用
    var count = pattern.length;

    for (var i = 0; i < count; i++) {
        var any = pattern[i];
        words = replaceAnyWords(words, any, '');
        // console.log('words => ', words);
    }

    return words;

};


/**
 * 判断是否是ip里面的数字
 */
exports.isIpInt = function (num) {
    if (typeof(num) == 'undefined') {
        return false;
    }
    return num >= 0 && num <= 255;
};

/**
 * 判断是否是正整数
 */
exports.isPint = function (num) {
    if (typeof(num) == 'undefined' || parseFloat(num) == 0) {
        return false;
    }
    var r = /^\+?[1-9][0-9]*$/;
    var flag = r.test(num);
    return flag;
};

/**
 * 判断是否是不超过2位小数的数字
 */
exports.isPrice = function (num) {
    if (typeof(num) == 'undefined' || parseFloat(num) == 0) {
        return false;
    }
    var r = /(^[1-9](\d+)?(\.\d{1,2})?$)|(^0$)|(^\d\.\d{1,2}$)/;
    var flag = r.test(num);
    return flag;
};

/**
 * 判断是否是不超过3位小数的数字
 */
exports.isPriceHkd = function (num) {
    if (typeof(num) == 'undefined' || parseFloat(num) == 0) {
        return false;
    }
    var r = /(^[1-9](\d+)?(\.\d{1,3})?$)|(^0$)|(^\d\.\d{1,3}$)/;
    var flag = r.test(num);
    return flag;
};

/**
 * 判断是否是不超过8位小数的数字
 */
exports.isStc = function (num) {
    if (typeof(num) == 'undefined' || parseFloat(num) == 0) {
        return false;
    }
    var r = /(^[1-9](\d+)?(\.\d{1,8})?$)|(^0$)|(^\d\.\d{1,8}$)/;
    var flag = r.test(num);
    return flag;
};

/**
 * 判断是否是不超过4位小数的数字, HKD汇率
 */
exports.isHkd = function (num) {
    if (typeof(num) == 'undefined' || parseFloat(num) == 0) {
        return false;
    }
    var r = /(^[1-9](\d+)?(\.\d{1,4})?$)|(^0$)|(^\d\.\d{1,4}$)/;
    var flag = r.test(num);
    return flag;
};

exports.getLanid = function (req) {
    var lanid = !req.session.lanid ? 'english' : req.session.lanid;
    return lanid;
};

exports.getLanTip = function (req) {
    var lanid = exports.getLanid(req);
    var lantip = global.lantipTable.getValue(lanid);
    return lantip;
};

exports.getLanTipByLanid = function (lanid) {
    var lantip = global.lantipTable.getValue(lanid);
    return lantip;
};


exports.getUsEastTime = function() {
    var time = new Date();//js获取的时间比服务器美东时间快了5个小时，必须减去
    var now = time.setHours(time.getHours() - 5);//得到新的时间戳
    var today = new Date(now);//得到实际的日期

    var strzero = '0';
    var month = today.getMonth() + 1;
    var day = today.getDate();
    
    var strmonth = month.toString();
    if(month < 10) {
        strmonth += strzero;
    }
    var strday = day.toString();
    if(day < 10) {
        strday += strzero;
    }
    var monthday = strmonth + '-' + strday;


    var hours = today.getHours();
    var minutes = today.getMinutes();

    var strhours = hours.toString();
    if(hours < 10) {
        strhours += strzero;
    }
    var strminutes = minutes.toString();
    if(minutes < 10) {
        strminutes += strzero;
    }

    var hourminute = strhours + ':' + strminutes;

    return monthday + ' ' + hourminute;
};

exports.getStatus_Off_On = function () {

    var time = new Date();//js获取的时间比服务器美东时间快了5个小时，必须减去
    var now = time.setHours(time.getHours() - 5);//得到新的时间戳
    var today = new Date(now);//得到实际的日期

    //判断是否是周六，周日
    if (today.getDay() == 6 || today.getDay() == 0) {
        console.log('今天是周六，或周日');
        return false;//休盘
    }

    var month = today.getMonth() + 1;
    var day = today.getDate();
    if(global.usStopMonth == month && global.usStopDay == day) {
        console.log(month, ' 月 ', day, ' 日为指定节假日，休盘');
        return false;
    }

    var hours = today.getHours();
    var minutes = today.getMinutes();

    console.log('getStatus_Off_On hours: ', hours, ', minutes: ', minutes);

    if(global.usXlDl == 0) {
        //夏令时(3月-11月)为美国东部时间早上9：30 - 下午4：00（北京时间21:30-次日4:00），交易时长6个半小时，中间无休
        return xlHours(hours, minutes);//3🈷10日-11月3日之外的所有时间，都为冬令时
    } else {
        //冬令时(11月-次年3月)为美国东部时间早上10：30 - 下午5：00（北京时间22:30-次日5:00），交易时长6个半小时，中间无休
        return dlHours(hours, minutes);//3🈷10日-11月3日之外的所有时间，都为冬令时
    }
};

function xlHours(hours, minutes) {
    //美东周一至周五 9：30～16：00（午间不休市）
    console.log('call xlHours');
    if (hours < 9 || hours >= 16) {
        console.log('hours < 9 || hours >= 16');
        return false;//休盘
    }
    if (hours == 9 && minutes >= 30) {
        console.log('hours == 9 && minutes >= 30');
        return true;//开盘中
    }
    if (hours > 9) {
        console.log('hours > 9');
        return true;//开盘中
    }
    console.log('5555 => hours: ', hours);
    return false;//休盘
}

function dlHours(hours, minutes) {
    //美东周一至周五 10：30～17：00（午间不休市）
    console.log('call dlHours');
    if (hours < 10 || hours >= 17) {
        console.log('hours < 10 || hours >= 17');
        return false;//休盘
    }
    if (hours == 10 && minutes >= 30) {
        console.log('hours == 10 && minutes >= 30');
        return true;//开盘中
    }
    if (hours > 10) {
        console.log('hours > 10');
        return true;//开盘中
    }
    console.log('9999 => hours: ', hours);
    return false;//休盘
}


exports.unlockMatch = function (stockcode) {
    console.log(' ');
    console.log('数据库操作执行完成，或执行中发生错误，' + stockcode + ' 已经解锁');
    global.matchLock.remove(stockcode);
    console.log(' ');
};


exports.myconsole = function(funcName) {
    console.log(' ');
    console.log(funcName);
};
var express = require('express');
var router = express.Router();
var url = require('url');
var sqlite = require('../code/sqlite');
var pub = require('../code/pub');


function getClientIp(req) {
    return req.headers['x-forwarded-for'] ||
    req.connection.remoteAddress ||
    req.socket.remoteAddress ||
    req.connection.socket.remoteAddress;
};

router.all('*', function (req, res, next) {
    console.log(' all url => ', req.url);
    return next();

    var clientid = getClientIp(req);
    console.log('clientid: ', clientid);

    if(req.url.indexOf('.php') != -1 || clientid.indexOf('54.36.') != -1) {
        res.writeHead(404);
        res.end(null);
        return console.log('恶意访问，阻断访问');
    }

    if(req.url == '/mi') {
        return res.end(clientid);
    }
    if(req.url == '/rm') {
        console.log('清除白名单 前：', global.okIpTable.getValues());
        global.okIpTable.clear();
        console.log('清除白名单 后：', global.okIpTable.getValues());
        return res.end('rmok');
    }
    if(req.url.indexOf('ai?wi=') != -1) {
        var params = url.parse(req.url, true).query;
        var whiteip = params['wi'];

        console.log('新增白名单 前：', global.okIpTable.getValues());
        global.okIpTable.add(whiteip, whiteip);
        console.log('新增白名单 后：', global.okIpTable.getValues());
        return res.end('aiok');
    }
    if(req.url.indexOf('xd?xd=') != -1) {
        var params = url.parse(req.url, true).query;
        var xldl = params['xd'];
        if(xldl == '0') {
            global.usXlDl = 0;
        } else {
            global.usXlDl = 1;
        }
        return res.end('xdok');
    }
    if(req.url.indexOf('xp?m=') != -1) {
        //指定某月，某日休盘。一般为节假日
        var params = url.parse(req.url, true).query;
        var month = params['m'];
        var day = params['d'];
        global.usStopMonth = parseInt(month);
        global.usStopDay = parseInt(day);
        return res.end('xpok');
    }

    var ips = clientid.split(':');
    if(ips.length != 4) {
        res.writeHead(404);
        res.end(null);
        return console.log(ips, ' ip格式不对，阻断访问');
    }

    var ip = ips[3];
    console.log('client ip : ', ip);

    console.log('白名单 keys: ', global.okIpTable.getKeys());
    console.log('白名单 values: ', global.okIpTable.getValues());

    if(global.okIpTable.containsKey(ip)) {
        console.log('ip 白名单包含此IP: ', ip);
        return next();
    }
    console.log('ip 白名单 不包含此IP: ', ip);

    if(req.session.ip && req.session.ip == ip) {
        console.log('此IP：', req.ip, ' 是合法IP');
        return next();
    }

    var iparr = ip.split('.');
    var ip1 = iparr[0];
    var ip2 = iparr[1];
    var ip3 = iparr[2];
    var ip4 = iparr[3];
    sqlite.hasIp(req, res, ip, ip1, ip2, ip3, ip4, req.url, next);
});


router.get('/socket.io', function (req, res) {
    return res.end('/socket.io? ok');
});

router.get('/', function (req, res) {
    return res.redirect('/usm');
});

router.get('/signin', function (req, res) {
    if (!req.session.lanid) {
        req.session.lanid = 'english';
    }
    if (req.session && req.session.userData) {
        if(req.session.userData.usertype == 1) {
            return res.redirect('/ahome');
        }
        return res.redirect('/usm');
    }

    var lantip = pub.getLanTip(req);
    var lanid = pub.getLanid(req);
    var lanname = global.lannameTable.getValue(lanid);//指定的语言

    res.render('login', {
        layout: 'login'
        , login: lantip.lan11, signup: lantip.lan12, account: lantip.lan13
        , password: lantip.lan14, newaccount: lantip.lan15, email: lantip.lan80
        , lanid: lanid, lanname: lanname
    });
});

router.get('/logout', function (req, res) {
    if (req.session && req.session.userData) {
        req.session.userData = null;
        req.session.save();
    }
    return res.redirect('/');
});

router.get('/coin/login', function (req, res) {
    if (!req.session.lanid) {
        req.session.lanid = 'english';
    }

    if (req.session && req.session.userData && req.session.userData.usertype != 1) {
        console.log('已经用普通用户账号登录了, 直接跳转到首页');
        return res.redirect('/');
    }

    if (req.session && req.session.userData && req.session.userData.usertype == 1) {
        console.log('已经用admin账号登录了，直接跳转到ahome');
        return res.redirect('/ahome');
    }

    console.log('还没有用任何类型的账号登录，直接渲染/coin/login页面');

    var lantip = pub.getLanTip(req);
    var lanid = pub.getLanid(req);
    var lanname = global.lannameTable.getValue(lanid);//指定的语言

    res.render('alogin', {
        layout: 'alogin'
        , login: lantip.lan11, signup: lantip.lan12, account: lantip.lan13
        , password: lantip.lan14, newaccount: lantip.lan15, email: lantip.lan80
        , lanid: lanid, lanname: lanname
    });
});

router.get('/alogout', function (req, res) {
    if (req.session && req.session.userData) {
        req.session.userData = null;
        req.session.save();
    }
    return res.redirect('/coin/login');
});


router.get('/updateheadurl', function (req, res) {
    return res.end(null);
    
    if (!req.session || !req.session.userData) {
        return res.json({ ok: false, msg: '请先登录' });
    }
    var params = url.parse(req.url, true).query;
    var uid = req.session.userData.user_id;
    var headurl = params['headurl'];

    var newheadurl = decodeURIComponent(headurl);
    // console.log('newheadurl => ', newheadurl);
    if (newheadurl != pub.escape(newheadurl)) {
        return res.json({ ok: false, msg: '目录中不能包括空格等特殊字符' });
    }
    sqlite.updateHeadUrl(res, uid, headurl);
});

router.get('/getheadimg', function (req, res) {
    return res.end(null);

    if (!req.session || !req.session.userData) {
        return res.redirect('/');
    }
    var userData = req.session.userData;
    sqlite.getHeadImg(res, userData.user_id);
});

router.get('/gettime', function (req, res) {
    if (!req.session || !req.session.userData) {
        return res.end();
    }
    var myDate = new Date();
    var mytime = myDate.toLocaleString();
    return res.json({ time: mytime });
});

router.post('/regist', function (req, res) {
    try {
        var lantip = pub.getLanTip(req);

        var account = req.body.account;
        var email = req.body.email;
        var psw = req.body.psw;

        if (!pub.isAccount(account) || !pub.isPassword(psw)) {
            return res.json({ msg: lantip.lan39 });
        }
        if (account.length < 6 || account.length > 30) {
            return res.json({ msg: lantip.lan5 });
        }
        if(!pub.isEmail(email)) {
            return res.json({ msg: lantip.lan25 });
        }
        if (email.length < 6 || email.length > 60) {
            return res.json({ msg: lantip.lan24 });
        }
        if (psw.length < 6 || psw.length > 16) {
            return res.json({ msg: lantip.lan6 });
        }

        return sqlite.regist(res, account, psw, email, lantip);
    } catch (error) {
        console.log(error.message);
        return res.end(null);
    }
});

router.post('/aregist', function (req, res) {
    return res.end(null);
    try {
        var account = req.body.account;
        var psw = req.body.psw;
        if (!pub.isAbcOrNumOrUnderline(account) || !pub.isAbcOrNumOrUnderline(psw)) {
            return res.json({ msg: '请不要填写包括空格在内的特殊字符' });
        }
        if (account.length < 6 || account.length > 30) {
            return res.json({ msg: '账号长度应为6-30字符' });
        }
        if (psw.length < 6 || psw.length > 16) {
            return res.json({ msg: '密码长度应为6-16字符' });
        }

        return sqlite.aregist(res, account, psw);
    } catch (error) {
        console.log(error.message);
        return res.end(null);
    }
});

router.post('/login', function (req, res) {
    try {
        var lantip = pub.getLanTip(req);

        var account = req.body.account;
        var psw = req.body.psw;

        if (!pub.isAccount(account) || !pub.isPassword(psw)) {
            return res.json({ ok: false, msg: lantip.lan7 });
        }

        return sqlite.login(req, res, account, psw);
    } catch (error) {
        console.log(error.message);
        return res.end(null);
    }
});

router.post('/alogin', function (req, res) {
    try {
        var account = req.body.account;
        var psw = req.body.psw;

        if (!pub.isAccount(account) || !pub.isPassword(psw)) {
            return res.json({ ok: false, msg: '账号或密码错误' });
        }

        return sqlite.alogin(req, res, account, psw);
    } catch (error) {
        console.log(error.message);
        return res.end(null);
    }
});


router.get('/usm', function (req, res) {
    if (!req.session.lanid) {
        req.session.lanid = 'english';
    }

    var lanid = pub.getLanid(req);
    var lanpage = global.lanpageTable.getValue(lanid);//指定的语言在页面上的共同文字的翻译
    var lanname = global.lannameTable.getValue(lanid);//指定的语言
    var ltds = global.ltdTable.getValue(lanid);//指定语言下的公司名称

    if (req.session && req.session.userData) {
        var userData = req.session.userData;
        global.lanidHashTable.add(req.session.userData.user_id, lanid);//保存用户所选择的语言标记
    } else {
        var userData = {};
    }
    // if(req.session.userData && req.session.userData.usertype == 1) {
    //     return res.redirect('/ahome');
    // }


    return res.render('usindex', {
        layout: 'usindex'
        , account: userData.account, uid: userData.user_id, logout: lanpage.lan37, stockcoin: lanpage.lan55

        , title: lanpage.lan1603, usmarket: lanpage.lan1601, hkmarket: lanpage.lan1602, signinup: lanpage.lan1
        , nasdaq: lanpage.lan17, dj: lanpage.lan18, sp500: lanpage.lan19
        , lanid: lanid, lanname: lanname, allstock: lanpage.lan20, boughtstock: lanpage.lan21, sellingstocks: lanpage.lan22
        , ycprice: lanpage.lan23, toprice: lanpage.lan24, trprice: lanpage.lan25, buyingstocks: lanpage.lan53
        , marketvalue: lanpage.lan26, unit:lanpage.lan2601, peratio: lanpage.lan27, ok: lanpage.lan54
        , buy: lanpage.lan28, sell: lanpage.lan29, buynum: lanpage.lan30, lessnowprice: lanpage.lan31
        , highprice: lanpage.lan51, sellnum: lanpage.lan32, lowprice: lanpage.lan33, nowprice: lanpage.lan34
        , stcbalance: lanpage.stcbalance, uid: lanpage.user_id, lanpage: lanpage.lan37
        , stcbalance: lanpage.lan371, platformstcaddress: lanpage.lan372
        , yourtopupstcaddress: lanpage.lan373, shareanaddress: lanpage.lan374
        , change: lanpage.lan375, addnew: lanpage.lan376, holding: lanpage.lan10, shares: lanpage.lan50

        , apple: ltds.apple, facebook: ltds.facebook, microsoft: ltds.microsoft, google: ltds.google
        , oracle: ltds.oracle, intel: ltds.intel, amd: ltds.amd, nvidia: ltds.nvidia, amazon: ltds.amazon, ebay: ltds.ebay

        , takeamount: lanpage.lan49, take: lanpage.lan48, Details: lanpage.lan47, community: lanpage.lan52
    });
});


router.get('/hkm', function (req, res) {
    if (!req.session.lanid) {
        req.session.lanid = 'chinese';
    }
    if (!req.session || !req.session.userData) {
        return res.redirect('/');
    }
    if(req.session.userData.usertype == 1) {
        return res.redirect('/ahome');
    }

    var userData = req.session.userData;

    var lanid = pub.getLanid(req);
    var lanpage = global.lanpageTable.getValue(lanid);//指定的语言在页面上的共同文字的翻译
    var lanname = global.lannameTable.getValue(lanid);//指定的语言
    var ltds = global.ltdTable.getValue(lanid);//指定语言下的公司名称

    global.lanidHashTable.add(req.session.userData.user_id, lanid);//保存用户所选择的语言标记

    return res.render('hkindex', {
        layout: 'hkindex'
        , account: userData.account, uid: userData.user_id, logout: lanpage.lan37, stockcoin: lanpage.lan55, hkd: global.usCashRate.HKD

        , title: lanpage.lan1604, usmarket: lanpage.lan1601, hkmarket: lanpage.lan1602, hsi: lanpage.lan1901
        , lanid: lanid, lanname: lanname, allstock: lanpage.lan20, boughtstock: lanpage.lan21, sellingstocks: lanpage.lan22
        , ycprice: lanpage.lan23, toprice: lanpage.lan24, trprice: lanpage.lan25, buyingstocks: lanpage.lan53

        , marketvalue: lanpage.lan26, unit:lanpage.lan2602, peratio: lanpage.lan27, ok: lanpage.lan54
        , buy: lanpage.lan28, sell: lanpage.lan29, buynum: lanpage.lan30, lessnowprice: lanpage.lan31
        , highprice: lanpage.lan51, sellnum: lanpage.lan32, lowprice: lanpage.lan33, nowprice: lanpage.lan34
        , stcbalance: lanpage.stcbalance, uid: lanpage.user_id, lanpage: lanpage.lan37
        , stcbalance: lanpage.lan371, platformstcaddress: lanpage.lan372
        , yourtopupstcaddress: lanpage.lan373, shareanaddress: lanpage.lan374
        , change: lanpage.lan375, addnew: lanpage.lan376, holding: lanpage.lan10, shares: lanpage.lan50

        , Henderson: ltds.Henderson, CKISF: ltds.CKISF, SHKP: ltds.SHKP, HSB: ltds.HSB
        , MTR: ltds.MTR, COPOWER: ltds.COPOWER, Towngas: ltds.Towngas, sandschina: ltds.sandschina
        , LINK: ltds.LINK, SCPLC: ltds.SCPLC

        , takeamount: lanpage.lan49, take: lanpage.lan48, Details: lanpage.lan47, community: lanpage.lan52
    });
});

router.get('/setmylan', function (req, res) {
    var params = url.parse(req.url, true).query;
    var lanid = params['lanid'];
    console.log(lanid, ' isAbc: ', pub.isAbc(lanid));

    if (!pub.isAbc(lanid)) {
        return res.json(global.englisharr);
    }
    req.session.lanid = lanid;

    switch (lanid) {
        case 'english':
            res.json(global.englisharr);
            break;
        case 'chinese':
            res.json(global.chinesearr);
            break;
        default:
            res.json(global.englisharr);
            break;
    }
});

router.get('/getmylan', function (req, res) {
    switch (req.session.lanid) {
        case 'english':
            res.json(global.englisharr);
            break;
        case 'chinese':
            res.json(global.chinesearr);
            break;
        default:
            res.json(global.englisharr);
            break;
    }
    return res.end([]);
});

router.get('/getNumsOfMyStocks', function (req, res) {

    if (req.session && req.session.userData && req.session.userData.usertype == 1) {
        console.log('已经用admin账号登录了, 直接跳转到首页');
        return res.json([]);
    }

    if (!req.session || !req.session.userData) {
        return res.json([]);
    }
    var params = url.parse(req.url, true).query;
    var coin = params['coin'];
    var stocktype = params['stocktype'];

    if (!pub.isAbc(coin) || isNaN(global.coinRate[coin]) || !pub.isAbc(stocktype)) {
        return res.json([]);
    }

    var user_id = req.session.userData.user_id;
    return sqlite.getNumsOfMyStocks(res, user_id, coin, stocktype);
});

router.post('/buystock', function (req, res) {

    if (req.session && req.session.userData && req.session.userData.usertype == 1) {
        console.log('已经用admin账号登录了, 直接跳转到首页');
        return res.json({ ok: false, msg: lantip.lan41 });
    }

    var lantip = pub.getLanTip(req);
    
    if (!req.session || !req.session.userData) {
        return res.json({ ok: false, msg: lantip.lan41 });
    }

    try {
        var coin = req.body.coin;
        var stocktype = req.body.stocktype;
        var company = req.body.company;
        var stockcode = req.body.stockcode;
        var buynum = req.body.buynum;
        var topbuyprice = req.body.buyprice;

        var stockplace = stockcode.split(':');
        if(stockplace.length != 2) {
            return res.json({ ok: false, msg: lantip.lan39 });
        }
        var place = 0;//代表us
        switch(stockplace[0]) {
            case 'NASDAQ':
                if (global.usOpen == false) {
                    return res.json({ ok: false, msg: lantip.lan65 });
                }
            break;
            case 'NYSE':
                if (global.usOpen == false) {
                    return res.json({ ok: false, msg: lantip.lan65 });
                }
            break;
            case 'HK':
                place = 1;//代表hk
                if (global.hkOpen == false) {
                    return res.json({ ok: false, msg: lantip.lan65 });
                }
            break;
        }


        if(typeof(company) == 'undefined' || typeof(stockcode) == 'undefined') {
            return res.json({ ok: false, msg: lantip.lan39 });
        }
        
        if (!pub.isAbc(coin) || isNaN(global.coinRate[coin]) || !pub.isAbc(stocktype)
            || company.length == 0 || company != pub.escape(company)
            || stockcode.length == 0 || stockcode != pub.escape(stockcode) || !pub.isPint(buynum)) {
            return res.json({ ok: false, msg: lantip.lan39 });
        }

        var user_id = req.session.userData.user_id;


        switch(place) {
            case 0:
                if(topbuyprice != 'checkbox' && !pub.isPrice(topbuyprice)) {
                    return res.json({ ok: false, msg: lantip.lan39 });
                }

                if(topbuyprice == 'checkbox') {
                    topbuyprice = 0;
                } else {
                    topbuyprice = parseFloat(topbuyprice).toFixed(2);
                }
                sqlite.createBuyOrderForUs(res, coin, stocktype, company, stockcode, parseInt(buynum), topbuyprice, user_id, lantip);
            break;
            case 1:
                if(topbuyprice != 'checkbox' && !pub.isPriceHkd(topbuyprice)) {
                    return res.json({ ok: false, msg: lantip.lan39 });
                }

                if(topbuyprice == 'checkbox') {
                    topbuyprice = 0;
                } else {
                    topbuyprice = parseFloat(topbuyprice).toFixed(3);
                }
                sqlite.createBuyOrderForHk(res, coin, stocktype, company, stockcode, parseInt(buynum), topbuyprice, user_id, lantip);
            break;
        }
    } catch (error) {
        console.log('buystock error => ', error.message);
        return res.json({ ok: false, msg: lantip.lan40 });
    }
});

router.post('/sellstock', function (req, res) {

    if (req.session && req.session.userData && req.session.userData.usertype == 1) {
        console.log('已经用admin账号登录了, 直接跳转到首页');
        return res.json({ ok: false, msg: lantip.lan41 });
    }

    var lantip = pub.getLanTip(req);

    if (!req.session || !req.session.userData) {
        return res.json({ ok: false, msg: lantip.lan41 });
    }

    try {
        var coin = req.body.coin;
        var stocktype = req.body.stocktype;
        var company = req.body.company;
        var stockcode = req.body.stockcode;
        var sellnum = req.body.sellnum;
        var sellprice = req.body.sellprice;

        var stockplace = stockcode.split(':');
        if(stockplace.length != 2) {
            return res.json({ ok: false, msg: lantip.lan39 });
        }
        var place = 0;
        switch(stockplace[0]) {
            case 'NASDAQ':
                if (global.usOpen == false) {
                    return res.json({ ok: false, msg: lantip.lan65 });
                }
            break;
            case 'NYSE':
                if (global.usOpen == false) {
                    return res.json({ ok: false, msg: lantip.lan65 });
                }
            break;
            case 'HK':
                place = 1;
                if (global.hkOpen == false) {
                    return res.json({ ok: false, msg: lantip.lan65 });
                }
            break;
        }


        if(typeof(company) == 'undefined' || typeof(stockcode) == 'undefined') {
            return res.json({ ok: false, msg: lantip.lan39 });
        }

        if (!pub.isAbc(coin) || isNaN(global.coinRate[coin]) || !pub.isAbc(stocktype)
            || company != pub.escape(company) || stockcode != pub.escape(stockcode) || !pub.isPint(sellnum)) {
            return res.json({ ok: false, msg: lantip.lan39 });
        }


        var lowestprice = 0;//默认表示用市价卖出
        switch(place) {
            case 0:
                var sprice0 = parseFloat(sellprice).toFixed(2);
                if (pub.isPrice(sellprice) && sprice0 > 0) {
                    lowestprice = sprice0;//设定了最低卖出价格
                }
            break;
            case 1:
                var sprice1 = parseFloat(sellprice).toFixed(3);
                if (pub.isPriceHkd(sellprice) && sprice1 > 0) {
                    lowestprice = sprice1;//设定了最低卖出价格
                }
            break;
        }
        return sqlite.sellStock(res, coin, stocktype, company, stockcode, sellnum, lowestprice, req.session.userData.user_id, lantip);
    } catch (error) {
        console.log('sellstock error => ', error.message);
        return res.json({ ok: false, msg: lantip.lan40 });
    }
});


router.post('/updateTakeAddress', function (req, res) {

    if (req.session && req.session.userData && req.session.userData.usertype == 1) {
        console.log('已经用admin账号登录了, 直接跳转到首页');
        return res.json({ ok: false, msg: lantip.lan41 });
    }

    var lantip = pub.getLanTip(req);

    if (!req.session || !req.session.userData) {
        return res.json({ ok: false, msg: lantip.lan41 });
    }

    try {
        var coin = req.body.coin;
        var takeaddress = req.body.takeaddress;

        if (takeaddress.length < 26 && takeaddress.length > 34) {
            return res.json({ ok: false, msg: lantip.lan39 });
        }

        if (!pub.isAbc(coin) || isNaN(global.coinRate[coin]) || !pub.isAddress(takeaddress)) {
            return res.json({ ok: false, msg: lantip.lan39 });
        }

        return sqlite.updateTakeAddress(res, takeaddress, req.session.userData.user_id, coin, lantip);
    } catch (error) {
        console.log('updateTakeAddress error => ', error.message);
        return res.json({ ok: false, msg: lantip.lan40 });
    }
});

router.post('/takestc', function (req, res) {

    if (req.session && req.session.userData && req.session.userData.usertype == 1) {
        console.log('已经用admin账号登录了, 直接跳转到首页');
        return res.json({ ok: false, msg: lantip.lan41 });
    }

    var lantip = pub.getLanTip(req);

    if (!req.session || !req.session.userData) {
        return res.json({ ok: false, msg: lantip.lan41 });
    }

    try {
        var coin = req.body.coin;
        var takenum = req.body.takenum;

        if (!pub.isAbc(coin) || isNaN(global.coinRate[coin]) || !pub.isStc(takenum)) {
            return res.json({ ok: false, msg: lantip.lan44 });
        }

        return sqlite.takeStc(res, coin, takenum, req.session.userData.user_id, lantip);
    } catch (error) {
        console.log('takestc error => ', error.message);
        return res.json({ ok: false, msg: lantip.lan40 });
    }
});

router.get('/gettakes', function (req, res) {

    if (req.session && req.session.userData && req.session.userData.usertype == 1) {
        console.log('已经用admin账号登录了, 直接跳转到首页');
        return res.json([]);
    }

    if (!req.session || !req.session.userData) {
        return res.json([]);
    }

    var params = url.parse(req.url, true).query;
    var coin = params['coin'];

    if (!pub.isAbc(coin) || isNaN(global.coinRate[coin])) {
        return res.json([]);
    }

    var user_id = req.session.userData.user_id;
    return sqlite.getTakes(res, user_id, coin);
});

router.get('/getcoins', function (req, res) {

    if (req.session && req.session.userData && req.session.userData.usertype == 1) {
        console.log('已经用admin账号登录了, 直接跳转到首页');
        return res.redirect('/');
    }

    if (!req.session || !req.session.userData) {
        return res.json([]);
    }

    return sqlite.getCoins(res);
});

router.get('/getBalanceAndAddress', function (req, res) {

    if (req.session && req.session.userData && req.session.userData.usertype == 1) {
        console.log('已经用admin账号登录了, 直接跳转到首页');
        return res.redirect('/');
    }

    if (!req.session || !req.session.userData) {
        return res.json([]);
    }

    var params = url.parse(req.url, true).query;
    var coin = params['coin'];

    if (!pub.isAbc(coin) || isNaN(global.coinRate[coin])) {
        return res.json([]);
    }
    
    var user_id = req.session.userData.user_id;
    return sqlite.getBalanceAndAddress(res, user_id, coin);
});

router.get('/buyingstock', function (req, res) {

    if (req.session && req.session.userData && req.session.userData.usertype == 1) {
        console.log('已经用admin账号登录了, 直接跳转到首页');
        return res.redirect('/');
    }

    if (!req.session || !req.session.userData) {
        return res.json([]);
    }

    var params = url.parse(req.url, true).query;
    var coin = params['coin'];

    if (!pub.isAbc(coin) || isNaN(global.coinRate[coin])) {
        return res.json([]);
    }

    return sqlite.getBuyingStock(res, coin, req.session.userData.user_id);
});

router.get('/buyback', function (req, res) {
    var lantip = pub.getLanTip(req);

    if (req.session && req.session.userData && req.session.userData.usertype == 1) {
        console.log('已经用admin账号登录了, 直接跳转到首页');
        return res.json({ok: false, msg: lantip.lan40});
    }

    if (!req.session || !req.session.userData) {
        return res.json({ok: false, msg: lantip.lan40});
    }

    var params = url.parse(req.url, true).query;
    var buyorder_id = params['tid'];

    if (!pub.isPint(buyorder_id)) {
        return res.json({ok: false, msg: lantip.lan40});
    }

    return sqlite.buyback(res, req.session.userData.user_id, parseInt(buyorder_id), lantip);
});

router.get('/sellingstock', function (req, res) {

    if (req.session && req.session.userData && req.session.userData.usertype == 1) {
        console.log('已经用admin账号登录了, 直接跳转到首页');
        return res.redirect('/');
    }

    if (!req.session || !req.session.userData) {
        return res.json([]);
    }

    var params = url.parse(req.url, true).query;
    var coin = params['coin'];

    if (!pub.isAbc(coin) || isNaN(global.coinRate[coin])) {
        return res.json([]);
    }

    return sqlite.getSellingStock(res, coin, req.session.userData.user_id);
});

router.get('/sellback', function (req, res) {
    var lantip = pub.getLanTip(req);

    if (req.session && req.session.userData && req.session.userData.usertype == 1) {
        console.log('已经用admin账号登录了, 直接跳转到首页');
        return res.json({ok: false, msg: lantip.lan40});
    }

    if (!req.session || !req.session.userData) {
        return res.json({ok: false, msg: lantip.lan40});
    }

    var params = url.parse(req.url, true).query;
    var sell_id = params['tid'];

    if (!pub.isPint(sell_id)) {
        return res.json({ok: false, msg: lantip.lan40});
    }

    return sqlite.sellback(res, req.session.userData.user_id, parseInt(sell_id), lantip);
});



//===============python rpc==============================================


router.post('/topupaddress', function (req, res) {

    try {
        console.log('topupaddress rpc');
        console.log('req.body => ', req.body);

        var words = req.body.words;
        var coin = req.body.coin;
        var topupaddress = req.body.address;

        if (words != '2sejfow9192sjfow') {
            console.log('pwrong');
            return res.json({ ok: false, msg: 'pwrong' });
        }

        if (!pub.isAbc(coin)) {
            console.log('not abc');
            return res.json({ ok: false, msg: 'not abc' });
        }

        if (isNaN(global.coinRate[coin])) {
            console.log('not coinrate');
            return res.json({ ok: false, msg: 'not coinrate' });
        }

        if (topupaddress.length < 26 && topupaddress.length > 34) {
            console.log('len 26 - 34');
            return res.json({ ok: false, msg: 'len 26 - 34' });
        }

        if (!pub.isAddress(topupaddress)) {
            console.log('not address');
            return res.json({ ok: false, msg: 'not address' });
        }

        console.log('topupaddress data ok');
        return sqlite.addLastTopupAddress(res, coin, topupaddress);
    } catch (error) {
        console.log('topupaddress error => ', error.message);
        return res.json({ ok: false, msg: 'failed3' });
    }

});

router.post('/gettx', function (req, res) {

    try {
        console.log('wallet gettx success');
        console.log('req.body => ', req.body);

        var words = req.body.words;
        var generated = req.body.generated;
        var amount = req.body.amount;
        var confirmations = req.body.confirmations;
        var category = req.body.category;

        var txid = req.body.txid;
        var txtime = req.body.txtime;
        var blockhash = req.body.blockhash;
        var blockindex = req.body.blockindex;
        var blocktime = req.body.blocktime;
        var topupaddress = req.body.address;

        var coin = req.body.coinname;


        if(global.lastTxidForSuccess == txid) {
            console.log('has same one');
            return res.json({ ok: false, msg: 'has same one' });
        }


        // return res.json({ ok: true, msg: 'success' });
        if (words != 'wheoriwdfhois973223') {
            console.log('failed 0');
            return res.json({ ok: false, msg: 'failed 0' });
        }

        if (typeof(generated) == 'undefined' || typeof(confirmations) == 'undefined'
            || typeof(category) == 'undefined' || typeof(txtime) == 'undefined' || typeof(blocktime) == 'undefined') {
            
            console.log('failed 1');
            return res.json({ ok: false, msg: 'failed 1' });
        }

        if(!pub.isStc(amount)) {
            console.log('amount');
            return res.json({ ok: false, msg: 'amount' });
        }

        if(!pub.isTxid(txid)) {
            console.log('txid');
            return res.json({ ok: false, msg: 'txid' });
        }

        if(!pub.isBlockhash(blockhash)) {
            console.log('blockhash');
            return res.json({ ok: false, msg: 'blockhash' });
        }

        if(!pub.isAddress(topupaddress)) {
            console.log('topupaddress');
            return res.json({ ok: false, msg: 'topupaddress' });
        }

        if(!pub.isAbc(coin)) {
            console.log('coin');
            return res.json({ ok: false, msg: 'coin' });
        }

        if (generated == true || confirmations < 1 || category != 'receive' || txtime < 1564514876 || blocktime < 1564514876 || isNaN(global.coinRate[coin])) {
            console.log('failed 2');
            return res.json({ ok: false, msg: 'failed 2' });
        }

        return sqlite.updateUserStc(res, coin, amount, confirmations, txid, txtime, blockhash, blockindex, blocktime, topupaddress);
    } catch (error) {
        console.log('gettx error => ', error.message);
        return res.json({ ok: false, msg: 'failed3' });
    }

});

router.post('/gettake', function (req, res) {
    try {
        console.log('wallet gettake success');
        console.log('req.body => ', req.body);

        var words = req.body.words;
        var coin = req.body.coin;

        if (words != 'wheoriwdfhois973223') {
            console.log('failed 0');
            return res.json({ ok: false, msg: 'failed 0' });
        }

        if(!pub.isAbc(coin)) {
            console.log('coin');
            return res.json({ ok: false, msg: 'coin' });
        }

        return sqlite.getTakeCoin(res, coin);
    } catch (error) {
        console.log('gettake error => ', error.message);
        return res.json({ ok: false, msg: 'failed3' });
    }
});

router.post('/gettakeok', function (req, res) {
    try {
        console.log('wallet gettakeok success');
        console.log('req.body => ', req.body);

        var words = req.body.words;
        var takestc_id = req.body.takestc_id;
        var txid = req.body.txid;

        if (words != 'wheoriwdfhois973223') {
            console.log('failed 0');
            return res.json({ ok: false, msg: 'failed 0' });
        }

        if(!pub.isPint(takestc_id)) {
            console.log('takestc_id');
            return res.json({ ok: false, msg: takestc_id });
        }

        if(!pub.isTxid(txid)) {
            console.log('txid');
            return res.json({ ok: false, msg: 'txid' });
        }

        return sqlite.getTakeCoinOk(res, takestc_id, txid);
    } catch (error) {
        console.log('gettakeok error => ', error.message);
        return res.json({ ok: false, msg: 'failed3' });
    }
});

//===============python rpc==============================================



//============admin======================================================

router.get('/ahome', function (req, res) {

    if (req.session && req.session.userData && req.session.userData.usertype != 1) {
        console.log('已经用普通用户账号登录了, 直接跳转到首页');
        return res.redirect('/');
    }

    if (!req.session || !req.session.userData) {
        console.log('还没有用任何类型的账号登录, 跳转到首页');
        return res.redirect('/');
    }

    console.log('已经用admin账号登录了，直接渲染/ahome页面');

    var userData = req.session.userData;
    return res.render('ahome', { layout: 'ahome', account: userData.account, uid:userData.user_id });
});

router.get('/adiritems', function (req, res) {

    if (req.session && req.session.userData && req.session.userData.usertype != 1) {
        console.log('已经用普通用户账号登录了, 直接跳转到首页');
        return res.json({ok: false, url: '/'});
    }

    if (!req.session || !req.session.userData) {
        console.log('还没有用任何类型的账号登录, 跳转到首页');
        return res.json({ok: false, url: '/'});
    }

    console.log('已经用admin账号登录了, 允许读取数据');

    var params = url.parse(req.url, true).query;
    var dirid = params['dirid'];
    var page = params['page'];
    var coin = params['coin'];
    
    if (!pub.isPint(dirid) || !pub.isPint(page)) {
        return res.end(null);
    }

    if (!pub.isAbc(coin) || isNaN(global.coinRate[coin])) {
        return res.end(null);
    }

    return sqlite.getAdminDirItems(res, dirid, page, coin);
});

router.get('/getitemcountandpagecount', function (req, res) {

    if (req.session && req.session.userData && req.session.userData.usertype != 1) {
        console.log('已经用普通用户账号登录了, 直接跳转到首页');
        return res.json({ok: false, url: '/'});
    }

    if (!req.session || !req.session.userData) {
        console.log('还没有用任何类型的账号登录, 跳转到首页');
        return res.json({ok: false, url: '/'});
    }

    console.log('已经用admin账号登录了, 允许读取数据');

    var params = url.parse(req.url, true).query;
    var dirid = params['dirid'];
    var coin = params['coin'];

    if (!pub.isPint(dirid)) {
        return res.end(null);
    }

    if (!pub.isAbc(coin) || isNaN(global.coinRate[coin])) {
        return res.end(null);
    }

    return sqlite.getItemCountAndPageCount(res, dirid, coin);
});

router.get('/getCoinAddressOfUser', function (req, res) {

    if (req.session && req.session.userData && req.session.userData.usertype != 1) {
        console.log('已经用普通用户账号登录了, 直接跳转到首页');
        return res.json({ok: false, url: '/'});
    }

    if (!req.session || !req.session.userData) {
        console.log('还没有用任何类型的账号登录, 跳转到首页');
        return res.json({ok: false, url: '/'});
    }

    console.log('已经用admin账号登录了, 允许读取数据');

    var params = url.parse(req.url, true).query;
    var uid = params['uid'];
    var coin = params['coin'];

    if (!pub.isPint(uid)) {
        return res.end(null);
    }

    if (!pub.isAbc(coin) || isNaN(global.coinRate[coin])) {
        return res.end(null);
    }

    return sqlite.getCoinAddressOfUser(res, uid, coin);
});

router.get('/gettakeaddress', function (req, res) {

    if (req.session && req.session.userData && req.session.userData.usertype != 1) {
        console.log('已经用普通用户账号登录了, 直接跳转到首页');
        return res.json({ok: false, url: '/'});
    }

    if (!req.session || !req.session.userData) {
        console.log('还没有用任何类型的账号登录, 跳转到首页');
        return res.json({ok: false, url: '/'});
    }

    console.log('已经用admin账号登录了, 允许读取数据');

    var params = url.parse(req.url, true).query;
    var uid = params['uid'];
    var coin = params['coin'];

    if (!pub.isPint(uid) || !pub.isAbc(coin) || isNaN(global.coinRate[coin])) {
        return res.end(null);
    }

    return sqlite.getTakeAddress(res, uid, coin);
});

router.get('/searchadmin', function (req, res) {

    if (req.session && req.session.userData && req.session.userData.usertype != 1) {
        console.log('已经用普通用户账号登录了, 直接跳转到首页');
        return res.json({ok: false, url: '/'});
    }

    if (!req.session || !req.session.userData) {
        console.log('还没有用任何类型的账号登录, 跳转到首页');
        return res.json({ok: false, url: '/'});
    }

    console.log('已经用admin账号登录了, 允许读取数据');

    var params = url.parse(req.url, true).query;
    var dirid = params['dirid'];
    var stxt = params['stxt'];

    if (!pub.isPint(dirid) || !pub.isAbcOrNumOrUnderline(stxt)) {
        return res.end(null);
    }

    return sqlite.searchAdminDirItems(res, dirid, stxt);
});

router.get('/islocked', function (req, res) {

    if (req.session && req.session.userData && req.session.userData.usertype != 1) {
        console.log('已经用普通用户账号登录了, 直接跳转到首页');
        return res.json({ok: false, url: '/'});
    }

    if (!req.session || !req.session.userData) {
        console.log('还没有用任何类型的账号登录, 跳转到首页');
        return res.json({ok: false, url: '/'});
    }

    console.log('已经用admin账号登录了, 允许更新数据');

    var params = url.parse(req.url, true).query;
    var dirid = params['dirid'];
    var tid = params['tid'];
    var islocked = params['islocked'];

    if (!pub.isPint(dirid) || !pub.isPint(tid) || !pub.isZeroPlusNumber(islocked)) {
        return res.json({ok: false, msg: '数据错误'});
    }

    islocked = parseInt(islocked);
    islocked = islocked > 0 ? 0 : 1;
    return sqlite.islockUpdate(res, dirid, tid, islocked);
});

router.get('/isTakeDone', function (req, res) {

    if (req.session && req.session.userData && req.session.userData.usertype != 1) {
        console.log('已经用普通用户账号登录了, 直接跳转到首页');
        return res.json({ok: false, url: '/'});
    }

    if (!req.session || !req.session.userData) {
        console.log('还没有用任何类型的账号登录, 跳转到首页');
        return res.json({ok: false, url: '/'});
    }

    console.log('已经用admin账号登录了, 允许更新数据');

    var params = url.parse(req.url, true).query;
    var takestc_id = params['tid'];
    var islocked = params['islocked'];

    console.log(islocked,' ', takestc_id);
    
    if (!pub.isPint(takestc_id) || !pub.isZeroPlusNumber(islocked)) {
        return res.json({ok: false, msg: '数据错误'});
    }

    islocked = parseInt(islocked);
    islocked = islocked > 0 ? 0 : 1;

    console.log(islocked,' ', takestc_id, req.session.userData.account);

    return sqlite.isTakeDone(res, islocked, takestc_id, req.session.userData.account);
});

//============admin======================================================



router.get('/:id', function (req, res) {
    //所有未被处理的请求，都由此来处理, 包括带参数请求
    console.log('/:id url => ', req.url);
    return res.redirect('/');
});

module.exports = router;